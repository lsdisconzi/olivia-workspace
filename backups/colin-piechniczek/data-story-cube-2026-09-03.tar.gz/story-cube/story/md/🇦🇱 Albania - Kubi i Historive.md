---

### 1\. Pse Ekziston Kjo

Kur një fëmijë mbahet larg njërit prej prindërve — për shkak të distancës, ndarjes apo pengimit të qëllimshëm — ai humbet diçka të pazëvendësueshme: tingullin e përditshëm të njeriut që e do.

Kubi i Historive nuk është një produkt që gjeneron mirëqenie sociale si efekt anësor. Është një mision social që përdor teknologjinë si mjet. Prandaj, forma e tij natyrore institucionale është ajo e një organizate jofitimprurëse — ku qëllimi drejton strukturën, dhe jo e kundërta.

Ky dokument përcakton vizionin dhe rrugën për ta kthyer Kubin e Historive në një lëvizje me interes publik: një mjet të shkallëzueshëm, të bazuar në prova, që mbron të drejtën e fëmijës për jetë familjare, mbështet sistemin e drejtësisë familjare dhe ndihmon shërbimet publike të ndërhyjnë herët. Gjithçka është e ankoruar në Nenin 9 të Konventës së Kombeve të Bashkuara për të Drejtat e Fëmijës, që garanton të drejtën e fëmijës për të mbajtur kontakte të rregullta me të dy prindërit, përveçse kur kjo bie ndesh me interesin e tij më të lartë.

---

### 2\. Historia Pas Kubit

Nga largësia e një prindi te e drejta e çdo fëmije për t’u dëgjuar

Kubi i Historive lindi nga një përvojë e jetuar: një prind të cilit iu ndalua të fliste me fëmijën e tij për gati një muaj. Thirrje të devijuara, mesazhe pa përgjigje. Çastet e vogla të përditshme — çfarë pe sot? të pëlqeu? çfarë vizatove? — që veniten në heshtje.

Më pas erdhi një ndërgjegjësim i dhimbshëm: problemi nuk është mungesa e një aplikacioni apo një telefoni i ngadaltë. Problemi është se kontakti i një fëmije me njërin prej prindërve shpesh trajtohet si privilegj i dhënë nga tjetri, ndërkohë që në të vërtetë është një e drejtë që i përket vetë fëmijës.

“Fëmijët kanë nevojë për zë. Ata kanë të drejta. Komunikimi me prindin që nuk është kujdestari kryesor duhet të jetë një zgjedhje e fëmijës — jo diçka e filtruar nga një ndërmjetës.”

Kubi e kthen këtë ide në një objekt fizik: një kuti druri e punuar bukur, me ekran, mikrofon, altoparlant dhe lidhje LTE të integruara në një njësi të vetme. Ai jeton në dhomën e fëmijës. Nuk mund të bllokohet, devijohet apo ripërdoret. Mbart vetëm zërin dhe historitë e prindit që e do — dhe asgjë tjetër nga interneti.

**Nuk është një aplikacion** **I pabllokueshëm** **I drejtuar nga fëmija** **I ngrohtë dhe i sigurt** Një pajisje e dedikuar. Nuk mund të çinstalohet, të pushtohet nga TikTok-u apo të përdoret për çdo gjë tjetër. LTE e integruar garanton që asnjë ndërmjetës të mos mund ta ndërpresë lidhjen. Një buton për të dëgjuar, një buton për të regjistruar. Pa nevojë për leje nga një i rritur në dhomë. Një shok druri pranë shtratit — jo një tjetër ekran që garon për vëmendje.

---

### 3\. Problemi

Ndarja familjare, pengimi i kontaktit dhe dëmi ndaj fëmijëve

Në Shqipëri, realiteti i ndarjes prindërore prek me dhjetëra mijëra fëmijë dhe adoleshentë. Sipas të dhënave të INSTAT-it, në vitin 2023 u regjistruan rreth 3.800 divorce, me një tendencë të lehtë rritjeje vitet e fundit.

**Fëmijët në familje të ndara:** Një pjesë e konsiderueshme e divorceve përfshijnë fëmijë të mitur. Edhe ndarjet e çifteve të pamartuara me fëmijë shtojnë numrin e të miturve që jetojnë vetëm me njërin prind. **Kujdestaria:** Megjithëse Kodi i Familjes parashikon ushtrimin e përbashkët të përgjegjësisë prindërore, në praktikë fëmijët shpesh i besohen nënës, ndërsa kontakti me babain mund të jetë i kufizuar ose i penguar. Gjykatat po orientohen gjithnjë e më shumë drejt kujdestarisë së përbashkët, por pengesat kulturore dhe praktike mbeten. **Mbingarkesa e sistemit të drejtësisë:** Gjykatat shqiptare përballen me një numër të lartë çështjesh familjare dhe procese të zgjatura, çka dëmton mirëqenien e fëmijëve. **Sistemi i mbrojtjes:** Agjencia Shtetërore për Mbrojtjen e të Drejtave të Fëmijëve dhe Njësitë e Mbrojtjes së Fëmijëve në bashki janë krijuar për të garantuar mbrojtjen e fëmijëve. Megjithatë, sistemi ka sfida të shumta për të ofruar shërbime parandaluese dhe mbështetëse për të gjitha familjet.

**Ku dështojnë mjetet aktuale**

**Telefonat dhe aplikacionet kontrollohen lehtësisht.** Prindi rezident mund të fshijë, kufizojë ose monitorojë komunikimin. Zëri i prindit tjetër nuk arrin kurrë te fëmija. **Ekranet e zakonshme janë toksike për fëmijët e vegjël.** Përmbajtjet e drejtuara nga algoritmet dhe reklamat janë krijuar për të kapur vëmendjen, jo për të ushqyer lidhjen e sigurt. **Fëmijët nuk kanë zë të drejtpërdrejtë.** Ata varen nga pajisja e dikujt tjetër, nga orari i dikujt tjetër dhe shpesh flasin nën vëzhgim. **Prindërit jo-rezidentë nuk kanë mbështetje të aksesueshme.** Sistemi i drejtësisë familjare është i shtrenjtë dhe i vështirë për t’u naviguar i vetëm.

Përtej familjeve individuale, shteti ka një boshllëk strukturor: nuk ekziston një mjet gjerësisht i disponueshëm dhe i shkallëzueshëm për të mbështetur të drejtën e fëmijës për jetë familjare. Kubi i Historive është projektuar për të mbushur këtë boshllëk — jo si bamirësi, por si një instrument efektiv i mbrojtjes publike dhe ndërhyrjes së hershme.

---

### 4\. Zgjidhja: Kubi i Historive

Një kub druri. Ekran, mikrofon dhe altoparlant të integruar. Një qëllim i vetëm.

Kubi është qëllimisht radikal në thjeshtësinë e tij. Është një pajisje unike dhe autonome. Bën vetëm atë që duhet të bëjë dhe e bën me ngrohtësi e kujdes.

**Regjistro:** Një buton i kuq. Fëmija flet, prindi tjetër merr. **Dëgjo:** Një buton i gjelbër. Zëri i njeriut që e do, menjëherë. **Shpërnda në TV:** Zëvendëso karikaturat pasive me histori që familja i ka krijuar së bashku. **Re e dyfishtë:** LTE e integruar do të thotë se lidhja nuk mund të ndërpritet. Të dy prindërit kanë gjithmonë akses të sigurt. **Prodhuar nga druri i certifikuar FSC.** Tema të personalizueshme — hapësirë, kafshë, përralla. **Platformë për prindërit:** Një aplikacion ueb për të ngarkuar ilustrime, për të zgjedhur tema dhe për të aksesuar një paketë veglash për navigim ligjor.

**Ku jemi sot:** Një MVP dixhital funksional tashmë punon në çdo shfletues — me motorë historish 2D dhe 3D, komanda zanore dhe gjurmim trupi — duke i lejuar familjet e para të testojnë menjëherë përvojën në një tablet ose telefon. Ky është embrioni i Kubit fizik, tani në zhvillim, që do të sjellë gjithë këtë aftësi në një pajisje të vetme autonome prej druri.

**Çfarë nuk është:** Nuk është një tablet. Nuk është një aplikacion telefoni. Nuk është një ekran YouTube-i. Nuk është asgjë që mund të devijohet, bllokohet ose mbushet me përmbajtje që prindërit nuk e kanë zgjedhur. Disiplina e Kubit është forca e tij më e madhe.

---

### 5\. Kush Përfiton

Fëmijët, prindërit, sistemi i drejtësisë familjare, forcat e rendit, bashkitë dhe shoqëria në tërësi

**Për fëmijën**

- **Siguri emocionale:** Dëgjimi i zërit të prindit që mungon çdo ditë ndihmon në ruajtjen e lidhjes së sigurt dhe mbron shëndetin mendor.  
- **Kohë e shëndetshme para ekranit:** Pa algoritme, pa reklama, pa përmbajtje të dëmshme — vetëm historitë që zgjedh familja.  
- **Një zë i vetin:** Fëmija mund të kontaktojë kur të dojë. Jo kur i lejohet. Jo nën mbikëqyrje.  
- **Rituali i gjumit:** Një histori e regjistruar nga prindi tjetër zëvendëson ankthin e ndarjes me rehati.

**Për prindin jo-rezident**

- **Prani e pabllokueshme:** LTE garanton që çdo mesazh arrin te fëmija. Asnjë aplikacion për t’u fshirë.  
- **Mbështetje për navigim ligjor:** Një portal i sigurt në internet me udhëzues në shqip të qartë, modele për deklarata dhe një arkiv provash — duke ndihmuar palët ndërgjyqëse të navigojnë sistemin gjyqësor. Plotëson, por nuk zëvendëson, këshillimin e pavarur ligjor.  
- **Regjistër i dokumentuar:** Çdo ndërveprim regjistrohet me datë dhe orë, duke siguruar provë objektive të kujdesit të vazhdueshëm prindëror për procedurat gjyqësore.  
- **Prindërim krijues:** Ngarkoni vizatime, ndërtoni histori të animuara, personalizoni Kubin për fëmijën.

**Për Gjykatat e Familjes dhe Prokurorinë**

- **Kanal komunikimi i verifikueshëm:** Kubi mund të urdhërohet nga gjykata si një mënyrë për të lehtësuar kontaktin — një kanal objektiv, të auditueshëm dhe të lirë nga ndërhyrjet.  
- **Regjistër i angazhimit prindëror:** Regjistrat me datë dhe orë zëvendësojnë narrativat kontradiktore me të dhëna. Gjyqtarët dhe prokurorët shohin saktësisht se sa shpesh u lidh një prind dhe çfarë ndau.  
- **Zvogëlimi i proceseve gjyqësore:** Kur kontakti regjistrohet objektivisht, mosmarrëveshjet mbi pengimin dhe mospërmbushjen zvogëlohen, duke çliruar kohë gjyqësore dhe duke reduktuar armiqësinë.

**Për Agjencinë Shtetërore për Mbrojtjen e të Drejtave të Fëmijëve, Shërbimin Social Shtetëror dhe Bashkitë**

- **Ndërhyrje e hershme në konfliktet familjare:** Kubi mund të zbatohet si pjesë e një strategjie parandaluese, duke reduktuar thirrjet e përsëritura në shërbime dhe referimet në mbrojtjen e fëmijës.  
- **Prova për hetimet mbrojtëse dhe penale:** Në rastet kur një prind përdor fëmijën për të kontrolluar tjetrin, regjistri i pandryshueshëm i Kubit mund të shërbejë si provë — dhe mund të konfigurohet që të lejojë vetëm kontakt të sigurt dhe të monitoruar kur ekziston rrezik.  
- **Kursim i kostove:** Çdo familje e mbështetur në këtë fazë të hershme shmang përshkallëzimin drejt procedurave mbrojtëse, strehimit institucional ose drejtësisë penale — duke kursyer mijëra euro për rast dhe duke parandaluar dëme ndërbrezore.

**Për universitetet dhe qendrat kërkimore** Kubi funksionon gjithashtu si infrastrukturë kërkimore mbi ndikimin e pengimit të kontaktit në zhvillimin e fëmijës. Përmes partneriteteve me universitete shqiptare (Universiteti i Tiranës, Universiteti i Shkodrës, etj.), ai mund të gjenerojë të dhëna gjatësore mbi mirëqenien emocionale, përvetësimin e gjuhës dhe lidhjen e sigurt — duke e kthyer përvojën e jetuar në prova të publikuara që formësojnë politikat publike.

**Për shoqërinë** Thyerja e lidhjeve familjare krijon kosto ndërbrezore: shkallë më të larta problemesh të shëndetit mendor, braktisje shkollore, përdorim substancash dhe delikuencë të miturish. Çdo familje që mbetet e lidhur është një qelizë sociale e forcuar. Kubi i Historive vepron në pikën e parandalimit — duke garantuar që një lidhje dashurie t’i mbijetojë ndarjes, duke reduktuar vuajtjen e fëmijëve dhe duke penguar përkeqësimin e dëmit. Kthimi social i këtij investimi matet jo në tremujorë, por në breza.

---

### 6\. Rruga Institucionale

Një strukturë jofitimprurëse në shërbim të misionit

Kubi i Historive do të themelohet si organizatë jofitimprurëse (Organizatë Jo-Fitimprurëse – OJF) sipas Kodit Civil shqiptar dhe legjislacionit përkatës. Të gjitha burimet e gjeneruara — qoftë nga grante, kontrata apo donacione — do të riinvestohen plotësisht në mision: prodhimin e më shumë Kubeve, përmirësimin e platformës, financimin e kërkimit të pavarur dhe zgjerimin në zona të reja.

Qeverisja do të ushtrohet nga një bord drejtues me përvojë në mbrojtjen e fëmijëve, të drejtën familjare, etikën dixhitale dhe ofrimin e shërbimeve publike. Organizata, në kohën e duhur, mund të kërkojë regjistrimin si organizatë me status të veçantë pranë autoriteteve tatimore për të lehtësuar partneritetin me sektorin publik, përfshirë mundësinë për të lidhur marrëveshje bashkëpunimi me shtetin.

Kubi i Historive nuk u përket aksionarëve. I përket kauzës.

---

### 7\. Ekosistemi i Mbështetjes

Burime financimi në Shqipëri, partneritete dhe një strategji në tre faza

Si një mjet jofitimprurës i projektuar për sektorin publik, Kubi i Historive mund të përdorë një kombinim të larmishëm burimesh:

#### A. Financime Publike Kombëtare

- **Ministria e Shëndetësisë dhe Mbrojtjes Sociale (MSHMS):** Nëpërmjet Shërbimit Social Shtetëror dhe programeve të mbrojtjes sociale, Ministria mund të financojë pilotimin e Kubit si një shërbim inovativ për familjet. Buxheti i shtetit ka linja për mbrojtjen e fëmijëve dhe mbështetjen e familjes.  
- **Fondi Social:** Një mekanizëm shtetëror që financon shërbime sociale të ofruara nga bashkitë dhe OJF-të. Ministria shpall thirrje vjetore për propozime. Kubi mund të propozohet si “Shërbim Dixhital i Kontaktit Familjar”.  
- **Buxhetet e Bashkive (61 bashki):** Bashkitë e mëdha (Tiranë, Durrës, Elbasan, Shkodër) kanë buxhete të dedikuara për shërbimet sociale dhe Njësitë e Mbrojtjes së Fëmijëve. Një kontratë e drejtpërdrejtë shërbimi mund të financojë një pilot.

#### B. Fondet e Bashkimit Evropian (Para-aderim dhe të Drejtpërdrejta)

- **IPA III (2021–2027):** Shqipëria përfiton 597 milionë euro. Dritaret tematike përfshijnë sundimin e ligjit, të drejtat themelore dhe përfshirjen sociale. Financimi i Kubit mund të bëhet përmes programeve vjetore të veprimit ose thirrjeve të Delegacionit të BE-së në Tiranë për shoqërinë civile. Grante deri në 500.000 €.  
- **Erasmus+ (Partneritetet e Kapaciteteve):** Si vend partner, Shqipëria mund të marrë pjesë në projekte që zhvillojnë mjete inovative për të rinjtë. Një konsorcium me një OJF evropiane mund të financojë trajnimin e prindërve dhe kurrikulën e përdorimit të Kubit.  
- **CERV – Daphne dhe të Drejtat e Fëmijëve:** Organizatat shqiptare janë të pranueshme si partnere. Një projekt transnacional me Itali ose Greqi mund të financojë pilotimin e Kubit në kontekste ndërkufitare ose dhune në familje.

#### C. Kombet e Bashkuara dhe Organizatat Ndërkombëtare

- **UNICEF Shqipëri:** Programi aktual synon forcimin e sistemit të mbrojtjes së fëmijëve. UNICEF mund të japë financim fillestar për një pilot në dy bashki, të mbulojë koston e vlerësimit të pavarur dhe të ndihmojë integrimin në sistemin shtetëror.  
- **PNUD Shqipëri:** Mbështet aksesin në drejtësi dhe programet kundër dhunës në familje. Kubi mund të pilotohet në mekanizmin e reagimit të koordinuar kundër dhunës si mjet kontakti i sigurt.  
- **OSBE Prezenca në Shqipëri:** Financon projekte të vogla që përmirësojnë funksionimin e gjykatave dhe të drejtat e fëmijëve. Një grant i vogël për të zhvilluar paketën e navigimit ligjor në shqip dhe trajnimin e gjyqtarëve.  
- **Bashkëpunimi Zviceran (SDC) / Ambasada Suedeze (SIDA):** Financojnë projekte të shoqërisë civile për përfshirjen sociale dhe të drejtat e njeriut. Kubi në kontekstin e migracionit (familjet e ndara nga emigracioni) është tërheqës.

#### D. Sektori Filantropik dhe Privat Shqiptar

- **Fondacionet e bankave:** BKT, Raiffeisen Bank, Intesa Sanpaolo Bank Albania kanë programe CSR për fëmijë dhe komunitet. Një bankë mund të sponsorojë blerjen e Kubeve për familje në nevojë.  
- **Fondacioni Vodafone Albania / One Albania:** Mund të sigurojnë lidhjen LTE dhe financimin e platformës cloud si një projekt “tek për të mirën”.  
- **Partners Albania / Fondacioni Së Bashku:** Ndërmjetës që shpërndajnë grante të vogla nga donatorë ndërkombëtarë për OJF-të lokale. Të përshtatshme për një pilot të vogël fillestar (5.000–20.000 €).  
- **Filantropia e diasporës:** Diaspora shqiptare në Itali, Greqi, SHBA është e interesuar për projekte familjare. Një fushatë crowdfunding mund të financojë grupin e parë të Kubeve.

#### E. Kërkimi dhe Partneritetet Universitare

- **Universiteti i Tiranës – Fakulteti i Shkencave Sociale:** Partneritet kërkimor për vlerësimin gjatësor të ndikimit në lidhjen e sigurt dhe gjuhë. Universiteti mund të jetë bashkë-aplikant për grante Erasmus+ ose Horizon Europe.  
- **Instituti i Shëndetit Publik:** Për të shtuar Kubin në një pilot të shëndetit mendor të fëmijëve, financuar nga MSHMS.

#### F. Strategjia e Financimit në Tri Faza

**Fara (Vitet 1–2) — Synimi: €60.000–€120.000**

- Grant i vogël nga UNICEF Shqipëri ose Partners Albania (përmes thirrjeve të BE-së) për përkthimin e platformës në shqip, prodhimin e 20–30 prototipave dhe një pilot në dy Njësi të Mbrojtjes së Fëmijëve (Tiranë dhe një bashki tjetër).  
- Vodafone Albania Foundation: lidhje interneti dhe mbështetje cloud.  
- Marrëveshje me Fakultetin e Shkencave Sociale për hartimin e vlerësimit.

**Pilotimi dhe Provat (Vitet 3–4) — Synimi: €400.000–€700.000**

- Thirrje e Delegacionit të BE-së për Shoqërinë Civile, me një konsorcium OJF shqiptare \+ ETS italiane, për një pilot me 200 Kube në 5 bashki.  
- Grant nga SDC për dimensionin e migracionit.  
- Kontratë me Shërbimin Social Shtetëror për integrimin e Kubit në paketën standarde të kontaktit të mbikëqyrur, financuar nga Fondi Social.

**Shkalla dhe Infrastruktura Publike (Viti 5 e tutje) — Synimi: \>1 milion € në vit**

- Kubi përfshihet në Planin Kombëtar të Veprimit IPA III si pjesë e programit të deinstitucionalizimit.  
- Ministria e Drejtësisë dhe Këshilli i Lartë Gjyqësor lëshojnë një udhëzim për përdorimin e Kubit si mjet standard në çështjet familjare.  
- Projekte transnacionale Horizon Europe për eksportimin e modelit në Kosovë, Maqedoni të Veriut dhe Mal të Zi.

---

### 8\. Përafrimi me Kuadrin Ligjor dhe Mbrojtës Shqiptar

Kubi i Historive është projektuar për t’u vendosur në kryqëzimin e arkitekturës ligjore dhe mbrojtjes së fëmijëve në Shqipëri:

- **Kushtetuta e Shqipërisë:** Njeh mbrojtjen e veçantë të fëmijëve nga shteti dhe të drejtën e tyre për të pasur marrëdhënie personale me të dy prindërit.  
- **Konventa e OKB-së për të Drejtat e Fëmijës:** Ratifikuar në vitin 1992\. Neni 9 garanton të drejtën e fëmijës për të mbajtur kontakte të rregullta me të dy prindërit.  
- **Kodi i Familjes (Ligji Nr. 9062/2003, i ndryshuar):** Neni 219 përcakton që fëmija ka të drejtë të mbajë marrëdhënie personale dhe kontakte të drejtpërdrejta me secilin prind pas ndarjes. Prindërit ushtrojnë bashkërisht përgjegjësinë prindërore.  
- **Ligji për të Drejtat dhe Mbrojtjen e Fëmijës (Ligji Nr. 18/2017):** Forcon sistemin institucional të mbrojtjes së fëmijëve, krijon Agjencinë Shtetërore për Mbrojtjen e të Drejtave të Fëmijëve dhe Njësitë e Mbrojtjes së Fëmijëve në bashki. Mandaton shtetin të mbështesë prindërit dhe të parandalojë institucionalizimin.  
- **Ligji për Masat Kundër Dhunës në Marrëdhëniet Familjare (Ligji Nr. 9669/2006, i ndryshuar):** Siguron urdhra mbrojtjeje. Në raste dhune, kontakti duhet të jetë i sigurt dhe i monitoruar. Kubi ofron regjistër të pandryshueshëm dhe mundësi për modalitet të mbikëqyrur.  
- **Agjenda Kombëtare për të Drejtat e Fëmijëve 2021–2026:** Në linjë me Garancinë Evropiane për Fëmijët, prioritizon deinstitucionalizimin, forcimin e familjes dhe aksesin në shërbime.

---

### 9\. Harta Rrugore Pesëvjeçare

Nga koncepti te infrastruktura kombëtare

| Faza | Periudha | Aktivitetet Kryesore | Objektivat |
| :---- | :---- | :---- | :---- |
| **1\. Themelimi** | 0–12 muaj | Themelimi i OJF-së. Përfundimi i prototipit të parë fizik të Kubit (ekran, audio, LTE). Sigurimi i financimit fillestar. Formalizimi i partneritetit kërkimor me një universitet shqiptar. | Ent ligjor i regjistruar. Prototip funksional gati. 3 partneritete strategjike. |
| **2\. Piloti** | 12–24 muaj | Implementimi i 100–150 Kubeve në 2–3 bashki, të integruar me Njësitë e Mbrojtjes së Fëmijëve dhe Gjykatat e Familjes. Mbledhja e të dhënave mbrojtëse dhe të mirëqenies. Publikimi i vlerësimit të parë. | 150 familje të mbështetura. Raport i parë i pavarur vlerësimi. |
| **3\. Provat** | 24–36 muaj | Publikim i rishikuar nga kolegët i rezultateve. Adoptim nga Shërbimi Social Shtetëror. Zgjerim në 10 bashki. | 2 artikuj akademikë. Kontratë me të paktën një bashki/Shërbim Social. |
| **4\. Shkalla** | 36–48 muaj | 50+ bashki. Përdorim formal në vendimet gjyqësore. Ekip prej 25+ personash. | 10.000 Kube të implementuara. 5 juridiksione që përdorin të dhënat e Kubit. |
| **5\. Infrastruktura Publike** | 48–60 muaj | Kubi njihet si pjesë e infrastrukturës kombëtare të drejtësisë familjare dhe mbështetjes së hershme. Bashkëfinancim nga qeveria qendrore dhe fondet e BE-së. Pilote ndërkombëtare. | 50.000+ Kube. Udhëzim politik i lëshuar. Njohje ndërkombëtare. |

---

### 10\. Bashkohu me Këtë Lëvizje

Porosit, hulumto, mbro, krijo, drejto

“Çdo fëmijë meriton të dëgjojë zërin e dikujt që e do. Çdo prind meriton të arrijë fëmijën e tij. Kubi i Historive e bën këtë të mundur — me thjeshtësi, siguri dhe ngrohtësi.”

Ne po ndërtojmë më shumë se një pajisje. Po ndërtojmë një lëvizje për të drejtat e fëmijëve, të bazuar në prova dhe të projektuar për sektorin publik.

Qofshi kryetar bashkie, drejtues i Njësisë së Mbrojtjes së Fëmijëve, gjyqtar i familjes, prokuror, studiues akademik, shërbim mbështetës për viktimat e dhunës, apo prind që e njeh këtë luftë nga afër — ka një vend për ju në këtë punë.

- **Porosit:** Bashki dhe Njësi të Mbrojtjes së Fëmijëve: testoni Kubin në zonën tuaj si pjesë të strategjisë së mbështetjes së hershme ose mbrojtjes publike.  
- **Hulumto:** Universitete: vendosni partneritete për të vlerësuar ndikimin në mirëqenien e fëmijëve, lidhjen e sigurt dhe zhvillimin e gjuhës.  
- **Mbro:** Profesionistë të së drejtës familjare dhe gjykatave: ndihmoni në formësimin e Kubit si një mjet i njohur për kontaktin dhe provën.  
- **Krijo:** Ilustrues, rrëfimtarë dhe animatorë: kontribuoni në një bibliotekë të hapur temash dhe historish.  
- **Drejto:** Bashkohuni me bordin tonë drejtues. Ndihmoni në udhëheqjen e organizatës me transparencë dhe rigorozitet.

---

**Kubi i Historive (Story Cube)** Lidhje që transformon — një urë dashurie mes prindërve dhe fëmijëve Në përputhje me Konventën e Kombeve të Bashkuara për të Drejtat e Fëmijës · Neni 9 Organizatë jofitimprurëse shqiptare në formim E krijuar me kujdes për familjet kudo  
