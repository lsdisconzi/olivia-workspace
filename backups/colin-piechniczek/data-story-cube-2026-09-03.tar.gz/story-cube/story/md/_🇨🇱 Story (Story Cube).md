# Cubo de Historias (Story Cube)

**Visión y Hoja de Ruta de Impacto – Chile**  
*Documento v3.1 · 2026 · Español*

*“La vida debe aplicarse a una causa, no a las cosas.”*  
Ese espíritu impulsa el Story Cube: una iniciativa que no busca retorno financiero, sino la restauración de un derecho fundamental: el vínculo entre un niño o niña y el padre o la madre que le ama, incluso cuando viven separados.

---

## 1\. Por Qué Existe Esto

Cuando un niño es mantenido lejos de uno de sus progenitores —por distancia, separación u obstrucción deliberada— pierde algo insustituible: el sonido cotidiano de la persona que le ama.

El Story Cube no es un producto que genere impacto social como efecto secundario. Es una misión social que utiliza la tecnología como herramienta. Su forma institucional natural es, por tanto, una **organización sin fines de lucro**, donde el propósito gobierna la estructura y no al revés.

Este documento establece la visión y el camino para transformar el Story Cube en un movimiento de interés público: una herramienta escalable, basada en evidencia, que protege el derecho del niño a la vida familiar, apoya al sistema de justicia y ayuda a los servicios públicos a intervenir de manera temprana. Todo ello anclado en el **Artículo 9 de la Convención de las Naciones Unidas sobre los Derechos del Niño**, que garantiza el derecho del niño a mantener contacto regular con ambos progenitores, salvo que ello sea contrario a su interés superior.

---

## 2\. La Historia Detrás del Cubo

**De la distancia de un progenitor al derecho de cada niño a ser escuchado**

El Story Cube nació de una experiencia vivida: un progenitor impedido de hablar con su hijo durante casi un mes. Llamadas desviadas, mensajes sin respuesta. Los pequeños momentos cotidianos —*¿qué viste hoy? ¿te gustó? ¿qué dibujaste?*— desaparecían en el silencio.

Lo que siguió fue una dolorosa constatación: el problema no es una aplicación faltante ni un teléfono lento. El problema es que el contacto de un niño con uno de sus progenitores se trata muchas veces como un privilegio concedido por el otro, cuando en realidad es un derecho que pertenece al propio niño.

*“Los niños necesitan voz. Tienen derechos. La comunicación con el progenitor que no es el cuidador principal debería ser una elección del niño, no algo filtrado por un intermediario.”*

El Cube transforma esa idea en un objeto físico: una caja de madera hermosamente trabajada, con pantalla, micrófono, altavoz y conectividad LTE integrados en una sola unidad. Vive en la habitación del niño. No puede ser bloqueado, desviado ni reutilizado. Transporta solo la voz y las historias del progenitor que le ama —y nada más de internet.

| No es una app | Inbloqueable | Liderado por el niño | Acogedor y seguro |
| :---- | :---- | :---- | :---- |
| Un dispositivo dedicado. No puede desinstalarse, secuestrarse por TikTok ni usarse para otra cosa. | LTE integrado garantiza que ningún intermediario pueda cortar la conexión. | Un botón para escuchar, un botón para grabar. Sin necesidad de permiso de un adulto en el entorno. | Un compañero de madera al lado de la cama —no una pantalla más compitiendo por la atención. |

---

## 3\. El Problema

**Separación familiar, obstrucción del contacto y el daño a la niñez**

En Chile, la realidad de la separación parental afecta a miles de niños, niñas y adolescentes. En **2023 se registraron más de 60.000 divorcios** en el país, una cifra que se ha mantenido elevada durante la última década.

- **Niños en familias separadas:** Aunque no existe un dato único consolidado, el alto número de divorcios indica que decenas de miles de niños viven en hogares con padres separados. Según la Encuesta Casen 2022, el **14,4 % de los menores de 18 años se encuentra en situación de pobreza multidimensional**, lo que agrava la vulnerabilidad de las familias que atraviesan una ruptura.  
- **Cuidado personal compartido y relación directa y regular:** La Ley N° 20.680 (2013) fortaleció la corresponsabilidad parental, estableciendo el cuidado personal compartido como una opción preferente cuando ambos progenitores están de acuerdo o el tribunal lo determina en beneficio del niño. Sin embargo, en la práctica, miles de causas por régimen comunicacional (relación directa y regular) colapsan anualmente los Tribunales de Familia. Según datos del Poder Judicial, en 2023 ingresaron más de **100.000 causas** relacionadas con cuidado personal y relación directa y regular.  
- **Sobrecarga del sistema de justicia:** Los Tribunales de Familia enfrentan una altísima carga de trabajo; los procesos de relación directa y regular pueden prolongarse durante meses o años, agravando el distanciamiento afectivo.  
- **Sistema de protección a la niñez:** Chile cuenta con un renovado Sistema de Garantías y Protección Integral de los Derechos de la Niñez y Adolescencia, creado por la **Ley N° 21.430 (2022)** , que mandata al Estado a garantizar el derecho a la vida familiar y al contacto regular con ambos padres. La nueva institucionalidad incluye la **Subsecretaría de la Niñez**, el **Servicio Nacional de Protección Especializada a la Niñez y Adolescencia (Mejor Niñez)** y la **Defensoría de la Niñez**.

**Dónde fallan las herramientas actuales**

- **Teléfonos y aplicaciones son controlables.** El progenitor residente puede eliminar, restringir o monitorear la comunicación. La voz del otro progenitor nunca llega al niño.  
- **Las pantallas comunes son tóxicas para niños pequeños.** Los contenidos guiados por algoritmos y la publicidad están diseñados para capturar atención, no para nutrir el apego.  
- **Los niños no tienen voz directa.** Dependen del dispositivo de otra persona, del horario de otra persona y, muchas veces, hablan bajo observación.  
- **Los progenitores no residentes carecen de apoyo accesible.** El sistema de justicia familiar puede ser caro y difícil de navegar sin asistencia letrada.

Más allá de las familias individuales, el Estado tiene una brecha estructural: no existe una herramienta ampliamente disponible y escalable para ayudar a defender el derecho del niño a la convivencia familiar. El Story Cube fue diseñado para llenar esa brecha —no como caridad, sino como un instrumento eficaz de protección pública e intervención temprana.

---

## 4\. La Solución: El Story Cube

**Un cubo de madera. Pantalla, micrófono y altavoz integrados. Un único propósito.**

El Cube es deliberadamente radical en su simplicidad. Es un dispositivo único y autónomo. Hace solo lo que debe hacer, y lo hace con calidez y cuidado.

- **Grabar:** Un botón rojo. El niño habla, el otro progenitor recibe.  
- **Escuchar:** Un botón verde. La voz de la persona que le ama, instantáneamente.  
- **Compartir en la TV:** Sustituir los dibujos animados pasivos por historias que la familia creó junta.  
- **Doble nube:** LTE integrado significa que la conexión no puede ser cortada. Ambos progenitores tienen siempre acceso seguro.  
- **Fabricado en madera certificada FSC.** Temas personalizables —espacio, animales, cuentos de hadas.  
- **Plataforma para progenitores:** Una aplicación web para enviar ilustraciones, elegir temas y acceder a un kit de herramientas de orientación legal.

**Dónde estamos hoy:** Un MVP digital funcional ya opera en cualquier navegador —con motores de historias 2D y 3D, comandos de voz y seguimiento corporal— permitiendo que las primeras familias prueben la experiencia de inmediato en una tablet o teléfono. Este es el embrión del Cube físico, que está ahora en desarrollo y traerá toda esa capacidad a un único dispositivo autónomo de madera.

**Lo que no es:** No es una tablet. No es una app de teléfono. No es una pantalla de YouTube. No es nada que pueda ser desviado, bloqueado o llenado con contenido que los progenitores no hayan elegido. La disciplina del Cube es su mayor fortaleza.

---

## 5\. Quiénes se Benefician

**Niños, progenitores, el sistema de justicia, municipalidades, fuerzas de seguridad y la sociedad en su conjunto**

### Para el niño

- **Seguridad emocional:** Escuchar la voz del progenitor ausente cada día ayuda a preservar el apego seguro y protege la salud mental.  
- **Tiempo de pantalla saludable:** Sin algoritmos, sin anuncios, sin contenido perjudicial —solo las historias que la familia elige.  
- **Una voz propia:** El niño puede contactar cuando quiera. No cuando se lo permiten. No bajo vigilancia.  
- **Ritual de hora de dormir:** Una historia grabada por el otro progenitor reemplaza la ansiedad de la separación por el consuelo.

### Para el progenitor no residente

- **Presencia inbloqueable:** El LTE garantiza que cada mensaje llegue al niño. Ninguna app para ser eliminada.  
- **Apoyo a la orientación legal:** Un portal web seguro con guías en lenguaje claro, modelos para escritos judiciales y un archivo de evidencias —ayudando a las personas a navegar el sistema judicial. Complementa, pero no sustituye, la asesoría legal independiente.  
- **Registro documentado:** Cada interacción queda registrada con fecha y hora, proporcionando prueba objetiva de cuidado parental continuo para procedimientos judiciales.  
- **Parentalidad creativa:** Enviar dibujos, construir historias animadas, personalizar el Cube para el niño.

### Para el Poder Judicial (Tribunales de Familia) y el Ministerio Público

- **Canal de comunicación verificable:** El Cube puede ser ordenado por el juez como forma de facilitar el contacto —un canal objetivo, auditable y libre de interferencias.  
- **Registro de involucramiento parental:** Los registros con fecha y hora sustituyen narrativas contradictorias por datos. Jueces y fiscales ven exactamente con qué frecuencia un progenitor se conectó y qué compartió.  
- **Reducción de la litigiosidad:** Cuando el contacto está registrado objetivamente, las disputas sobre obstrucción e incumplimiento disminuyen, liberando tiempo judicial y reduciendo la animosidad.

### Para las Municipalidades, las Oficinas Locales de Niñez (OLN) y las fuerzas de seguridad

- **Intervención temprana en conflictos familiares:** El Cube puede implementarse como parte de una estrategia de prevención, reduciendo llamadas reiteradas a Carabineros, derivaciones al sistema de protección y demandas judiciales.  
- **Evidencia para investigaciones de protección y penales:** En casos donde un progenitor utiliza al niño para controlar al otro, el registro inmutable del Cube puede servir como prueba —y puede configurarse para permitir solo contacto seguro y monitoreado cuando existe riesgo.  
- **Ahorro de costos:** Cada familia apoyada en esta fase temprana evita la escalada hacia procedimientos de cuidado alternativo, medidas de protección o causas penales —ahorrando recursos públicos por caso y previniendo daños intergeneracionales.

### Para universidades y centros de investigación

El Cube funciona también como infraestructura de investigación sobre el impacto de la obstrucción del contacto en el desarrollo infantil. Mediante alianzas con universidades chilenas (Universidad de Chile, Pontificia Universidad Católica de Chile, Universidad de Concepción, entre otras), puede generar datos longitudinales sobre bienestar emocional, adquisición del lenguaje y apego —transformando la experiencia vivida en evidencia publicada que moldee las políticas públicas.

### Para la sociedad

La ruptura de los lazos familiares crea costos intergeneracionales: mayores tasas de problemas de salud mental, fracaso escolar, consumo de sustancias y conductas infractoras. Cada familia que permanece conectada es una célula social fortalecida. El Story Cube actúa en el punto de la prevención —garantizando que un vínculo de amor sobreviva a la separación, reduciendo el sufrimiento infantil e impidiendo que el daño se agrave. El retorno social de esta inversión no se mide en trimestres, sino en generaciones.

---

## 6\. Camino Institucional

**Una estructura sin fines de lucro al servicio de la misión**

El Story Cube se constituirá como una **organización de la sociedad civil** sin fines de lucro, al amparo de la legislación chilena (especialmente la Ley N° 20.500 sobre Asociaciones y Participación Ciudadana en la Gestión Pública). Podrá adoptar la forma de **corporación o fundación**. Todos los recursos que genere —ya sean subvenciones, contratos o donaciones— se reinvertirán íntegramente en la misión: fabricar más Cubes, mejorar la plataforma, financiar investigación independiente y expandirse a nuevas comunas.

La gobernanza será ejercida por un **directorio** con experiencia en protección de la niñez, derecho de familia, ética digital y prestación de servicios públicos. La organización podrá solicitar su inscripción en el **Registro de Donatarios** del Ministerio de Desarrollo Social y Familia para recibir donaciones con beneficios tributarios, así como postular a los **fondos concursables de la Subsecretaría de la Niñez** y del **Servicio Mejor Niñez**. También podrá celebrar **convenios de colaboración** con municipalidades, tribunales de familia y otros organismos del Estado.

El Story Cube no pertenece a accionistas. Pertenece a la causa.

---

## 7\. Ecosistema de Apoyo

**Fuentes de financiamiento en Chile, alianzas y una estrategia en tres fases**

Como herramienta sin fines de lucro diseñada para el sector público, el Story Cube puede recurrir a una combinación diversificada de recursos:

**A. Financiamiento Público Nacional**

- **Fondo Nacional de la Niñez y Adolescencia:** Fondos concursables de la Subsecretaría de la Niñez (Ministerio de Desarrollo Social y Familia) para proyectos de promoción y protección de derechos de la niñez.  
- **Fondo de Intervención para la Niñez:** Transferencias a municipalidades y organizaciones colaboradoras del Servicio Mejor Niñez, que pueden cofinanciar iniciativas locales.  
- **Fondo de Fortalecimiento de Organizaciones de Interés Público (FFOIP):** Administrado por el Ministerio Secretaría General de Gobierno, financia proyectos de fortalecimiento de la sociedad civil.  
- **Fondos municipales de infancia:** Muchos municipios cuentan con presupuestos participativos o fondos específicos para programas de niñez, donde el Cube puede integrarse a las Oficinas Locales de Niñez (OLN).  
- **Ley de Donaciones con Fines Sociales (Ley N° 19.885):** Permite a empresas y personas deducir impuestos por donaciones a corporaciones y fundaciones inscritas en el Registro de Donatarios.

**B. Fundaciones y Organizaciones Filantrópicas**

- **Fundación Colunga:** Apoyo a iniciativas que fortalecen la sociedad civil y los derechos de la niñez.  
- **Fundación Luksic:** Financiamiento de proyectos sociales y educativos.  
- **Fundación Olivo:** Promoción del bienestar infantil y familiar.  
- **Fundación Telefónica Movistar:** Innovación social y educación digital.  
- **Fundación Mustakis:** Desarrollo integral de niños y jóvenes.  
- **UNICEF Chile:** Socio estratégico en la garantía de derechos de la infancia, con presencia activa en el país.

**C. Cooperación Internacional**

- **UNICEF:** Puede apoyar la validación del modelo y la generación de evidencia.  
- **Agencias de cooperación y organismos multilaterales** con programas en infancia y protección social.

**D. Alianzas Público-Privadas y Donantes Individuales**

- Empresas con programas de responsabilidad social que deseen apadrinar la entrega de Cubes en comunas vulnerables.  
- Donaciones de personas naturales, con posibilidad de acogerse a los beneficios tributarios de la Ley N° 19.885.

**E. Potenciales Instituciones Colaboradoras**

| Tipo de Institución | Entidad Específica |
| :---- | :---- |
| Subsecretaría de la Niñez | Ministerio de Desarrollo Social y Familia |
| Servicio Nacional de Protección Especializada | Mejor Niñez |
| Defensoría de la Niñez | Defensoría de la Niñez |
| Poder Judicial | Tribunales de Familia / Cortes de Apelaciones |
| Ministerio Público | Fiscalías locales / Unidad de Víctimas y Testigos |
| Municipalidades | Oficinas Locales de Niñez (OLN), DIDECO |
| Universidades | U. de Chile, PUC, U. de Concepción, U. Diego Portales, etc. |
| Consejo de la Sociedad Civil de la Niñez | Órgano asesor de la Subsecretaría de la Niñez |

### F. Estrategia en tres fases

1. **Semilla (Años 1–2):** Subvenciones de fundaciones, piloto inicial con una municipalidad y un Tribunal de Familia, alianza académica establecida. Primeros prototipos físicos implementados.  
2. **Sostenibilidad (Años 3–4):** Contratación directa por municipios, adopción por el sistema de garantías (Mejor Niñez y OLN), base de evidencia publicada, expansión a múltiples regiones.  
3. **Escala (Año 5 en adelante):** Implementación nacional con cofinanciamiento del Fondo Nacional de la Niñez, integración en resoluciones judiciales y rutas de protección. Pilotos internacionales en paralelo.

---

## 8\. Alineación con el Marco Legal y de Protección Chileno

El Story Cube está diseñado para situarse en la intersección de la arquitectura legal y de protección de la niñez chilena:

- **Constitución Política de la República, Artículo 1° inciso segundo:** Reconoce a la familia como el núcleo fundamental de la sociedad, deber del Estado protegerla y fortalecerla.  
- **Convención sobre los Derechos del Niño (CDN):** Ratificada por Chile en 1990\. Su **Artículo 9** garantiza el derecho del niño a mantener relaciones personales y contacto directo con ambos padres de modo regular, salvo si es contrario a su interés superior.  
- **Ley N° 21.430 sobre Garantías y Protección Integral de los Derechos de la Niñez y Adolescencia (2022):** Establece el Sistema de Garantías, el interés superior del niño como principio rector, el derecho a la vida familiar y el derecho a mantener una relación directa y regular con ambos progenitores (arts. 21, 22 y 29).  
- **Ley N° 20.680 (2013) que modifica el Código Civil y otros cuerpos legales:** Fortalece la corresponsabilidad parental, establece el cuidado personal compartido como alternativa preferente cuando favorece el interés superior del niño, y regula la relación directa y regular.  
- **Código Civil, artículos 222 y siguientes:** Definen la relación directa y regular como un derecho-deber de los padres y un derecho del hijo, incluso cuando el cuidado personal lo ejerce solo uno de ellos.  
- **Ley N° 19.968 que crea los Tribunales de Familia (2004):** Atribuye a estos tribunales el conocimiento de las causas sobre cuidado personal, relación directa y regular, y medidas de protección.  
- **Ley N° 21.302 que crea el Servicio Nacional de Protección Especializada a la Niñez y Adolescencia (Mejor Niñez, 2021):** Reemplaza al antiguo SENAME en materia de protección, con un enfoque en la intervención temprana y el fortalecimiento familiar.

---

## 9\. Glosario de Términos Legales

| Español | Descripción |
| :---- | :---- |
| **Cuidado personal** | Atribución del cuidado cotidiano del niño a uno o ambos progenitores. Puede ser compartido o exclusivo. |
| **Cuidado personal compartido** | Ambos progenitores ejercen el cuidado del hijo de forma equilibrada, como manifestación de la corresponsabilidad parental. |
| **Relación directa y regular** | Derecho-deber del progenitor que no tiene el cuidado personal a mantener un contacto periódico y estable con su hijo (antes llamado “régimen de visitas”). |
| **Corresponsabilidad parental** | Principio según el cual ambos progenitores, vivan juntos o separados, participan en la crianza y educación de los hijos. |
| **Interés superior del niño** | Principio que orienta todas las decisiones que afectan al niño, priorizando su bienestar y desarrollo integral. |
| **Tribunal de Familia** | Órgano jurisdiccional especializado en asuntos de familia, incluyendo cuidado personal, relación directa y regular, y medidas de protección. |
| **Defensoría de la Niñez** | Organismo autónomo encargado de la promoción y protección de los derechos de niños, niñas y adolescentes. |
| **Oficina Local de Niñez (OLN)** | Unidad municipal creada por la Ley N° 21.430 para la prevención, promoción y protección de derechos de la niñez a nivel comunal. |
| **Mejor Niñez** | Servicio Nacional de Protección Especializada a la Niñez y Adolescencia, responsable de la protección de niños gravemente vulnerados. |
| **Subsecretaría de la Niñez** | Órgano del Ministerio de Desarrollo Social y Familia encargado de las políticas de niñez y del Sistema de Garantías. |

---

## 10\. Hoja de Ruta de Cinco Años

**Del concepto a la infraestructura nacional**

| Fase | Período | Actividades Principales | Hitos |
| :---- | :---- | :---- | :---- |
| **1\. Fundación** | 0–12 meses | Constituir la corporación o fundación sin fines de lucro. Completar el primer prototipo físico del Cube (pantalla, audio, LTE). Obtener financiamiento inicial. Formalizar alianza de investigación con una universidad chilena. | Entidad legal registrada. Prototipo funcional listo. 3 alianzas estratégicas. |
| **2\. Piloto** | 12–24 meses | Implementar 100–150 Cubes en 2–3 comunas, integrados con Oficinas Locales de Niñez y Tribunales de Familia. Recopilar datos de protección y bienestar. Primera evaluación publicada. | 150 familias apoyadas. Primer informe de evaluación independiente. |
| **3\. Evidencia** | 24–36 meses | Publicación revisada por pares de los resultados. Adopción por el Sistema de Garantías (OLN/Mejor Niñez). Expansión a 10 comunas. | 2 artículos académicos. Convenio con al menos una municipalidad o Tribunal de Familia. |
| **4\. Escala** | 36–48 meses | 50+ comunas. Uso formal en resoluciones judiciales. Equipo de 25+ personas. | 10.000 Cubes implementados. 5 jurisdicciones utilizando datos del Cube. |
| **5\. Infraestructura Pública** | 48–60 meses | Cube reconocido como parte de la infraestructura nacional de justicia familiar y apoyo temprano. Cofinanciado por el Fondo Nacional de la Niñez. Pilotos internacionales. | 50.000+ Cubes. Lineamiento de política pública emitido. Reconocimiento internacional. |

---

## 11\. Únase a Este Movimiento

**Comisione, investigue, defienda, cree, gobierne**

*“Todo niño merece escuchar la voz de alguien que le ama.*  
*Todo progenitor merece llegar a su hijo.*  
*El Story Cube lo hace posible —con simplicidad, seguridad y calidez.”*

Estamos construyendo más que un dispositivo. Estamos construyendo un movimiento por los derechos de la niñez, basado en evidencia y diseñado para el sector público.

Sea usted un alcalde, un profesional de una Oficina Local de Niñez, un juez de Familia, un fiscal del Ministerio Público, un investigador académico, un servicio de apoyo a víctimas o un progenitor que conoce esta lucha en carne propia —**hay un lugar para usted en este trabajo.**

- **Comisionar:** Municipalidades, Oficinas Locales de Niñez y Tribunales de Familia: prueben el Cube en su territorio como parte de su estrategia de apoyo temprano o protección pública.  
- **Investigar:** Universidades: establezcan alianzas para evaluar el impacto en el bienestar infantil, el apego y el desarrollo del lenguaje.  
- **Defender:** Abogados de familia, fiscales y jueces: ayuden a moldear el Cube como una herramienta reconocida para el contacto y la evidencia.  
- **Crear:** Ilustradores, narradores y animadores: contribuyan a una biblioteca abierta de temas e historias.  
- **Gobernar:** Únase a nuestro directorio. Ayude a guiar la organización con transparencia y rigor.

---

**Cubo de Historias (Story Cube)**  
*Conexión que transforma — un puente de amor entre padres e hijos*  
Alineado con la Convención de las Naciones Unidas sobre los Derechos del Niño · Art. 9  
Organización de la sociedad civil chilena en formación  
Hecho con cuidado para las familias de todas partes  
