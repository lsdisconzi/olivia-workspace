---

# Cubo de Histórias (Story Cube)

**Visão e Roteiro de Impacto – Portugal** *Documento v3.1 · 2026 · Português (versão inglesa disponível)*

*“A tua vida deve ser aplicada a uma causa, não a coisas.”*  
É este espírito que impulsiona o Story Cube — uma iniciativa que não procura retorno financeiro, mas a restauração de um direito fundamental: o vínculo entre uma criança e o progenitor que a ama, mesmo quando vivem separados.

---

## 1\. Porquê Isto Existe

Quando uma criança é mantida afastada de um progenitor — por distância, separação ou obstrução deliberada — perde algo insubstituível: o som quotidiano da pessoa que a ama.

O Story Cube não é um produto que gera bem social como efeito secundário. É uma missão social que utiliza a tecnologia como ferramenta. A sua forma institucional natural é, portanto, uma **organização sem fins lucrativos** — onde o propósito governa a estrutura, e não o contrário.

Este documento estabelece a visão e o caminho para transformar o Story Cube num movimento de interesse público: uma ferramenta escalável, baseada em evidências, que protege o direito da criança à vida familiar, apoia o sistema de justiça familiar e ajuda os serviços públicos a intervir mais cedo. Tudo ancorado no **Artigo 9.º da Convenção das Nações Unidas sobre os Direitos da Criança**, que garante o direito da criança a manter contacto regular com ambos os progenitores, salvo se tal for contrário ao seu superior interesse.

---

## 2\. A História Por Trás do Cubo

**Da distância de um progenitor ao direito de cada criança a ser ouvida**

O Story Cube nasceu de uma experiência vivida: um progenitor impedido de falar com o seu filho durante quase um mês. Chamadas encaminhadas, mensagens sem resposta. Os pequenos momentos diários — *o que viste hoje? gostaste? o que desenhaste?* — a desaparecerem no silêncio.

Seguiu-se uma dolorosa constatação: o problema não é uma aplicação em falta ou um telefone lento. O problema é que o contacto de uma criança com um dos progenitores é frequentemente tratado como um privilégio concedido pelo outro, quando na verdade é um direito que pertence à própria criança.

*“As crianças precisam de voz. Têm direitos. A comunicação com o progenitor que não é o principal cuidador deve ser uma escolha da criança — não algo filtrado por um intermediário.”*

O Cube transforma essa ideia num objeto físico: uma caixa de madeira lindamente trabalhada, com ecrã, microfone, altifalante e conectividade LTE incorporados numa única unidade. Vive no quarto da criança. Não pode ser bloqueado, desviado ou reutilizado. Transporta apenas a voz e as histórias do progenitor que a ama — e nada mais da internet.

| Não é uma app | Inbloqueável | Liderado pela criança | Acolhedor e seguro |
| :---- | :---- | :---- | :---- |
| Um dispositivo dedicado. Não pode ser desinstalado, sequestrado pelo TikTok ou utilizado para qualquer outra coisa. | LTE integrado garante que nenhum intermediário pode cortar a ligação. | Um botão para ouvir, um botão para gravar. Sem necessidade de permissão de um adulto na sala. | Um companheiro de cabeceira em madeira — não mais um ecrã a competir por atenção. |

---

## 3\. O Problema

**Separação familiar, obstrução de contacto e o dano causado às crianças**

Em Portugal, existem cerca de **1,7 milhões de crianças com menos de 18 anos**, representando 16% da população. Embora dados específicos sobre famílias separadas sejam limitados, as evidências disponíveis revelam uma realidade preocupante:

- **Pobreza infantil:** A taxa de risco de pobreza entre menores de 18 anos foi de **17,6% em 2024**, acima dos 16,6% para o conjunto da população. A situação é particularmente grave nas **famílias monoparentais, onde a pobreza atingia 35,1%**. Cerca de **301 mil crianças** vivem em situação de pobreza em Portugal.  
- **Crianças em acolhimento:** Cerca de **6.000 crianças com menos de 18 anos** encontram-se em acolhimento institucional. Mais de **95% residem em lares de acolhimento residencial** e apenas **2% (cerca de 300 crianças)** estão colocadas em famílias de acolhimento.  
- **Sobrecarga do sistema de proteção:** Em 2023, as Comissões de Proteção de Crianças e Jovens (CPCJ) tramitaram **84.196 processos** de promoção e proteção, um aumento de 7,7% face a 2022\. Foram abertos **42.622 novos processos** pela primeira vez em 2023\.  
- **Sistema judicial sobrecarregado:** Os tribunais judiciais portugueses terminaram 2023 com **mais de 581 mil processos pendentes**. O sistema judicial português falha em proteger as crianças, com processos judiciais morosos que prejudicam aqueles que mais necessitam de salvaguarda.  
- **Violência doméstica:** Apenas **13% das denúncias de violência doméstica** resultaram em condenações em 2023\. As medidas de proteção às vítimas podem incluir a proibição de contacto do agressor.

**Onde as ferramentas atuais falham**

- **Telemóveis e apps são controláveis.** O progenitor residente pode eliminar, restringir ou monitorizar a comunicação. A voz do outro progenitor nunca chega à criança.  
- **Os ecrãs comuns são tóxicos para crianças pequenas.** Conteúdos orientados por algoritmos e publicidade são concebidos para capturar atenção, não para nutrir a vinculação.  
- **As crianças não têm voz direta.** Dependem do dispositivo de outra pessoa, do horário de outra pessoa, e frequentemente falam sob observação.  
- **Os progenitores não residentes carecem de apoio acessível.** O sistema de justiça familiar é caro e difícil de navegar sozinho.

Para além das famílias individuais, o Estado tem uma lacuna estrutural: não existe uma ferramenta amplamente disponível e escalável para ajudar a defender o direito da criança à vida familiar. O Story Cube foi concebido para preencher essa lacuna — não como caridade, mas como um instrumento eficaz de proteção pública e intervenção precoce.

---

## 4\. A Solução: O Story Cube

**Um cubo de madeira. Ecrã, microfone e altifalante integrados. Um único propósito.**

O Cube é deliberadamente radical na sua simplicidade. É um dispositivo único, autónomo. Faz apenas o que precisa de fazer, e fá-lo com calor e cuidado.

- **Gravar:** Um botão vermelho. A criança fala, o outro progenitor recebe.  
- **Ouvir:** Um botão verde. A voz da pessoa que a ama, instantaneamente.  
- **Partilhar na TV:** Trocar desenhos animados passivos por histórias que a família criou em conjunto.  
- **Dupla nuvem:** LTE integrado significa que a ligação não pode ser cortada. Ambos os progenitores têm sempre acesso seguro.  
- **Fabricado em madeira certificada FSC.** Temas personalizáveis — espaço, animais, contos de fadas.  
- **Plataforma para progenitores:** Uma aplicação web para carregar ilustrações, escolher temas e aceder a um kit de ferramentas de navegação legal.

**Onde estamos hoje:** Um MVP digital funcional já funciona em qualquer navegador — com motores de histórias 2D e 3D, comandos de voz e rastreamento corporal — permitindo que as primeiras famílias testem a experiência imediatamente num tablet ou telemóvel. Este é o embrião do Cube físico, que está agora em desenvolvimento e trará toda essa capacidade para um único dispositivo autónomo de madeira.

**O que não é:** Não é um tablet. Não é uma app de telemóvel. Não é um ecrã do YouTube. Não é nada que possa ser desviado, bloqueado ou preenchido com conteúdos que os progenitores não tenham escolhido. A disciplina do Cube é a sua maior força.

---

## 5\. Quem Beneficia

**Crianças, progenitores, o sistema de justiça familiar, forças de segurança, autarquias e a sociedade em geral**

### Para a criança

- **Segurança emocional:** Ouvir a voz do progenitor ausente todos os dias ajuda a preservar a vinculação segura e protege a saúde mental.  
- **Tempo de ecrã saudável:** Sem algoritmos, sem anúncios, sem conteúdos nocivos — apenas as histórias que a família escolhe.  
- **Uma voz própria:** A criança pode contactar quando quiser. Não quando é permitido. Não sob vigilância.  
- **Ritual de hora de dormir:** Uma história gravada pelo outro progenitor substitui a ansiedade da separação pelo conforto.

### Para o progenitor não residente

- **Presença inbloqueável:** O LTE garante que cada mensagem chega à criança. Nenhuma app para ser eliminada.  
- **Apoio à navegação legal:** Um portal web seguro com guias em português simples, modelos para declarações e um arquivo de evidências — ajudando litigantes a navegar no sistema judicial. Complementa, mas não substitui, o aconselhamento jurídico independente.  
- **Registo documentado:** Cada interação é registada com data e hora, fornecendo prova objetiva de cuidado parental contínuo para processos judiciais.  
- **Parentalidade criativa:** Carregar desenhos, construir histórias animadas, personalizar o Cube para a criança.

### Para o Tribunal de Família e Menores, Ministério Público e Magistratura

- **Canal de comunicação verificável:** O Cube pode ser ordenado pelo tribunal como forma de facilitar o contacto — um canal objetivo, auditável e livre de interferências.  
- **Registo de envolvimento parental:** Registos com data e hora substituem narrativas contraditórias por dados. Juízes e procuradores veem exatamente com que frequência um progenitor se conectou e o que partilhou.  
- **Redução de litígios:** Quando o contacto é registado objetivamente, os litígios sobre obstrução e incumprimento diminuem, libertando tempo judicial e reduzindo a animosidade.

### Para as Forças de Segurança e Autarquias

- **Intervenção precoce em conflitos familiares:** O Cube pode ser implementado como parte de uma estratégia de triagem e prevenção, reduzindo chamadas repetidas aos serviços e sinalizações para as CPCJ.  
- **Evidência para investigações de salvaguarda e criminais:** Nos casos em que um progenitor utiliza a criança para controlar o outro, o Cube fornece um registo não filtrado e imutável que pode ser utilizado em investigações ao abrigo da **Lei n.º 112/2009 (violência doméstica)**, que tipifica a violência doméstica como crime punível com 1 a 5 anos de prisão, e onde as medidas de proteção podem incluir a proibição de contacto com a vítima.  
- **Evitamento de custos:** Cada família apoiada nesta fase precoce evita a escalada para processos de proteção estatutária, medidas de acolhimento ou justiça criminal — poupando milhares de euros por caso e prevenindo danos intergeracionais.

### Para universidades e centros de investigação

O Cube funciona também como infraestrutura de investigação sobre o impacto da obstrução de contacto no desenvolvimento infantil. Através de parcerias com universidades portuguesas (e.g., Universidade de Coimbra, Universidade do Porto, ISCTE, Nova SBE), pode gerar dados longitudinais sobre bem-estar emocional, aquisição de linguagem e vinculação — transformando a experiência vivida em evidência publicada que molda políticas públicas.

### Para a sociedade

A rutura dos laços familiares cria custos intergeracionais: maiores taxas de problemas de saúde mental, insucesso escolar, consumo de substâncias e delinquência juvenil. Cada família que permanece conectada é uma célula social fortalecida. O Story Cube atua no ponto da prevenção — garantindo que um vínculo amoroso sobrevive à separação, reduzindo o sofrimento infantil e impedindo que o dano se agrave. O retorno social desse investimento mede-se não em trimestres, mas em gerações.

---

## 6\. Percurso Institucional

**Uma estrutura sem fins lucrativos ao serviço da missão**

O Story Cube será estabelecido como uma **organização sem fins lucrativos** (pessoa coletiva de utilidade pública), nos termos do Código Civil Português. Todos os recursos gerados — sejam de subsídios, contratos ou donativos — são reinvestidos integralmente na missão: fabricar mais Cubes, melhorar a plataforma, financiar investigação independente e expandir para novas áreas.

A governação será exercida por um **conselho diretivo** ou **conselho fiscal** com experiência em proteção de crianças e jovens, direito da família, ética digital e prestação de serviços públicos. A organização pode, em tempo útil, requerer o **estatuto de utilidade pública** ou o **estatuto de IPSS (Instituição Particular de Solidariedade Social)**, o que melhor permita a parceria com o setor público, incluindo a possibilidade de celebrar **acordos de cooperação** com a Segurança Social.

O Story Cube não pertence a acionistas. Pertence à causa.

---

## 7\. Ecossistema de Apoio

**Fontes de financiamento em Portugal, parcerias e uma estratégia em três fases**

Como ferramenta sem fins lucrativos concebida para o setor público, o Story Cube pode recorrer a uma combinação diversificada de recursos:

- **Programa Portugal 2030 (PT2030) / Portugal Inovação Social:** A iniciativa pública pioneira que mobiliza fundos da União Europeia para financiar projetos de inovação social. Inclui **Social Impact Bonds (SIBs)** e **Parcerias para o Impacto (PFI)**, que promovem financiamento baseado em resultados e colaboração público-privada. Já apoiou **178 projetos**, com **483 projetos aprovados** no total e **110 milhões de euros em financiamento**.  
- **Fundo Social Europeu (FSE+):** Portugal recebeu **9,14 mil milhões de euros** em apoio do FSE durante o período 2014-2020.  
- **Ministério do Trabalho, Solidariedade e Segurança Social (MTSSS):** Formulação e execução de políticas para a infância e família. O programa **Creche Feliz** já cobre mais de **128.000 crianças**.  
- **Ministério da Justiça:** Sistema de Mediação Familiar (SMF) e modernização da justiça familiar.  
- **Comissão Nacional de Promoção dos Direitos e Proteção das Crianças e Jovens (CNPDPCJ):** Coordenação das 312 CPCJ a nível nacional.  
- **Autarquias locais:** Contratação de serviços de apoio à família através de orçamentos municipais e das CPCJ.  
- **Fundações e mecenato:** Fundação Calouste Gulbenkian, Fundação Francisco Manuel dos Santos, Fundação Santander (Prémio Inovação Social — 50.000€), Caixa Social Awards (já apoiou 223 projetos com 4,76 milhões de euros), Fundação Amélia de Mello (Bolsa de 150.000€ para inovação social).  
- **Conselhos e fundações:** Fundação para a Ciência e a Tecnologia (FCT) para estudos longitudinais sobre bem-estar infantil.

### Estratégia em três fases

1. **Semente (Anos 1–2):** Subsídios de fundações, piloto inicial com uma autarquia e uma CPCJ, parceria académica estabelecida. Primeiros protótipos físicos implementados.  
2. **Sustentação (Anos 3–4):** Contratação direta por autarquias, adoção por CPCJ, base de evidências publicada, expansão para múltiplas regiões.  
3. **Escala (Ano 5 em diante):** Implementação nacional com cofinanciamento do governo central, integração em decisões judiciais e percursos de salvaguarda. Pilotos internacionais em paralelo.

---

## 8\. Alinhamento com o Quadro Legal e de Salvaguarda Português

O Story Cube é concebido para se situar na interseção da arquitetura legal e de proteção infantil portuguesa:

- **Constituição da República Portuguesa, Artigo 36.º:** Consagra o direito à família, o direito e dever dos pais de educar e manter os filhos, e estabelece que **“os filhos não podem ser separados dos pais, a não ser que estes não cumpram os seus deveres fundamentais para com eles, e sempre mediante decisão judicial”**. O Cube é uma ferramenta prática para defender este direito constitucional.  
- **Lei de Proteção de Crianças e Jovens em Perigo (Lei n.º 147/99, de 1 de setembro):** Estabelece o quadro legal para a intervenção das CPCJ. O Cube fornece evidência direta do que a criança diz e sente, ajudando as entidades a tomar decisões que reflitam a sua experiência vivida.  
- **Lei n.º 112/2009 (Violência Doméstica):** O sofrimento emocional e psicológico são formas reconhecidas de abuso. Quando uma criança é usada como arma contra o outro progenitor, o registo imutável do Cube pode servir como prova de violência psicológica — e pode ser configurado para permitir apenas contacto seguro e monitorizado quando existe risco.  
- **Código Civil Português (Artigos 1878.º a 1908.º):** Regula o exercício das responsabilidades parentais. O direito de visitas significa o direito do progenitor não residente de se relacionar e conviver com a criança.  
- **Sistema de Mediação Familiar (SMF):** O Cube complementa os esforços de mediação familiar, oferecendo um canal de comunicação verificável quando a mediação é insuficiente ou quando o conflito persiste.  
- **Lei n.º 23/2013 (Economia Social):** Reforça o quadro legal para entidades da economia social, incluindo associações, cooperativas, fundações e empresas sociais.

---

## 9\. Roteiro de Cinco Anos

**Do conceito à infraestrutura nacional**

| Fase | Período | Atividades Principais | Marcos |
| :---- | :---- | :---- | :---- |
| **1\. Fundação** | 0–12 meses | Constituir a entidade sem fins lucrativos. Concluir o primeiro protótipo físico do Cube (ecrã, áudio, LTE). Garantir financiamento inicial. Formalizar parceria de investigação com uma universidade portuguesa. | Entidade legal registada. Protótipo funcional pronto. 3 parcerias estratégicas. |
| **2\. Piloto** | 12–24 meses | Implementar 100–150 Cubes em 2–3 áreas autárquicas, integrados com CPCJ e equipas de apoio à família. Recolher dados de salvaguarda e bem-estar. Primeira avaliação publicada. | 150 famílias apoiadas. Primeiro relatório de avaliação independente. |
| **3\. Evidência** | 24–36 meses | Publicação revista por pares dos resultados. Adoção por uma CPCJ. Expansão para 10 autarquias. | 2 artigos académicos. Contrato com pelo menos uma autarquia/CPCJ. |
| **4\. Escala** | 36–48 meses | 50+ autarquias. Utilização formal em decisões judiciais. Equipa de 25+ pessoas. | 10.000 Cubes implementados. 5 comarcas a utilizar dados do Cube. |
| **5\. Infraestrutura Pública** | 48–60 meses | Cube reconhecido como parte da infraestrutura nacional de justiça familiar e apoio precoce. Cofinanciado pelo governo central. Pilotos internacionais. | 50.000+ Cubes. Orientação política emitida. Reconhecimento internacional. |

---

## 10\. Junte-se a Este Movimento

**Comissione, investigue, defenda, crie, governe**

*“Todas as crianças merecem ouvir a voz de alguém que as ama.*  
*Todos os progenitores merecem chegar aos seus filhos.*  
*O Story Cube torna isso possível — com simplicidade, segurança e calor.”*

Estamos a construir mais do que um dispositivo. Estamos a construir um movimento pelos direitos das crianças, baseado em evidências e concebido para o setor público.

Quer seja um autarca, um membro de uma CPCJ, um juiz de família, um investigador académico, um serviço de apoio à vítima de violência doméstica, ou um progenitor que conhece esta luta em primeira mão — **há um lugar para si neste trabalho.**

- **Comissionar:** Autarquias e CPCJ: testem o Cube na sua área como parte da vossa estratégia de apoio precoce ou proteção pública.  
- **Investigar:** Universidades: estabeleçam parcerias para avaliar o impacto no bem-estar infantil, vinculação e desenvolvimento da linguagem.  
- **Defender:** Profissionais de direito da família e magistratura: ajudem a moldar o Cube como uma ferramenta reconhecida para contacto e evidência.  
- **Criar:** Ilustradores, contadores de histórias e animadores: contribuam para uma biblioteca aberta de temas e histórias.  
- **Governar:** Junte-se ao nosso conselho diretivo. Ajude a orientar a organização com transparência e rigor.

---

**Cubo de Histórias (Story Cube)**  
*Ligação que transforma — uma ponte de amor entre pais e filhos*  
Alinhado com a Convenção das Nações Unidas sobre os Direitos da Criança · Artigo 9.º  
Organização sem fins lucrativos portuguesa em formação  
Feito com cuidado para famílias em todo o lado

---

