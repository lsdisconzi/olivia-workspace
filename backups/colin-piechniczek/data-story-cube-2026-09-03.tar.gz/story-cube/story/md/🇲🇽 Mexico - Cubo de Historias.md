---

# Cubo de Histórias (Story Cube)

**Visión y Hoja de Ruta de Impacto – México** *Documento v3.1 · 2026 · Español*

*“Tu vida debe ser aplicada a una causa, no a las cosas.”* Ese espíritu impulsa el Story Cube — una iniciativa que no busca retorno financiero, sino la restauración de un derecho fundamental: el vínculo entre una niña o niño y el padre o madre que lo ama, incluso cuando viven separados.

---

## 1\. Por Qué Existe Esto

Cuando una niña o niño es mantenido alejado de uno de sus progenitores — por distancia, separación u obstrucción deliberada — pierde algo irremplazable: el sonido cotidiano de la persona que lo ama.

El Story Cube no es un producto que genera bien social como efecto secundario. Es una misión social que utiliza la tecnología como herramienta. Su forma institucional natural es, por tanto, una **organización sin fines de lucro** — donde el propósito gobierna la estructura, y no al revés.

Este documento establece la visión y el camino para convertir el Story Cube en un movimiento de interés público: una herramienta escalable, basada en evidencia, que protege el derecho de la niñez a la vida familiar, apoya al sistema de justicia familiar y ayuda a los servicios públicos a intervenir de manera temprana. Todo anclado en el **Artículo 9 de la Convención de las Naciones Unidas sobre los Derechos del Niño**, que garantiza el derecho del niño a mantener contacto regular con ambos progenitores, salvo que ello sea contrario a su interés superior.

---

## 2\. La Historia Detrás del Cubo

**De la distancia de un progenitor al derecho de cada niño a ser escuchado**

El Story Cube nació de una experiencia vivida: un progenitor impedido de hablar con su hijo durante casi un mes. Llamadas desviadas, mensajes sin respuesta. Los pequeños momentos cotidianos — *¿qué viste hoy? ¿te gustó? ¿qué dibujaste?* — desvaneciéndose en el silencio.

Lo que siguió fue una dolorosa constatación: el problema no es una aplicación faltante o un teléfono lento. El problema es que el contacto de un niño con uno de sus progenitores es tratado a menudo como un privilegio concedido por el otro, cuando en realidad es un derecho que pertenece al propio niño.

*“Las niñas y niños necesitan voz. Tienen derechos. La comunicación con el progenitor que no es el cuidador principal debería ser una elección del niño — no algo filtrado por un intermediario.”*

El Cube transforma esa idea en un objeto físico: una caja de madera bellamente trabajada, con pantalla, micrófono, altavoz y conectividad LTE integrados en una sola unidad. Vive en la habitación del niño. No puede ser bloqueado, desviado o reutilizado. Transporta solo la voz y las historias del progenitor que lo ama — y nada más de internet.

| No es una app | Inbloqueable | Liderado por el niño | Acogedor y seguro |
| :---- | :---- | :---- | :---- |
| Un dispositivo dedicado. No puede ser desinstalado, secuestrado por TikTok ni utilizado para nada más. | LTE integrado garantiza que ningún intermediario pueda cortar la conexión. | Un botón para escuchar, un botón para grabar. Sin necesidad de permiso de un adulto en la habitación. | Un compañero de madera junto a la cama — no otra pantalla compitiendo por atención. |

---

## 3\. El Problema

**Separación familiar, obstrucción del contacto y el daño a la niñez**

En México, la realidad de la separación parental afecta a cientos de miles de niños, niñas y adolescentes. En **2024 se registraron 161,932 divorcios** en el país, con una tasa de **33.3 divorcios por cada 100 matrimonios**.

- **Niños en familias separadas:** De los matrimonios disueltos mediante divorcio judicial, **22.5% tenía una hija o hijo menor de edad; 16.2% tenía dos; y 5.5% más de dos**. Esto implica que cientos de miles de niños, niñas y adolescentes en México viven en hogares con padres separados. Las parejas **sin hijos** representan el **55.1%** de los divorcios.  
- **Custodia:** En los divorcios judiciales, la custodia de los hijos se asignó a la **madre en el 55.1%** de los casos, y a **ambos padres (custodia compartida) en el 38.2%**.  
- **Sobrecarga del sistema de justicia:** En 2024, el **89.6%** de los divorcios se resolvió por vía judicial. El Poder Judicial enfrenta una alta carga de trabajo en materia de familia.  
- **Sistema de protección:** La **Procuraduría Federal de Protección de Niñas, Niños y Adolescentes (PFPNNA)** , creada en 2015, es la institución encargada de garantizar que la niñez viva protegida y con sus derechos respetados. Sin embargo, el sistema enfrenta retos estructurales para atender a todos los casos.

**Dónde fallan las herramientas actuales**

- **Teléfonos y apps son controlables.** El progenitor residente puede eliminar, restringir o monitorear la comunicación. La voz del otro progenitor nunca llega al niño.  
- **Las pantallas comunes son tóxicas para los niños pequeños.** Contenidos guiados por algoritmos y publicidad están diseñados para captar atención, no para nutrir el apego.  
- **Los niños no tienen voz directa.** Dependen del dispositivo de otra persona, del horario de otra persona, y a menudo hablan bajo observación.  
- **Los progenitores no residentes carecen de apoyo accesible.** El sistema de justicia familiar es costoso y difícil de navegar en soledad.

Más allá de las familias individuales, el Estado tiene una brecha estructural: no existe una herramienta ampliamente disponible y escalable para ayudar a defender el derecho del niño a la vida familiar. El Story Cube está diseñado para llenar ese vacío — no como caridad, sino como un instrumento eficaz de protección pública e intervención temprana.

---

## 4\. La Solución: El Story Cube

**Un cubo de madera. Pantalla, micrófono y altavoz integrados. Un solo propósito.**

El Cube es deliberadamente radical en su simplicidad. Es un dispositivo único y autónomo. Hace solo lo que necesita hacer, y lo hace con calidez y cuidado.

- **Grabar:** Un botón rojo. El niño habla, el otro progenitor recibe.  
- **Escuchar:** Un botón verde. La voz de la persona que lo ama, instantáneamente.  
- **Compartir en TV:** Reemplazar dibujos animados pasivos por historias que la familia ha creado junta.  
- **Doble nube:** LTE integrado significa que la conexión no puede ser cortada. Ambos progenitores tienen siempre acceso seguro.  
- **Fabricado en madera certificada FSC.** Temas personalizables — espacio, animales, cuentos de hadas.  
- **Plataforma para progenitores:** Una aplicación web para subir ilustraciones, elegir temas y acceder a un kit de herramientas de navegación legal.

**Dónde estamos hoy:** Un MVP digital funcional ya funciona en cualquier navegador — con motores de historias 2D y 3D, comandos de voz y seguimiento corporal — permitiendo que las primeras familias prueben la experiencia inmediatamente en una tablet o teléfono. Este es el embrión del Cube físico, que está ahora en desarrollo y traerá toda esa capacidad a un único dispositivo autónomo de madera.

**Lo que no es:** No es una tablet. No es una app de teléfono. No es una pantalla de YouTube. No es nada que pueda ser desviado, bloqueado o llenado con contenido que los progenitores no hayan elegido. La disciplina del Cube es su mayor fortaleza.

---

## 5\. Quién se Beneficia

**Niños, progenitores, el sistema de justicia familiar, fuerzas de seguridad, municipios y la sociedad en su conjunto**

### Para el niño o niña

- **Seguridad emocional:** Escuchar la voz del progenitor ausente todos los días ayuda a preservar el apego seguro y protege la salud mental.  
- **Tiempo de pantalla saludable:** Sin algoritmos, sin anuncios, sin contenido dañino — solo las historias que la familia elige.  
- **Una voz propia:** El niño puede contactar cuando quiera. No cuando se le permite. No bajo vigilancia.  
- **Ritual de hora de dormir:** Una historia grabada por el otro progenitor reemplaza la ansiedad de la separación con confort.

### Para el progenitor no residente

- **Presencia inbloqueable:** El LTE garantiza que cada mensaje llegue al niño. Ninguna app para ser eliminada.  
- **Apoyo a la navegación legal:** Un portal web seguro con guías en español claro, plantillas para declaraciones y un archivo de evidencia — ayudando a los litigantes a navegar el sistema judicial. Complementa, pero no reemplaza, el asesoramiento legal independiente.  
- **Registro documentado:** Cada interacción es registrada con fecha y hora, proporcionando prueba objetiva de cuidado parental continuo para procedimientos judiciales.  
- **Parentalidad creativa:** Subir dibujos, construir historias animadas, personalizar el Cube para el niño.

### Para el Poder Judicial (Juzgados de lo Familiar) y el Ministerio Público

- **Canal de comunicación verificable:** El Cube puede ser ordenado por el juez como una forma de facilitar el contacto — un canal objetivo, auditable y libre de interferencias.  
- **Registro de involucramiento parental:** Registros con fecha y hora reemplazan narrativas contradictorias por datos. Jueces y fiscales ven exactamente con qué frecuencia un progenitor se conectó y qué compartió.  
- **Reducción de litigios:** Cuando el contacto es registrado objetivamente, las disputas sobre obstrucción e incumplimiento disminuyen, liberando tiempo judicial y reduciendo la animosidad.

### Para la Procuraduría Federal de Protección (PFPNNA), los Sistemas DIF y los Municipios

- **Intervención temprana en conflictos familiares:** El Cube puede ser implementado como parte de una estrategia de prevención, reduciendo llamadas reiteradas a los servicios y derivaciones a protección de la infancia.  
- **Evidencia para investigaciones de protección y penales:** En casos donde un progenitor utiliza al niño para controlar al otro, el registro inmutable del Cube puede servir como prueba — y puede ser configurado para permitir solo contacto seguro y monitoreado cuando existe riesgo.  
- **Ahorro de costos:** Cada familia apoyada en esta fase temprana evita la escalada hacia procedimientos de protección, acogimiento o justicia penal — ahorrando miles de pesos por caso y previniendo daños intergeneracionales.

### Para universidades y centros de investigación

El Cube funciona también como infraestructura de investigación sobre el impacto de la obstrucción del contacto en el desarrollo infantil. A través de alianzas con universidades mexicanas (UNAM, IPN, ITESM, etc.), puede generar datos longitudinales sobre bienestar emocional, adquisición del lenguaje y apego — transformando la experiencia vivida en evidencia publicada que da forma a las políticas públicas.

### Para la sociedad

La ruptura de los lazos familiares crea costos intergeneracionales: mayores tasas de problemas de salud mental, fracaso escolar, consumo de sustancias y delincuencia juvenil. Cada familia que permanece conectada es una célula social fortalecida. El Story Cube actúa en el punto de la prevención — garantizando que un vínculo de amor sobreviva a la separación, reduciendo el sufrimiento infantil e impidiendo que el daño se agrave. El retorno social de esa inversión se mide no en trimestres, sino en generaciones.

---

## 6\. Camino Institucional

**Una estructura sin fines de lucro al servicio de la misión**

El Story Cube será establecido como una **organización sin fines de lucro** (persona jurídica sin fines de lucro), al amparo del Código Civil Federal y de las leyes aplicables en México. Todos los recursos generados — ya sea por subvenciones, contratos o donaciones — son reinvertidos íntegramente en la misión: fabricar más Cubes, mejorar la plataforma, financiar investigación independiente y expandirse a nuevas áreas.

El gobierno será ejercido por un **consejo directivo** con experiencia en protección de la infancia, derecho de familia, ética digital y prestación de servicios públicos. La organización puede, a su debido tiempo, solicitar su **inscripción en el Registro Nacional de Organizaciones de la Sociedad Civil**, lo que mejor permita la alianza con el sector público, incluida la posibilidad de celebrar **convenios de colaboración** con el Estado.

El Story Cube no pertenece a accionistas. Pertenece a la causa.

---

## 7\. Ecosistema de Apoyo

**Fuentes de financiamiento en México, alianzas y una estrategia en tres fases**

Como herramienta sin fines de lucro diseñada para el sector público, el Story Cube puede recurrir a una combinación diversificada de recursos:

**A. Financiamiento Público Nacional**

- **Programa de Apoyo a las Instancias de Mujeres (PAIMEF):** Aunque enfocado en violencia de género, puede tener líneas para infancia y familias.  
- **Sistema Nacional DIF (SNDIF):** A través de sus programas de protección a la infancia y apoyo familiar. El SNDIF trabaja en coordinación con las procuradurías estatales y municipales en todo el país.  
- **Presupuesto de Egresos de la Federación:** Partidas para infancia, familia y protección social.  
- **Programas de Desarrollo Social (SEDESOL / BIENESTAR):** Programas de apoyo a familias en situación de vulnerabilidad.

**B. Fondos de Fundaciones y Cooperación Internacional**

- **UNICEF México:** Presente en el país, promueve la protección de los derechos de la niñez. Ha colaborado en la elaboración de guías prácticas para la protección y restitución de derechos.  
- **Fundaciones nacionales:** Fundación Carlos Slim, Fundación Televisa, Fundación Merced, entre otras.  
- **Cooperación internacional:** Agencias de cooperación y organismos multilaterales con programas en infancia y protección social.

**C. Gobiernos Estatales y Municipales**

- **Gobiernos de los estados:** A través de sus sistemas estatales DIF y procuradurías de protección.  
- **Municipios:** A través de los Sistemas Municipales DIF y las direcciones de desarrollo social.  
- **Fondos de apoyo a la infancia:** Existen diversos programas de apoyo económico para niñas, niños y adolescentes en situación de vulnerabilidad.

**D. Poder Judicial**

- **Juzgados de lo Familiar:** Pueden considerar el Cube como una herramienta para facilitar el contacto y generar evidencia en casos de custodia y convivencia.  
- **Centros de Justicia para las Mujeres:** Espacios que integran diversos servicios de atención a la violencia familiar.

**E. Potenciales Instituciones Colaboradoras**

| Tipo de Institución | Entidad Específica |
| :---- | :---- |
| Procuraduría Federal de Protección | Procuraduría Federal de Protección de Niñas, Niños y Adolescentes (PFPNNA) |
| Sistema Nacional DIF | Sistema Nacional para el Desarrollo Integral de la Familia (SNDIF) |
| Secretaría de Gobernación | Secretaría de Gobernación (SEGOB) |
| Poder Judicial | Juzgados de lo Familiar / Suprema Corte de Justicia de la Nación (SCJN) |
| Municipios | Sistemas Municipales DIF / Direcciones de Desarrollo Social |
| Universidades | UNAM, IPN, ITESM, UAM, universidades estatales |

### F. Estrategia en tres fases

1. **Semilla (Años 1–2):** Subvenciones de fundaciones, piloto inicial con un municipio y un Juzgado de lo Familiar, alianza académica establecida. Primeros prototipos físicos implementados.  
2. **Sostenibilidad (Años 3–4):** Contratación directa por municipios, adopción por el Sistema DIF y la PFPNNA, base de evidencia publicada, expansión a múltiples estados.  
3. **Escala (Año 5 en adelante):** Implementación nacional con cofinanciamiento del gobierno federal, integración en resoluciones judiciales y rutas de protección. Pilotos internacionales en paralelo.

---

## 8\. Alineamiento con el Marco Legal y de Protección Mexicano

El Story Cube está diseñado para situarse en la intersección de la arquitectura legal y de protección infantil mexicana:

- **Convención sobre los Derechos del Niño (CDN):** México ratificó la Convención el **21 de septiembre de 1990**. El **Artículo 9** garantiza el derecho del niño a mantener relaciones personales y contacto directo con ambos progenitores de modo regular, salvo si ello es contrario a su interés superior.  
    
- **Ley General de los Derechos de Niñas, Niños y Adolescentes (LGDNNA):** Promulgada el **4 de diciembre de 2014**, con última reforma publicada el **27 de mayo de 2024**. Esta ley tiene por objeto reconocer a niñas, niños y adolescentes como titulares de derechos; garantizar el pleno ejercicio, respeto, protección y promoción de sus derechos humanos. Establece que **no podrán ser separados de las personas que ejerzan la patria potestad** o de sus tutores. También crea y regula el **Sistema Nacional de Protección Integral de los Derechos de Niñas, Niños y Adolescentes (SIPINNA)**.  
    
- **Código Civil Federal, Artículos 411 a 424:** En caso de separación de quienes ejercen la patria potestad, **ambos deberán continuar con el cumplimiento de sus deberes** y podrán convenir los términos de su ejercicio. La **custodia compartida** se refiere a que los padres en caso de divorcio o separación tienen el derecho y la obligación de ejercer en igualdad de circunstancias.  
    
- **Patria Potestad, Guarda y Custodia:** La patria potestad son los derechos y obligaciones que los padres tienen en relación a sus hijos.  
    
- **Procuraduría Federal de Protección de Niñas, Niños y Adolescentes (PFPNNA):** Creada en 2015, es la institución del Estado mexicano encargada de garantizar que la niñez viva protegida y con sus derechos respetados. Trabaja en coordinación con el Sistema Nacional DIF y con las procuradurías estatales y municipales. Su labor principal es intervenir cuando un niño se encuentra en riesgo o cuando sus derechos han sido vulnerados.  
    
- **Sistema Nacional para el Desarrollo Integral de la Familia (SNDIF):** Institución mexicana que coordina los sistemas estatales y municipales DIF para la protección de la familia y la infancia.

---

## 9\. Hoja de Ruta de Cinco Años

**Del concepto a la infraestructura nacional**

| Fase | Período | Actividades Principales | Hitos |
| :---- | :---- | :---- | :---- |
| **1\. Fundación** | 0–12 meses | Constituir la entidad sin fines de lucro. Completar el primer prototipo físico del Cube (pantalla, audio, LTE). Obtener financiamiento inicial. Formalizar alianza de investigación con una universidad mexicana. | Entidad legal registrada. Prototipo funcional listo. 3 alianzas estratégicas. |
| **2\. Piloto** | 12–24 meses | Implementar 100–150 Cubes en 2–3 municipios, integrados con Sistemas DIF y Juzgados de lo Familiar. Recoger datos de protección y bienestar. Primera evaluación publicada. | 150 familias apoyadas. Primer informe de evaluación independiente. |
| **3\. Evidencia** | 24–36 meses | Publicación revisada por pares de los resultados. Adopción por el Sistema DIF y la PFPNNA. Expansión a 10 municipios. | 2 artículos académicos. Contrato con al menos un municipio/Sistema DIF. |
| **4\. Escala** | 36–48 meses | 50+ municipios. Uso formal en resoluciones judiciales. Equipo de 25+ personas. | 10.000 Cubes implementados. 5 jurisdicciones utilizando datos del Cube. |
| **5\. Infraestructura Pública** | 48–60 meses | Cube reconocido como parte de la infraestructura nacional de justicia familiar y apoyo temprano. Cofinanciado por el gobierno federal. Pilotos internacionales. | 50.000+ Cubes. Orientación política emitida. Reconocimiento internacional. |

---

## 10\. Únete a Este Movimiento

**Comisiona, investiga, defiende, crea, gobierna**

*“Cada niño merece escuchar la voz de alguien que lo ama.* *Cada progenitor merece llegar a su hijo.* *El Story Cube hace eso posible — con sencillez, seguridad y calidez.”*

Estamos construyendo más que un dispositivo. Estamos construyendo un movimiento por los derechos de la infancia, basado en evidencia y diseñado para el sector público.

Ya sea que seas un presidente municipal, un director de un Sistema DIF, un juez de lo familiar, un fiscal, un investigador académico, un servicio de apoyo a víctimas de violencia, o un progenitor que conoce esta lucha de primera mano — **hay un lugar para ti en este trabajo.**

- **Comisionar:** Municipios, Sistemas DIF y Juzgados de lo Familiar: prueben el Cube en su área como parte de su estrategia de apoyo temprano o protección pública.  
- **Investigar:** Universidades: establezcan alianzas para evaluar el impacto en el bienestar infantil, el apego y el desarrollo del lenguaje.  
- **Defender:** Profesionales del derecho de familia y del Poder Judicial: ayuden a moldear el Cube como una herramienta reconocida para el contacto y la evidencia.  
- **Crear:** Ilustradores, narradores y animadores: contribuyan a una biblioteca abierta de temas e historias.  
- **Gobernar:** Únete a nuestro consejo directivo. Ayuda a guiar la organización con transparencia y rigor.

---

**Cubo de Histórias (Story Cube)** *Conexión que transforma — un puente de amor entre padres e hijos* Alineado con la Convención de las Naciones Unidas sobre los Derechos del Niño · Artículo 9 Organización sin fines de lucro mexicana en formación Hecho con cuidado para familias en todas partes

---

