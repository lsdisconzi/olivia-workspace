# Story Cube | کہانی کا کیوب (Kahani Ka Cube)

**Vision and Impact Roadmap – Pakistan**  
*Document v3.1 · 2026 · English / اردو*

*“Your life must be applied to a cause, not to things.”*  
That spirit drives the Story Cube — an initiative that seeks no financial return, only the restoration of a fundamental right: the bond between a child and the parent who loves them, even when they live apart.

---

## 1\. Why This Exists

When a child is kept from a parent — by distance, separation, or deliberate obstruction — they lose something irreplaceable: the everyday sound of someone who loves them.

The Story Cube is not a product that generates social good as a side effect. It is a social mission that uses technology as a tool. Its natural institutional form is therefore a **non‑profit organization** — where purpose governs structure, not the other way around.

This document sets out the vision and the path to transform the Story Cube into a public‑interest movement: a scalable, evidence‑based tool that protects a child’s right to family connection, supports the justice system, and helps public services intervene early. Everything is anchored in **Article 9 of the United Nations Convention on the Rights of the Child**, ratified by Pakistan in 1990, which guarantees the right of the child who is separated from one or both parents to maintain personal relations and direct contact with both parents on a regular basis, unless that is contrary to their best interests.

---

## 2\. The Story Behind the Cube

**From one parent’s distance to every child’s right to be heard**

The Story Cube was born from lived experience: a parent blocked from speaking with their child for nearly a month. Calls diverted, messages unanswered. The tiny everyday moments — *what did you see today? did you like it? what did you draw?* — vanishing into silence.

What followed was a painful realization: the problem is not a missing app or a slow phone. The problem is that a child’s contact with one parent is too often treated as a privilege granted by the other, when it is, in truth, a right that belongs to the child.

*“Children need a voice. They have rights. Communication with the non‑primary parent should be the child’s choice — not something filtered through a gatekeeper.”*

The Cube turns that idea into a physical object: a beautifully crafted wooden box, with a screen, microphone, speaker, and built‑in LTE connectivity — all in one unit. It lives in the child’s room. It cannot be blocked, diverted, or repurposed. It carries only the voice and stories of the parent who loves them — and nothing else from the internet.

| Not an app | Unblockable | Child‑led | Welcoming and safe |
| :---- | :---- | :---- | :---- |
| A dedicated device. It cannot be uninstalled, hijacked by TikTok, or used for anything else. | Built‑in LTE guarantees no intermediary can cut the connection. | One button to listen, one button to record. No adult permission needed in the child’s home. | A wooden companion by the bedside — not another screen competing for attention. |

---

## 3\. The Problem

**Family separation, contact obstruction, and the harm to childhood**

In Pakistan, family separation — through divorce, khula, separation, or migration — affects hundreds of thousands of children. While official marriage and divorce statistics remain fragmented, the scale of the challenge is evident.

- **Children in separated families:** According to the Population Census 2023, Pakistan has a population of over 240 million, with nearly half under the age of 18\. The UN estimates that around **22 million children are out of school**, and **34% of the population lives below the national poverty line**, compounding vulnerability when families break down.  
- **Custody and guardianship:** Pakistan’s family law landscape is pluralistic, governed by the **Guardians and Wards Act, 1890**, the **Muslim Family Laws Ordinance, 1961**, and uncodified principles of Islamic law. In disputes, the concept of **hizanat** (physical custody of young children, typically with the mother until a certain age) and **wilayat** (legal guardianship, usually with the father) often lead to conflict when parents separate. Despite global best‑interest standards, many fathers struggle to maintain meaningful contact after divorce, and mothers may face barriers to legal guardianship.  
- **Overburdened justice system:** Family Courts, established under the **Family Courts Act, 1964**, are inundated with cases of maintenance, custody, and visitation. Litigation can span years, leaving children in limbo and increasing parental acrimony.  
- **Child protection infrastructure:** The **National Commission on the Rights of the Child (NCRC)** and provincial bodies such as the **Punjab Child Protection and Welfare Bureau** and **Sindh Child Protection Authority** are mandated to safeguard children, but preventive tools for family contact are scarce.

**Where current tools fail**

- **Phones and apps are controllable.** The resident parent can delete, restrict, or monitor communication. The other parent’s voice never reaches the child.  
- **Ordinary screens are harmful for young children.** Algorithm‑driven content and advertising are designed to capture attention, not to nurture attachment.  
- **Children lack a direct voice.** They depend on someone else’s device, someone else’s schedule, and often speak under observation.  
- **Non‑resident parents lack accessible support.** The family justice system is costly, hard to navigate alone, and rarely designed to facilitate day‑to‑day emotional connection.

Beyond individual families, the state has a structural gap: there is no widely available, scalable tool to help defend a child’s right to family connection, especially in a society where the extended family and the concept of *izzat* (honour) can intensify post‑separation gatekeeping. The Story Cube is designed to fill that gap — not as charity, but as an effective instrument of public protection, early intervention, and preservation of the child’s right to love both parents.

---

## 4\. The Solution: The Story Cube

**A wooden cube. Built‑in screen, microphone, and speaker. A single purpose.**

The Cube is deliberately radical in its simplicity. It is a unique, standalone device. It does only what it needs to do, and it does so with warmth and care.

- **Record:** A red button. The child speaks, the other parent receives it.  
- **Listen:** A green button. The voice of the person who loves them, instantly.  
- **Share on TV:** Replace passive cartoons with stories the family creates together.  
- **Dual cloud:** Built‑in LTE means the connection cannot be severed. Both parents always have secure access.  
- **Made of FSC‑certified wood.** Customizable themes — space, animals, fairy tales, and regionally inspired designs (truck art motifs, Basant, Islamic geometric patterns).  
- **Parent platform:** A web app to send illustrations, choose themes, and access a legal‑navigation toolkit in Urdu and English, helping parents understand their rights and document their involvement.

**Where we are today:** A working digital MVP already runs in any browser — with 2D and 3D story engines, voice commands, and body tracking — allowing the first families to test the experience immediately on a tablet or phone. This is the embryo of the physical Cube, now in development, which will bring all that capability into a single, autonomous wooden device.

**What it is not:** It is not a tablet. It is not a phone app. It is not a YouTube screen. It is nothing that can be diverted, blocked, or filled with content the parents did not choose. The Cube’s discipline is its greatest strength.

---

## 5\. Who Benefits

**Children, parents, the justice system, child protection authorities, police, and society as a whole**

### For the child

- **Emotional security:** Hearing the absent parent’s voice every day helps preserve secure attachment and protects mental health, especially critical in a context where separation often severs the bond entirely.  
- **Healthy screen time:** No algorithms, no ads, no harmful content — only stories the family chooses.  
- **A voice of their own:** The child can reach out whenever they want. Not when they are allowed. Not under surveillance.  
- **Bedtime ritual:** A story recorded by the other parent replaces separation anxiety with comfort — a nightly *dua* (prayer) or a lullaby can be shared securely.

### For the non‑resident parent

- **Unblockable presence:** LTE guarantees every message reaches the child. No app to be deleted.  
- **Legal navigation support:** A secure web portal with plain‑language guides in Urdu and English, sample applications for visitation orders, and an encrypted evidence log — helping self‑represented litigants navigate family courts. It complements, but does not replace, independent legal advice.  
- **Documented record:** Every interaction is time‑stamped, providing objective proof of ongoing parental care for custody proceedings — crucial in a system where verbal allegations often dominate.  
- **Creative parenting:** Send drawings, build animated stories, customize the Cube with familiar cultural references.

### For the Judiciary (Family Courts) and Lawyers

- **Verifiable communication channel:** The Cube can be ordered by a judge as a means of facilitating contact — an objective, auditable channel free from interference and allegations of coaching.  
- **Record of parental engagement:** Time‑stamped logs replace contradictory narratives with data. Judges see exactly how often a parent connected and what they shared.  
- **Reduction in litigation:** When contact is objectively recorded, disputes about obstruction and non‑compliance decrease, freeing court time and reducing family bitterness.

### For Child Protection Bureaus, Police, and Provincial Governments

- **Early intervention in family conflict:** The Cube can be deployed as part of a prevention strategy, reducing repeat calls for service and referrals to the child protection system.  
- **Evidence for protection and criminal investigations:** In cases where one parent uses the child to control the other, the Cube’s immutable log can serve as evidence — and it can be configured to allow only safe, monitored contact when risk exists.  
- **Cost savings:** Every family supported at this early stage avoids escalation to formal child protection proceedings, institutional placement, or criminal justice involvement — saving significant public resources and preventing intergenerational harm.

### For universities and research centres

The Cube also serves as research infrastructure on the impact of contact obstruction on child development. Through partnerships with Pakistani universities — Lahore University of Management Sciences (LUMS), University of the Punjab, Quaid‑i‑Azam University, Aga Khan University, Institute of Business Administration (IBA) Karachi, and others — it can generate longitudinal data on emotional well‑being, language acquisition, and attachment, turning lived experience into published evidence that shapes provincial and federal policy.

### For society

The rupture of family bonds creates intergenerational costs: higher rates of mental health problems, school dropout, child labour, and juvenile delinquency. Pakistan already carries a heavy burden of out‑of‑school children and child protection violations. Every family that stays connected is a strengthened social cell. The Story Cube acts at the point of prevention — ensuring that a loving bond survives separation, reducing child suffering, and stopping harm before it escalates. The social return on that investment is not measured in fiscal quarters, but in generations.

---

## 6\. Institutional Path

**A non‑profit structure in service of the mission**

The Story Cube will be established as a **not‑for‑profit company** under Section 42 of the **Companies Act, 2017**, licensed by the Securities and Exchange Commission of Pakistan (SECP). The organization will also apply for registration with the **Federal Board of Revenue** for income tax exemption and the ability to receive tax‑deductible donations under the Income Tax Ordinance, 2001\. All resources generated — whether through grants, contracts, or donations — will be reinvested entirely in the mission: manufacturing more Cubes, improving the platform, funding independent research, and expanding to new regions, including engaging with Azad Jammu and Kashmir and Gilgit‑Baltistan.

Governance will be exercised by a **board of directors** with expertise in child protection, family law, digital ethics, and public service delivery. An advisory body will include youth representatives, Islamic legal scholars, child psychologists, and members of civil society, ensuring the Cube remains culturally resonant and ethically sound.

The Story Cube belongs to no shareholders. It belongs to the cause.

---

## 7\. Support Ecosystem

**Funding sources in Pakistan, partnerships, and a three‑phase strategy**

As a non‑profit tool designed for the public sector and civil society, the Story Cube can draw on a diverse mix of resources:

**A. Public Funding and Government Programmes**

- **Provincial Child Protection Authorities:** Punjab Child Protection and Welfare Bureau, Sindh Child Protection Authority, Khyber Pakhtunkhwa Social Welfare Department, Balochistan Social Welfare Department — all fund or implement child‑focused projects.  
- **National Commission on the Rights of the Child (NCRC):** The apex body for children’s rights in Pakistan, which can support policy alignment and pilot funding.  
- **Human Rights Wing, Ministry of Human Rights:** Oversees implementation of international treaties and may fund innovative rights‑based initiatives.  
- **Prime Minister’s Programme for Youth:** Though not directly child‑focused, can provide complementary support.  
- **Zakat and Bait‑ul‑Mal:** Some provincial Bait‑ul‑Mal programmes support orphanages and child welfare, potentially adaptable for preventive family support.

**B. Foundations and Philanthropic Organisations**

- **Pakistan Centre for Philanthropy (PCP):** Certifies non‑profits and connects them with donors; can help open corporate giving.  
- **Aga Khan Foundation Pakistan:** Works in early childhood development and social inclusion.  
- **The Citizens Foundation (TCF):** While education‑focused, its community networks could support distribution and impact study.  
- **Saifee Foundation, Noon Foundation, and others:** Large family foundations that support health and social welfare.  
- **Philanthropy Pakistan / Pakistan Human Capital Fund:** Emerging platforms for social investment.  
- **Local corporate CSR programmes:** Engro Foundation, HBL Foundation, and others that focus on social innovation.

**C. International Cooperation**

- **UNICEF Pakistan:** Present for decades, UNICEF Pakistan works on child protection, justice, and education and can be a strategic partner for scaling.  
- **UNDP Pakistan, UNFPA, and the European Union:** Active in governance, human rights, and family‑related programmes.  
- **British Asian Trust, DFID/FCDO legacy programmes:** Have funded social development in Pakistan.

**D. Individual Donors and Diaspora Giving**

- **Zakat‑eligible projects:** The Cube, when dedicated to vulnerable children, may qualify for Zakat funds, a massive source of charitable giving in Pakistan.  
- **Diaspora community:** Overseas Pakistanis often support social causes through platforms like SKMCH\&RC’s model; a Cubes‑for‑Families fund could tap into this.

**E. Potential Collaborating Institutions**

| Type of Institution | Specific Entity |
| :---- | :---- |
| National Child Rights Body | National Commission on the Rights of the Child (NCRC) |
| Provincial Protection Agencies | Punjab CPWB, Sindh Child Protection Authority, KP Social Welfare, Balochistan SWD |
| Judiciary | Family Courts (district level), Lahore High Court, Sindh High Court (with child‑focused benches) |
| Legal Aid | Legal Aid Society (Sindh), AGHS Legal Aid Cell, local bar councils |
| Police | Human Rights Cells of Provincial Police, Gender Protection Units |
| Universities | LUMS, Punjab University, Aga Khan University (Institute for Educational Development), Quaid‑i‑Azam University, IBA Karachi |
| Religious & Community Leaders | Council of Islamic Ideology (for guidance), local mosques and community centres for outreach |

### F. Three‑Phase Strategy

1. **Seed (Years 1–2):** Pilot project in one urban centre (e.g., Lahore) and one rural district with a Family Court, supported by foundation grants and academic partnership. First 100‑150 Cubes deployed with consenting families referred by the court. Baseline data collected.  
2. **Sustainability (Years 3–4):** Evidence published; provincial government contracts for child‑protection and family‑court use; multi‑city expansion across Punjab and Sindh; platform fully localized.  
3. **Scale (Year 5 onward):** National programme, with NCRC endorsement, integration into family‑court procedures, co‑funding from federal PSDP (Public Sector Development Programme) and international donors; parallel pilots in other South Asian countries.

---

## 8\. Alignment with Pakistan’s Legal and Child‑Protection Framework

The Story Cube is designed to sit within Pakistan’s complex, layered legal context for children and families:

- **Constitution of the Islamic Republic of Pakistan, 1973:** Article 25 (equality), Article 35 (protection of family), and the principles of policy (Articles 29‑40) direct the state to protect the family and children. The Supreme Court has read the right to family life into the right to dignity (Article 14).  
- **Guardians and Wards Act, 1890:** The primary legislation governing custody and guardianship, focused on the “welfare of the minor” as the paramount consideration — echoing the “best interests” principle.  
- **Muslim Family Laws Ordinance, 1961:** Regulates marriage and divorce for Muslims, including provisions for child maintenance. The Dissolution of Muslim Marriages Act, 1939, allows a woman to seek *khula*.  
- **Islamic law principles:** *Hizanat* (physical custody, usually with the mother for young children: boys until 7, girls until puberty, though courts can vary this based on welfare) and *wilayat* (legal guardianship, primarily with the father). The Cube serves the child’s right to know and be cared for by both, regardless of custody label.  
- **Family Courts Act, 1964:** Establishes family courts with exclusive jurisdiction over family matters, including custody and visitation. The Cube can be proposed as a tool for supervised or facilitated contact in court orders.  
- **Child protection laws:** Provincial laws — such as the **Punjab Destitute and Neglected Children Act, 2004**, the **Sindh Child Protection Authority Act, 2011**, and the **KP Child Protection and Welfare Act, 2010** — mandate the state to safeguard children and can be the statutory basis for deploying Cubes as a preventive measure.  
- **National Commission on the Rights of the Child Act, 2017:** Establishes the NCRC with power to inquire into child rights violations and recommend systemic improvements. The Cube’s mission aligns squarely with the NCRC’s mandate.  
- **United Nations Convention on the Rights of the Child (UNCRC):** Ratified by Pakistan in 1990\. **Article 9** — the right of the child separated from parents to maintain contact — is at the heart of the Cube. Pakistan’s 2018 *Zainab Alert* response and other reforms show a growing state commitment to child protection.

---

## 9\. Glossary of Key Legal Terms

| English | Urdu / Arabic | Description |
| :---- | :---- | :---- |
| **Best interests of the child / Welfare principle** | بچے کی بہترین مفاد / فلاح و بہبود | The paramount consideration in custody and guardianship decisions. |
| **Hizanat** | حضانت | Physical custody of a young child; in classical Hanafi law, the mother has the right of *hizanat* for sons until age 7 and daughters until puberty, but courts may extend or vary this based on welfare. |
| **Wilayat** | ولایت | Legal guardianship, usually vested in the father, concerning the child’s property, education, and major decisions. |
| **Guardian and Ward** | سرپرست و محجور | Legal terms under the Guardians and Wards Act, 1890, for the person (guardian) responsible for a minor. |
| **Khula** | خلع | A wife’s right to seek dissolution of marriage through court, often returning her *dower*. |
| **Visitation / Meeting rights** | ملاقات کا حق | The right of a non‑custodial parent to spend time with the child. |
| **Family Court** | فیملی کورٹ / خاندانی عدالت | Specialized court under the Family Courts Act, 1964, dealing with marriage, divorce, maintenance, and custody. |
| **Child Protection Bureau** | چائلڈ پروٹیکشن بیورو | Provincial agency responsible for protecting children from abuse, neglect, and exploitation. |
| **NCRC** | قومی کمیشن برائے حقوق اطفال | National Commission on the Rights of the Child, the apex child‑rights body. |

---

## 10\. Five‑Year Roadmap

**From concept to national infrastructure**

| Phase | Period | Key Activities | Milestones |
| :---- | :---- | :---- | :---- |
| **1\. Foundation** | 0–12 months | Register Section 42 company with SECP. Complete first physical Cube prototype (screen, audio, LTE, Urdu audio prompts). Secure seed funding from a foundation. Sign MoU with one university and one Family Court bench. | Legal entity registered. Prototype tested with 5 families. 3 institutional letters of support. |
| **2\. Pilot** | 12–24 months | Deploy 150 Cubes in Lahore and one rural district, integrated with Family Court orders and a Child Protection Bureau. Collect quantitative and qualitative data. First evaluation report published. | 150 families actively using Cube. Evaluation report shared with NCRC and provincial government. |
| **3\. Evidence** | 24–36 months | Peer‑reviewed research publication. Adoption by at least one provincial CPWB as standard tool for non‑custodial contact. Expansion to 5 cities. | 2 academic articles. Contract with provincial government. 1,000 Cubes deployed. |
| **4\. Scale** | 36–48 months | 50+ districts across 2 provinces. Formal integration into Family Court rules through a Practice Direction. Staff of 30+. | 10,000 Cubes deployed. Court direction issued. Partner network of 20 legal‑aid clinics. |
| **5\. Public Infrastructure** | 48–60 months | Recognised by NCRC and Ministry of Human Rights as national preventive child‑protection infrastructure. Co‑funded through the Public Sector Development Programme (PSDP) and international donors. Regional pilots in Bangladesh and beyond. | 50,000+ Cubes. National policy guidance adopted. International recognition as a South Asian best practice. |

---

## 11\. Join This Movement

**Commission, research, advocate, create, govern**

*“Har bachcha haqdaar hai apne piyaar karne waale ki awaaz sunne ka. Har walid ya walida haqdaar hai apne bachche tak pahunchna. Story Cube yeh mumkin banata hai — saadgi, hifazat aur muhabbat ke saath.”*  
*(“Every child deserves to hear the voice of someone who loves them. Every parent deserves to reach their child. The Story Cube makes this possible — with simplicity, security, and warmth.”)*

We are building more than a device. We are building an evidence‑based, culturally rooted movement for children’s rights in Pakistan and beyond.

Whether you are a provincial minister, a Family Court judge, a child protection officer, a police human rights investigator, a university researcher, a corporate CSR leader, a religious scholar, or a parent who knows this struggle firsthand — **there is a place for you in this work.**

- **Commission:** Provincial Child Protection Bureaus, Family Courts, and social welfare departments: pilot the Cube as part of your early‑intervention toolkit.  
- **Research:** Universities and institutes: partner to evaluate impact on child well‑being, attachment, and resilience in the Pakistani context.  
- **Advocate:** Lawyers, judges, and parliamentarians: help shape the Cube into a recognized tool for contact and evidence, consistent with Islamic jurisprudence and constitutional values.  
- **Create:** Illustrators, storytellers, and voice artists: contribute to an open library of themes and stories in Urdu, Punjabi, Sindhi, Pashto, Balochi, and English.  
- **Govern:** Join our board or advisory council. Help guide the organization with transparency, cultural sensitivity, and unwavering commitment to the child.

---

**Story Cube | کہانی کا کیوب**  
*Connection that transforms — a bridge of love between parents and children*  
Aligned with the United Nations Convention on the Rights of the Child · Article 9  
Not‑for‑profit company under formation in Pakistan  
Made with care for families in every corner of the country  
