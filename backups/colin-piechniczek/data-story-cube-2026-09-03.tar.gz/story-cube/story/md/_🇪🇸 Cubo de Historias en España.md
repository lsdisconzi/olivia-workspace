---

## Cubo de Historias (Story Cube)

### Visión y Hoja de Ruta de Impacto – Documento España v3.1 · 2026 · Español

*“Tu vida debería estar dedicada a una causa, no a cosas.”* Ese espíritu impulsa Story Cube — una iniciativa que no busca retorno financiero, sino restaurar un derecho fundamental: el vínculo entre un niño y el progenitor que lo ama, incluso cuando viven separados.

---

### 1\. Por Qué Existe

Cuando un niño está separado de uno de sus progenitores — por distancia, ruptura u obstaculización deliberada del contacto — pierde algo insustituible: la voz cotidiana de quien lo ama.

Story Cube no es un producto que genera bien social como efecto secundario. Es una misión social que utiliza la tecnología como herramienta. Su forma institucional natural es, por tanto, la de una organización sin ánimo de lucro — donde el propósito gobierna la estructura, y no al revés.

Este documento define la visión y el camino para convertir Story Cube en un movimiento de interés público: una herramienta escalable, basada en evidencia, que protege el derecho del niño a la vida familiar, apoya al sistema de justicia de familia y ayuda a los servicios públicos a intervenir de forma temprana. Todo ello fundamentado en el **Artículo 9 de la Convención de las Naciones Unidas sobre los Derechos del Niño**, que garantiza el derecho del niño a mantener contacto regular con ambos progenitores, salvo que sea contrario a su interés superior.

---

### 2\. La Historia detrás del Cubo

De la distancia de un progenitor al derecho de cada niño a ser escuchado

Story Cube nació de una experiencia vivida: un progenitor al que se le impidió hablar con su hijo durante casi un mes. Llamadas desviadas, mensajes sin respuesta. Los pequeños momentos cotidianos — ¿qué has visto hoy? ¿te ha gustado? ¿qué has dibujado? — desaparecían en el silencio.

Después llegó una dolorosa toma de conciencia: el problema no es que falte una app o que el teléfono sea lento. El problema es que el contacto del niño con uno de sus progenitores se trata a menudo como un privilegio que concede el otro progenitor, cuando en realidad es un derecho que pertenece al propio niño.

*“Los niños necesitan voz. Tienen derechos. La comunicación con el progenitor no custodio debería ser una elección del niño — no algo filtrado por un intermediario.”*

El Cubo transforma esa idea en un objeto físico: una caja de madera bellamente elaborada, con pantalla, micrófono, altavoz y conectividad LTE integrada en una sola unidad. Vive en la habitación del niño. No se puede bloquear, desviar ni utilizar para otro fin. Solo transporta la voz y las historias del progenitor que ama al niño — y nada más de internet.

|  |  |
| :---- | :---- |
| **No es una app** | Dispositivo dedicado. No se puede desinstalar, secuestrar con TikTok ni usar para nada más. |
| **Imbloqueable** | La conexión LTE integrada garantiza que ningún intermediario pueda interrumpir la comunicación. |
| **Guiado por el niño** | Un botón para escuchar, uno para grabar. Sin necesidad del permiso de un adulto en la habitación. |
| **Amigable y seguro** | Un compañero de madera junto a la cama — no otra pantalla compitiendo por la atención. |

---

### 3\. El Problema

Ruptura familiar, obstaculización del contacto y el daño causado a los niños

En España viven aproximadamente **8,3 millones de niños y adolescentes de 0 a 17 años**, lo que representa alrededor del **17,5%** de la población. Los datos estadísticos disponibles muestran la gravedad de la situación:

- **Divorcios:** En 2024 se registraron en España alrededor de **84.000 divorcios** (cifra similar a la de 2023). La tasa de divorcios se sitúa en aproximadamente 1,7 por cada 1.000 habitantes.  
- **Menores afectados por rupturas:** Los divorcios y separaciones afectaron a unos **78.000 menores**, de los cuales:  
  - 20% tenían entre 0 y 5 años.  
  - 30% tenían entre 6 y 12 años.  
  - 50% tenían entre 13 y 17 años.  
- **Custodia de los hijos:** En los procesos de divorcio, los órganos judiciales acordaron:  
  - **43%** custodia compartida (cifra en aumento año tras año).  
  - **51%** custodia exclusiva de la madre.  
  - **4%** custodia exclusiva del padre.  
  - En el **2%** restante se atribuyó la custodia a otros familiares o instituciones.  
- **Sobrecarga del sistema:** Los Juzgados de Familia y los servicios sociales comunitarios soportan una elevada carga de trabajo. Anualmente ingresan más de **150.000 demandas de divorcio, separación y medidas paternofiliales**, y las ejecuciones por incumplimiento del régimen de visitas crecen de forma constante.  
- **Sistema de protección:** Los **Juzgados de Familia y de Menores**, las **Fiscalías de Menores**, los **Equipos Psicosociales** y los **Servicios Sociales** de las comunidades autónomas y ayuntamientos son las instituciones clave en la protección de los derechos de la infancia. La **Ley Orgánica 8/2021, de 4 de junio, de protección integral a la infancia y la adolescencia frente a la violencia** y la **Ley Orgánica 1/1996, de 15 de enero, de Protección Jurídica del Menor** constituyen el marco normativo central.

**Dónde fallan las herramientas actuales**

- **Teléfonos y aplicaciones son controlables.** El progenitor con el que convive el menor puede eliminar, restringir o monitorizar la comunicación. La voz del otro progenitor nunca llega al niño.  
- **Las pantallas genéricas son tóxicas para los más pequeños.** Los contenidos guiados por algoritmos y publicidad están diseñados para captar la atención, no para reforzar el vínculo afectivo.  
- **Los niños no tienen voz directa.** Dependen del dispositivo de otro, del horario de otro y a menudo hablan bajo observación.  
- **Los progenitores no custodios carecen de apoyo accesible.** El sistema de justicia de familia es costoso y difícil de navegar sin asistencia jurídica.

Más allá de las familias individuales, existe una laguna estructural en el sistema público: no hay una herramienta universalmente accesible y escalable que ayude a hacer efectivo el derecho del niño a la vida familiar. Story Cube está diseñado para llenar ese vacío — no como caridad, sino como un instrumento eficaz de protección pública y de intervención temprana.

---

### 4\. La Solución: Story Cube

Un cubo de madera. Pantalla, micrófono y altavoz integrados. Un único propósito.

El Cubo es deliberadamente radical en su sencillez. Es un dispositivo único y autónomo. Hace solo lo que debe hacer, y lo hace con calidez y cuidado.

| Función | Descripción |
| :---- | :---- |
| **Grabar** | Botón rojo. El niño habla, el otro progenitor recibe. |
| **Escuchar** | Botón verde. La voz de quien le ama, al instante. |
| **Compartir en TV** | Sustituir los dibujos animados pasivos por las historias que la familia ha creado junta. |
| **Doble nube** | LTE integrado significa que la conexión no se puede interrumpir. Ambos progenitores tienen siempre acceso seguro. |
| **Material** | Fabricado en madera con certificado FSC. Temáticas personalizables — espacio, animales, cuentos. |
| **Plataforma para progenitores** | Aplicación web para subir ilustraciones, elegir temas y acceder a un conjunto de herramientas de orientación legal. |

**Dónde estamos hoy:** Un MVP digital funcional ya opera en cualquier navegador — con motores de cuentos 2D y 3D, comandos de voz y seguimiento corporal — permitiendo a las primeras familias probar la experiencia al instante en tablet o teléfono. Es la semilla del Cubo físico, actualmente en fase de desarrollo, que traerá todas esas capacidades a un único y autónomo dispositivo de madera.

**Lo que no es:** No es una tablet. No es una app de móvil. No es una pantalla de YouTube. No es nada que pueda ser redirigido, bloqueado o llenado con contenidos no elegidos por los progenitores. La disciplina del Cubo es su mayor fortaleza.

---

### 5\. A Quién Beneficia

Niños, progenitores, sistema de justicia de familia, fuerzas de seguridad, corporaciones locales y toda la sociedad

**Para el niño**

- **Seguridad emocional:** Escuchar a diario la voz del progenitor ausente ayuda a mantener un apego seguro y protege la salud mental.  
- **Tiempo de pantalla saludable:** Sin algoritmos, sin anuncios, sin contenidos dañinos — solo historias que la familia elige.  
- **Voz propia:** El niño puede contactar cuando quiera. No cuando le han dado permiso. No bajo observación.  
- **Ritual antes de dormir:** Una historia grabada por el otro progenitor sustituye la ansiedad por separación por consuelo.

**Para el progenitor no custodio**

- **Presencia imbloqueable:** El LTE garantiza que cada mensaje llegue al niño. Ninguna app que eliminar.  
- **Apoyo en la navegación legal:** Un portal web seguro con guías en español, modelos de escritos y un archivo de evidencias — que ayuda a las partes a manejarse en el sistema judicial. Complementa, pero no sustituye, el asesoramiento jurídico independiente.  
- **Registro documentado:** Cada interacción queda sellada con fecha y hora, constituyendo una prueba objetiva del cuidado parental continuo en procedimientos judiciales.  
- **Parentalidad creativa:** Subir dibujos, crear historias animadas, personalizar el Cubo para el niño.

**Para los Juzgados de Familia y Equipos Psicosociales**

- **Canal de comunicación verificable:** El Cubo puede ser ordenado judicialmente como medio para facilitar el contacto — un canal objetivo y auditable, libre de interferencias.  
- **Registro de implicación parental:** Los registros con fecha y hora sustituyen las narrativas contradictorias con datos. Jueces, fiscales y equipos técnicos ven exactamente con qué frecuencia se conectó el progenitor y qué compartió.  
- **Reducción de la litigiosidad:** Cuando el contacto se registra objetivamente, las disputas sobre obstaculización o incumplimiento se reducen, liberando tiempo judicial y disminuyendo la hostilidad.

**Para las Fuerzas y Cuerpos de Seguridad y los Servicios Sociales**

- **Intervención temprana en conflictos familiares:** El Cubo puede desplegarse como parte de una estrategia preventiva, reduciendo las llamadas recurrentes y las actuaciones de los servicios sociales.  
- **Evidencia en procedimientos de protección y penales:** En casos donde un progenitor usa al menor para controlar al otro, el registro inmutable del Cubo puede servir de prueba — y puede configurarse para permitir únicamente un contacto seguro y monitorizado en supuestos de riesgo.  
- **Ahorro de costes:** Cada familia apoyada en esta fase temprana evita la escalada hacia la tutela institucional, procedimientos penales o de desamparo — ahorrando miles de euros por caso y previniendo el daño intergeneracional.

**Para universidades y centros de investigación** El Cubo funciona también como infraestructura de investigación para estudiar el impacto de la obstaculización del contacto en el desarrollo infantil. Mediante alianzas con universidades españolas (por ejemplo, la Universidad Complutense de Madrid, la Universidad de Barcelona, la Universidad Autónoma de Madrid, la Universidad de Valencia o la Universidad de Deusto) puede generar datos longitudinales sobre bienestar emocional, adquisición del lenguaje y apego — transformando la experiencia vivida en evidencia publicada que informe las políticas públicas.

**Para la sociedad** La ruptura de vínculos familiares genera costes intergeneracionales: mayores tasas de problemas de salud mental, fracaso escolar, adicciones y delincuencia juvenil. Cada familia que permanece conectada es una célula social fortalecida. Story Cube actúa en el punto de la prevención — asegurando que el vínculo amoroso sobreviva a la separación, reduciendo el sufrimiento infantil y evitando la profundización del daño. El retorno social de esta inversión se mide no en trimestres, sino en generaciones.

---

### 6\. El Camino Institucional

Una estructura sin ánimo de lucro al servicio de la misión

Story Cube se constituirá como una **organización sin ánimo de lucro** (fundación o asociación) conforme a la legislación española. Todos los fondos que obtenga — de subvenciones, contratos o donaciones — se reinvertirán íntegramente en la misión: producir más Cubos, mejorar la plataforma, financiar investigación independiente y expandirse a nuevos territorios.

El gobierno de la entidad lo ejercerá un **patronato o junta directiva** con experiencia en protección a la infancia, derecho de familia, ética digital y prestación de servicios públicos. La organización podrá solicitar, cuando corresponda, la **declaración de utilidad pública**, lo que facilitará las alianzas con el sector público, incluyendo la posibilidad de suscribir **convenios de colaboración** con administraciones autonómicas y locales.

Story Cube no pertenece a accionistas. Pertenece a la causa.

---

### 7\. Ecosistema de Apoyo

Fuentes de financiación en España, alianzas y estrategia en tres fases

Como herramienta sin ánimo de lucro diseñada para el sector público, Story Cube puede nutrirse de una combinación diversa de fuentes:

**A. Programas nacionales de subvenciones**

| Fuente | Descripción |
| :---- | :---- |
| **Subvenciones del IRPF – Tramo de fines sociales (Ministerio de Derechos Sociales y Agenda 2030\)** | Convocatoria anual que canaliza el 0,7% del IRPF hacia proyectos de acción social, incluyendo infancia y familia. Destina cientos de millones de euros cada año a entidades sin ánimo de lucro. |
| **Programa de Protección a la Familia y Atención a la Infancia** | Ayudas y subvenciones gestionadas por el Ministerio de Derechos Sociales, enfocadas en la parentalidad positiva, la mediación y el apoyo a familias vulnerables. |
| **Fondo de Bienes Decomisados (Plan Nacional sobre Drogas)** | Financia programas de prevención y apoyo a menores en riesgo, incluyendo aquellos afectados por conflictos familiares graves. |
| **Subvenciones del Ministerio de Justicia** | Líneas de apoyo a proyectos de mediación, asistencia jurídica y modernización de la Administración de Justicia, que pueden amparar herramientas como el Cubo. |

**B. Fondos Europeos**

| Fuente | Descripción |
| :---- | :---- |
| **Fondo Social Europeo Plus (FSE+) 2021-2027** | A través del Programa de Inclusión Social, Garantía Infantil y Lucha contra la Pobreza, España gestiona más de **8.000 millones de euros**. El Cubo puede encajar en las líneas de innovación social y apoyo a familias. |
| **Programa Ciudadanos, Igualdad, Derechos y Valores (CERV)** | Iniciativa de la UE que financia proyectos de protección de los derechos de la infancia, no discriminación y lucha contra la violencia. |
| **Next Generation EU – Mecanismo de Recuperación y Resiliencia** | Dentro del Plan de Recuperación, España ha destinado partidas específicas al refuerzo de los servicios sociales y la modernización de la justicia. |
| **Programa Interreg España-Portugal y España-Francia** | Oportunidades de cooperación transfronteriza para pilotar el Cubo en regiones limítrofes y compartir buenas prácticas. |

**C. Fundaciones y filantropía**

| Fuente | Descripción |
| :---- | :---- |
| **Fundación ”la Caixa”** | Principal fundación privada de España, con importantes programas de acción social y atención a la infancia (CaixaProinfancia). Potencial socio estratégico. |
| **Fundación ANAR** | Organización de referencia en la ayuda a niños y adolescentes en riesgo, con líneas de apoyo psicológico y jurídico. |
| **Save the Children España** | ONG internacional con presencia en España, centrada en la protección de la infancia y la lucha contra la pobreza infantil. |
| **Fundación Bancaria Ibercaja / Fundación Santander / Fundación BBVA** | Convocatorias de proyectos sociales que apoyan iniciativas innovadoras de cohesión social y bienestar. |
| **Fundación Mutua Madrileña** | Apoya proyectos de acción social, con un foco especial en infancia, salud y violencia de género. |

**D. Fondos autonómicos y locales**

| Fuente | Descripción |
| :---- | :---- |
| **Subvenciones de las Comunidades Autónomas** | Cada Consejería de Familia, Servicios Sociales o Igualdad convoca ayudas para proyectos que apoyen a la infancia y la mediación familiar. |
| **Ayuntamientos y Diputaciones** | Los servicios sociales municipales pueden contratar el Cubo como parte de sus programas de intervención y apoyo familiar. |
| **Pactos de Estado** | Fondos finalistas que llegan a las entidades locales para luchar contra la violencia de género o la violencia hacia la infancia, donde el Cubo puede ser una herramienta de protección. |

**E. Otros socios potenciales**

| Tipo de institución | Ejemplo concreto |
| :---- | :---- |
| **Ministerio de Derechos Sociales y Agenda 2030** | Dirección General de Derechos de la Infancia y de la Adolescencia |
| **Ministerio de Justicia** | Fiscalía General del Estado – Fiscalía de Menores |
| **Defensor del Pueblo / Defensor del Menor** | Instituciones autonómicas de defensa de derechos |
| **Juzgados de Familia y Menores** | Juzgados de Primera Instancia especializados |
| **Equipos Psicosociales** | Adscritos a la Administración de Justicia |
| **Servicios Sociales** | Centros de Servicios Sociales municipales y autonómicos |
| **ONGs de infancia** | Plataforma de Infancia, Aldeas Infantiles SOS, etc. |
| **Universidades** | UCM, UB, UAM, UV, Deusto, Autónoma de Barcelona, etc. |

**F. Estrategia en tres fases**

| Fase | Periodo | Acciones clave | Hitos |
| :---- | :---- | :---- | :---- |
| **Semilla** | 0–12 meses | Subvenciones de fundaciones, pilotaje con un ayuntamiento y un juzgado de familia, alianza académica. Primeros prototipos físicos. | Entidad jurídica registrada. Prototipo funcional. 3 alianzas estratégicas. |
| **Sostenibilidad** | 12–36 meses | Contratación directa por ayuntamientos y comunidades autónomas. Adopción por servicios sociales. Base de evidencia publicada. Expansión a varias CC.AA. | 150 familias apoyadas. Evaluación independiente. 2 publicaciones académicas. |
| **Escala** | 36+ meses | Despliegue nacional con cofinanciación estatal. Integración en resoluciones judiciales. Pilotajes internacionales. | 10.000+ Cubos. 5 partidos judiciales utilizan datos del Cubo. Reconocimiento como infraestructura pública. |

---

### 8\. Conformidad con la Legislación Española y el Marco de Protección

Story Cube está diseñado para situarse en la intersección de la arquitectura jurídica y de protección a la infancia en España:

- **Constitución Española, Art. 39:** Poderes públicos aseguran la protección social, económica y jurídica de la familia, y la protección integral de los hijos.  
- **Convención de la ONU sobre los Derechos del Niño:** España ratificó la Convención en 1990\. El Art. 9 garantiza el derecho del niño a mantener relaciones personales y contacto directo con ambos progenitores, salvo que sea contrario a su interés superior.  
- **Código Civil español (arts. 92 y ss., 154 y ss.):** Regula la patria potestad, la custodia, el régimen de visitas y comunicaciones.  
- **Ley Orgánica 1/1996, de 15 de enero, de Protección Jurídica del Menor:** Marco general de los derechos de los menores, incluido el derecho a relacionarse con sus progenitores.  
- **Ley Orgánica 8/2021, de 4 de junio, de protección integral a la infancia y la adolescencia frente a la violencia:** Refuerza los entornos seguros y las medidas de prevención y detección precoz.  
- **Ley de Enjuiciamiento Civil (arts. 748 y ss.):** Procedimientos de familia y medidas sobre hijos. Ejecución forzosa de las resoluciones de visitas.  
- **Ley Orgánica 1/2004, de 28 de diciembre, de Medidas de Protección Integral contra la Violencia de Género:** Especialmente relevante para la configuración de contactos seguros en casos de riesgo.  
- **Ley 26/2015, de 28 de julio, de modificación del sistema de protección a la infancia y a la adolescencia:** Introduce el interés superior del menor como principio rector y fortalece los mecanismos de intervención.  
- **Plan de Acción Estatal para la Implementación de la Garantía Infantil Europea:** Hoja de ruta nacional contra la pobreza y la exclusión infantil, que abre vías de financiación para herramientas como el Cubo.

---

### 9\. Hoja de Ruta a Cinco Años – España

| Fase | Periodo | Acciones clave | Hitos |
| :---- | :---- | :---- | :---- |
| **1\. Cimientos** | 0–12 meses | Constitución de la entidad sin ánimo de lucro en España. Finalización del primer prototipo físico del Cubo. Captación de financiación inicial. Formalización de alianza de investigación con una universidad española. | Entidad jurídica registrada. Prototipo funcional. 3 alianzas estratégicas. |
| **2\. Piloto** | 12–24 meses | Despliegue de 100–150 Cubos en 2–3 municipios, integración con servicios sociales y juzgados de familia. Recopilación de datos sobre protección y bienestar. Primera evaluación publicada. | 150 familias apoyadas. Primer informe independiente de evaluación. |
| **3\. Evidencia** | 24–36 meses | Publicación revisada por pares de los resultados. Adopción por al menos una Comunidad Autónoma. Expansión a 10 municipios. | 2 artículos académicos. Convenio con al menos una administración autonómica o local. |
| **4\. Escalado** | 36–48 meses | Más de 50 municipios. Uso formal en resoluciones judiciales. Equipo de 25+ personas. | 10.000 Cubos desplegados. 5 partidos judiciales utilizan los registros del Cubo. |
| **5\. Infraestructura pública** | 48–60 meses | El Cubo reconocido como parte de la infraestructura nacional de justicia de familia y apoyo temprano. Cofinanciado por la Administración General del Estado (Ministerio de Derechos Sociales). Pilotajes internacionales. | 50.000+ Cubos. Recomendaciones de política pública emitidas. Reconocimiento internacional. |

---

### 10\. Únete a Este Movimiento

Encarga, investiga, apoya, crea, gobierna

*“Cada niño merece escuchar la voz de alguien que le ama. Cada progenitor merece llegar a su hijo. Story Cube lo hace posible — con sencillez, seguridad y calidez.”*

Estamos construyendo más que un dispositivo. Estamos construyendo un movimiento por los derechos de la infancia, basado en evidencia y diseñado para el sector público.

Tanto si eres **alcalde o alcaldesa**, **profesional de servicios sociales**, **juez o jueza de familia**, **fiscal**, **psicólogo/a del equipo psicosocial**, **abogado/a de familia**, **investigador/a académico/a** o un **padre o madre** que conoce de primera mano esta lucha — hay un lugar para ti en este trabajo.

- **Encarga:** Ayuntamientos, servicios sociales y juzgados de familia: probad el Cubo en vuestro territorio como parte de vuestra estrategia de apoyo temprano o de protección pública.  
- **Investiga:** Universidades: estableced alianzas para evaluar el impacto en el bienestar infantil, el apego y el desarrollo del lenguaje.  
- **Apoya:** Abogados de familia, equipos psicosociales y jueces: ayudad a configurar el Cubo como herramienta reconocida de contacto y como elemento probatorio.  
- **Crea:** Ilustradores, narradores y animadores: contribuid a la biblioteca abierta de temáticas e historias.  
- **Gobierna:** Únete a nuestro patronato. Ayuda a dirigir la organización con transparencia y rigor.

---

## Cubo de Historias (Story Cube)

### La conexión que transforma — un puente de amor entre padres e hijos

**Conforme con la Convención de la ONU sobre los Derechos del Niño · Artículo 9** **Organización española sin ánimo de lucro en fase de constitución** **Creado con cuidado para las familias de todo el mundo**  
