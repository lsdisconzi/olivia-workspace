  
---

# Cubo de Histórias (Story Cube)

**Visão e Roteiro de Impacto – Brasil** *Documento v3.1 · 2026 · Português*

*“A sua vida deve ser aplicada a uma causa, não a coisas.”* É esse espírito que impulsiona o Story Cube — uma iniciativa que não busca retorno financeiro, mas a restauração de um direito fundamental: o vínculo entre uma criança e o pai ou a mãe que a ama, mesmo quando vivem separados.

---

## 1\. Por Que Isto Existe

Quando uma criança é mantida afastada de um dos genitores — por distância, separação ou obstrução deliberada — ela perde algo insubstituível: o som cotidiano da pessoa que a ama.

O Story Cube não é um produto que gera bem social como efeito colateral. É uma missão social que utiliza a tecnologia como ferramenta. A sua forma institucional natural é, portanto, uma **organização sem fins lucrativos** — onde o propósito governa a estrutura, e não o contrário.

Este documento estabelece a visão e o caminho para transformar o Story Cube num movimento de interesse público: uma ferramenta escalável, baseada em evidências, que protege o direito da criança à convivência familiar, apoia o sistema de justiça e ajuda os serviços públicos a intervirem de maneira precoce. Tudo ancorado no **Art. 9 da Convenção das Nações Unidas sobre os Direitos da Criança**, que garante o direito da criança a manter contato regular com ambos os genitores, salvo se tal for contrário ao seu superior interesse.

---

## 2\. A História por Trás do Cubo

**Da distância de um genitor ao direito de cada criança a ser ouvida**

O Story Cube nasceu de uma experiência vivida: um genitor impedido de falar com seu filho durante quase um mês. Chamadas desviadas, mensagens sem resposta. Os pequenos momentos cotidianos — *o que você viu hoje? gostou? o que desenhou?* — desaparecendo no silêncio.

O que se seguiu foi uma dolorosa constatação: o problema não é um aplicativo faltante ou um telefone lento. O problema é que o contato de uma criança com um dos genitores é tratado muitas vezes como um privilégio concedido pelo outro, quando na verdade é um direito que pertence à própria criança.

*“As crianças precisam de voz. Têm direitos. A comunicação com o genitor que não é o cuidador principal deveria ser uma escolha da criança — não algo filtrado por um intermediário.”*

O Cube transforma essa ideia em um objeto físico: uma caixa de madeira belamente trabalhada, com tela, microfone, alto-falante e conectividade LTE integrados em uma única unidade. Vive no quarto da criança. Não pode ser bloqueado, desviado ou reutilizado. Transporta apenas a voz e as histórias do genitor que a ama — e nada mais da internet.

| Não é um app | Inbloqueável | Liderado pela criança | Acolhedor e seguro |
| :---- | :---- | :---- | :---- |
| Um dispositivo dedicado. Não pode ser desinstalado, sequestrado pelo TikTok nem utilizado para mais nada. | LTE integrado garante que nenhum intermediário possa cortar a conexão. | Um botão para ouvir, um botão para gravar. Sem necessidade de permissão de um adulto no ambiente. | Um companheiro de madeira ao lado da cama — não mais uma tela competindo por atenção. |

---

## 3\. O Problema

**Separação familiar, obstrução do contato e o dano à infância**

No Brasil, a realidade da separação parental afeta milhões de crianças e adolescentes. Em **2024, o país registrou 428.301 divórcios**, uma queda de 2,8% em relação a 2023 (440.827).

- **Crianças em famílias separadas:** Embora não haja um dado único consolidado, o elevado número de divórcios indica que centenas de milhares de crianças e adolescentes vivem em lares com pais separados. O Brasil tem **10,6 milhões de crianças e adolescentes com idades entre 0 e 14 anos vivendo na extrema pobreza**, o que agrava a vulnerabilidade das famílias separadas.  
- **Guarda compartilhada:** Pela primeira vez, a **guarda compartilhada** se tornou a forma mais adotada nas separações no Brasil, chegando a **44,6%** dos divórcios judiciais em 2024, superando a guarda exclusiva da mulher (42,6%). Foram quase **82,2 mil sentenças judiciais** nesse sentido. A Lei da Guarda Compartilhada (Lei nº 11.698/2008) estabeleceu a guarda compartilhada como regra geral, privilegiando o convívio da criança com ambos os genitores. Em 2014, com a Lei 13.058, a guarda compartilhada deixou de ser mera opção e se transformou em regra.  
- **Sobrecarga do sistema de justiça:** As Varas de Família e as Varas da Infância e Juventude enfrentam alta carga de trabalho, com processos que muitas vezes se arrastam por anos, prejudicando as crianças.  
- **Sistema de proteção:** O **Sistema de Garantia de Direitos da Criança e do Adolescente (SGDCA)**, instituído a partir do Estatuto da Criança e do Adolescente (ECA), atua na defesa, promoção e controle social dos direitos da infância.

**Onde as ferramentas atuais falham**

- **Telefones e aplicativos são controláveis.** O genitor residente pode excluir, restringir ou monitorar a comunicação. A voz do outro genitor nunca chega à criança.  
- **As telas comuns são tóxicas para crianças pequenas.** Conteúdos guiados por algoritmos e publicidade são projetados para capturar atenção, não para nutrir o apego.  
- **As crianças não têm voz direta.** Dependem do dispositivo de outra pessoa, do horário de outra pessoa e, muitas vezes, falam sob observação.  
- **Os genitores não residentes carecem de apoio acessível.** O sistema de justiça familiar é caro e difícil de navegar sozinho.

Além das famílias individuais, o Estado tem uma lacuna estrutural: não existe uma ferramenta amplamente disponível e escalável para ajudar a defender o direito da criança à convivência familiar. O Story Cube foi projetado para preencher essa lacuna — não como caridade, mas como um instrumento eficaz de proteção pública e intervenção precoce.

---

## 4\. A Solução: O Story Cube

**Um cubo de madeira. Tela, microfone e alto-falante integrados. Um único propósito.**

O Cube é deliberadamente radical em sua simplicidade. É um dispositivo único e autônomo. Faz apenas o que precisa fazer, e o faz com calor e cuidado.

- **Gravar:** Um botão vermelho. A criança fala, o outro genitor recebe.  
- **Ouvir:** Um botão verde. A voz da pessoa que a ama, instantaneamente.  
- **Compartilhar na TV:** Substituir desenhos animados passivos por histórias que a família criou junto.  
- **Dupla nuvem:** LTE integrado significa que a conexão não pode ser cortada. Ambos os genitores têm sempre acesso seguro.  
- **Fabricado em madeira certificada FSC.** Temas personalizáveis — espaço, animais, contos de fadas.  
- **Plataforma para genitores:** Um aplicativo web para enviar ilustrações, escolher temas e acessar um kit de ferramentas de navegação legal.

**Onde estamos hoje:** Um MVP digital funcional já funciona em qualquer navegador — com motores de histórias 2D e 3D, comandos de voz e rastreamento corporal — permitindo que as primeiras famílias testem a experiência imediatamente em um tablet ou telefone. Este é o embrião do Cube físico, que está agora em desenvolvimento e trará toda essa capacidade para um único dispositivo autônomo de madeira.

**O que não é:** Não é um tablet. Não é um aplicativo de telefone. Não é uma tela de YouTube. Não é nada que possa ser desviado, bloqueado ou preenchido com conteúdo que os genitores não tenham escolhido. A disciplina do Cube é sua maior força.

---

## 5\. Quem se Beneficia

**Crianças, genitores, o sistema de justiça, forças de segurança, municípios e a sociedade como um todo**

### Para a criança

- **Segurança emocional:** Ouvir a voz do genitor ausente todos os dias ajuda a preservar o apego seguro e protege a saúde mental.  
- **Tempo de tela saudável:** Sem algoritmos, sem anúncios, sem conteúdo prejudicial — apenas as histórias que a família escolhe.  
- **Uma voz própria:** A criança pode contatar quando quiser. Não quando é permitida. Não sob vigilância.  
- **Ritual de hora de dormir:** Uma história gravada pelo outro genitor substitui a ansiedade da separação pelo conforto.

### Para o genitor não residente

- **Presença inbloqueável:** O LTE garante que cada mensagem chegue à criança. Nenhum aplicativo para ser excluído.  
- **Apoio à navegação legal:** Um portal web seguro com guias em português claro, modelos para declarações e um arquivo de evidências — ajudando os litigantes a navegar no sistema judicial. Complementa, mas não substitui, a assessoria jurídica independente.  
- **Registro documentado:** Cada interação é registrada com data e hora, fornecendo prova objetiva de cuidado parental contínuo para procedimentos judiciais.  
- **Parentalidade criativa:** Enviar desenhos, construir histórias animadas, personalizar o Cube para a criança.

### Para o Poder Judiciário (Varas de Família e Varas da Infância e Juventude) e o Ministério Público

- **Canal de comunicação verificável:** O Cube pode ser ordenado pelo juiz como forma de facilitar o contato — um canal objetivo, auditável e livre de interferências.  
- **Registro de envolvimento parental:** Registros com data e hora substituem narrativas contraditórias por dados. Juízes e promotores veem exatamente com que frequência um genitor se conectou e o que compartilhou.  
- **Redução de litígios:** Quando o contato é registrado objetivamente, as disputas sobre obstrução e descumprimento diminuem, liberando tempo judicial e reduzindo a animosidade.

### Para os Conselhos Tutelares, os Municípios e as Forças de Segurança

- **Intervenção precoce em conflitos familiares:** O Cube pode ser implementado como parte de uma estratégia de prevenção, reduzindo chamadas reiteradas aos serviços e encaminhamentos para o sistema de proteção.  
- **Evidência para investigações de proteção e criminais:** Em casos onde um genitor utiliza a criança para controlar o outro, o registro imutável do Cube pode servir como prova — e pode ser configurado para permitir apenas contato seguro e monitorado quando existe risco.  
- **Economia de custos:** Cada família apoiada nesta fase precoce evita a escalada para procedimentos de acolhimento institucional, medidas de proteção ou justiça penal — economizando milhares de reais por caso e prevenindo danos intergeracionais.

### Para universidades e centros de pesquisa

O Cube funciona também como infraestrutura de pesquisa sobre o impacto da obstrução do contato no desenvolvimento infantil. Por meio de parcerias com universidades brasileiras (USP, UNICAMP, UFRJ, UFMG, PUC-Rio, entre outras), pode gerar dados longitudinais sobre bem-estar emocional, aquisição de linguagem e apego — transformando a experiência vivida em evidência publicada que molda as políticas públicas.

### Para a sociedade

A ruptura dos laços familiares cria custos intergeracionais: maiores taxas de problemas de saúde mental, fracasso escolar, consumo de substâncias e delinquência juvenil. Cada família que permanece conectada é uma célula social fortalecida. O Story Cube atua no ponto da prevenção — garantindo que um vínculo de amor sobreviva à separação, reduzindo o sofrimento infantil e impedindo que o dano se agrave. O retorno social desse investimento não se mede em trimestres, mas em gerações.

---

## 6\. Caminho Institucional

**Uma estrutura sem fins lucrativos a serviço da missão**

O Story Cube será estabelecido como uma **organização da sociedade civil** (OSC), sem fins lucrativos, ao amparo do Código Civil Brasileiro (Lei nº 10.406/2002) e da legislação aplicável. Todos os recursos gerados — seja por subvenções, contratos ou doações — são reinvestidos integralmente na missão: fabricar mais Cubes, melhorar a plataforma, financiar pesquisa independente e expandir para novas áreas.

A governança será exercida por um **conselho de administração** com experiência em proteção da infância, direito de família, ética digital e prestação de serviços públicos. A organização pode, a seu tempo, solicitar o **registro no Conselho Nacional dos Direitos da Criança e do Adolescente (CONANDA)**  e o **cadastro nos Fundos Municipal, Estadual e Nacional dos Direitos da Criança e do Adolescente** , o que melhor permita a parceria com o setor público, incluindo a possibilidade de celebrar **termos de colaboração** e **termos de fomento** com o poder público.

O Story Cube não pertence a acionistas. Pertence à causa.

---

## 7\. Ecossistema de Apoio

**Fontes de financiamento no Brasil, parcerias e uma estratégia em três fases**

Como ferramenta sem fins lucrativos projetada para o setor público, o Story Cube pode recorrer a uma combinação diversificada de recursos:

**A. Financiamento Público Nacional**

- **Fundo Nacional para a Criança e o Adolescente (FNCA):** Instituído pela Lei nº 8.242/1991, com orçamento atualizado de **R$ 22,15 milhões**. Gerido pelo CONANDA, destina-se a financiar programas e projetos voltados à promoção e defesa dos direitos da criança e do adolescente.  
- **Fundos Estaduais e Municipais dos Direitos da Criança e do Adolescente (FMDCA):** Fundos especiais que podem financiar projetos locais.  
- **Ministério dos Direitos Humanos e da Cidadania (MDHC):** Órgão responsável pela formulação e implementação de políticas para crianças e adolescentes.  
- **Conselho Nacional de Justiça (CNJ):** Por meio de seus programas e prêmios para a infância e juventude, pode apoiar e reconhecer iniciativas inovadoras.  
- **Programas de transferência de renda:** O **Bolsa Família** e outros programas sociais, embora não sejam fontes diretas de financiamento, atendem famílias em situação de vulnerabilidade que podem se beneficiar do Cube.

**B. Editais de Fundações e Organizações Filantrópicas**

- **Fundação BB (Banco do Brasil):** Edital de apoio a projetos sociais.  
- **Instituto ACP:** Chamada de Projetos para fortalecimento de iniciativas sociais.  
- **Instituto Itaú Social:** Editais voltados ao desenvolvimento institucional de organizações da sociedade civil.  
- **Fundação Maria Cecilia Souto Vidigal:** Atua na primeira infância.  
- **Fundação Telefônica Vivo:** Projetos de inovação social e educação.

**C. Cooperação Internacional**

- **UNICEF Brasil:** Presente no Brasil desde 1950, atua para garantir os direitos constitucionais da infância e adolescência e pode ser um parceiro estratégico.  
- **Agências de cooperação e organismos multilaterais** com programas em infância e proteção social.

**D. Parcerias Público-Privadas e Mecenas**

- **Empresas com programas de responsabilidade social:** Podem apoiar o Cube por meio de patrocínios ou doações.  
- **Pessoas físicas e jurídicas:** Doações podem ser deduzidas do Imposto de Renda, nos termos da Lei nº 9.249/1995, quando destinadas a fundos da criança e do adolescente.

**E. Potenciais Instituições Colaboradoras**

| Tipo de Instituição | Entidade Específica |
| :---- | :---- |
| Conselho Nacional dos Direitos da Criança e do Adolescente | CONANDA |
| Ministério dos Direitos Humanos e da Cidadania | MDHC |
| Conselho Nacional de Justiça | CNJ |
| Ministério Público | MP (nos Estados e na União) |
| Poder Judiciário | Varas de Família / Varas da Infância e Juventude / TJs |
| Municípios | Secretarias de Assistência Social / Conselhos Tutelares |
| Universidades | USP, UNICAMP, UFRJ, UFMG, PUC-Rio, etc. |

### F. Estratégia em três fases

1. **Semente (Anos 1–2):** Subvenções de fundações, piloto inicial com um município e uma Vara de Família, parceria acadêmica estabelecida. Primeiros protótipos físicos implementados.  
2. **Sustentabilidade (Anos 3–4):** Contratação direta por municípios, adoção pelo sistema de garantia de direitos (SGDCA), base de evidências publicada, expansão para múltiplos estados.  
3. **Escala (Ano 5 em diante):** Implementação nacional com cofinanciamento do governo federal (FNCA e outros), integração em decisões judiciais e rotas de proteção. Pilotos internacionais em paralelo.

---

## 8\. Alinhamento com o Marco Legal e de Proteção Brasileiro

O Story Cube está projetado para se situar na interseção da arquitetura legal e de proteção infantil brasileira:

- **Constituição Federal de 1988, Art. 227:** Estabelece que é dever da família, da sociedade e do Estado assegurar à criança e ao adolescente, com absoluta prioridade, o direito à vida, à saúde, à alimentação, à educação, ao lazer, à profissionalização, à cultura, à dignidade, ao respeito, à liberdade e à convivência familiar e comunitária.  
    
- **Estatuto da Criança e do Adolescente (ECA) – Lei nº 8.069/1990:** A principal lei de proteção da infância no Brasil. O **Art. 19** estabelece que toda criança ou adolescente tem direito a ser criado e educado no seio de sua família. O **Art. 15** garante o direito à liberdade, ao respeito e à dignidade.  
    
- **Lei da Guarda Compartilhada (Lei nº 11.698/2008):** Estabeleceu a guarda compartilhada como regra geral, privilegiando o convívio da criança com ambos os genitores. A **Lei nº 13.058/2014** reforçou a guarda compartilhada como regra, deixando de ser mera opção. A guarda compartilhada, entretanto, não se aplica quando há prática de violência doméstica.  
    
- **Lei nº 12.010/2009 (Lei Nacional da Adoção):** Incluiu no ECA disposições sobre o direito à convivência familiar e comunitária.  
    
- **Sistema de Garantia de Direitos da Criança e do Adolescente (SGDCA):** Instituído a partir do ECA, composto por três eixos estratégicos: Defesa, Promoção de Direitos e Controle Social. Atua em rede para garantir os direitos da infância.  
    
- **Lei nº 8.242/1991:** Criou o CONANDA e instituiu o Fundo Nacional para a Criança e o Adolescente (FNCA).  
    
- **Convenção das Nações Unidas sobre os Direitos da Criança (CDN):** O Brasil ratificou a Convenção e a incorporou ao ordenamento jurídico. O **Art. 9** garante o direito da criança a manter contato com ambos os genitores.

---

## 9\. Glossário de Termos Legais

| Português | Descrição |
| :---- | :---- |
| **Guarda compartilhada** | Modalidade de guarda em que ambos os genitores compartilham a responsabilidade e a tomada de decisões sobre a criança, privilegiando o convívio com ambos. |
| **Guarda unilateral / exclusiva** | Modalidade em que a guarda é atribuída a apenas um dos genitores. |
| **Convivência familiar** | Direito da criança de ser criada e educada no seio de sua família. |
| **Interesse superior da criança** | Princípio que orienta todas as decisões que afetam a criança, priorizando seu bem-estar e desenvolvimento. |
| **Responsabilidade parental** | Deveres e obrigações dos pais em relação aos filhos (antes denominada "pátrio poder"). |
| **Poder familiar** | Conjunto de direitos e deveres dos pais em relação aos filhos (termo ainda utilizado no Código Civil). |
| **Conselho Tutelar** | Órgão permanente e autônomo, não jurisdicional, encarregado pela sociedade de zelar pelo cumprimento dos direitos da criança e do adolescente. |
| **Vara da Infância e Juventude** | Órgão do Poder Judiciário especializado em causas que envolvem crianças e adolescentes. |
| **SGDCA** | Sistema de Garantia de Direitos da Criança e do Adolescente. |
| **CONANDA** | Conselho Nacional dos Direitos da Criança e do Adolescente. |
| **FNCA** | Fundo Nacional para a Criança e o Adolescente. |

---

## 10\. Roteiro de Cinco Anos

**Do conceito à infraestrutura nacional**

| Fase | Período | Atividades Principais | Marcos |
| :---- | :---- | :---- | :---- |
| **1\. Fundação** | 0–12 meses | Constituir a organização da sociedade civil. Completar o primeiro protótipo físico do Cube (tela, áudio, LTE). Obter financiamento inicial. Formalizar parceria de pesquisa com uma universidade brasileira. | Entidade legal registrada. Protótipo funcional pronto. 3 parcerias estratégicas. |
| **2\. Piloto** | 12–24 meses | Implementar 100–150 Cubes em 2–3 municípios, integrados com Conselhos Tutelares e Varas de Família. Coletar dados de proteção e bem-estar. Primeira avaliação publicada. | 150 famílias apoiadas. Primeiro relatório de avaliação independente. |
| **3\. Evidência** | 24–36 meses | Publicação revisada por pares dos resultados. Adoção pelo sistema de garantia de direitos (SGDCA). Expansão para 10 municípios. | 2 artigos acadêmicos. Contrato com pelo menos um município/Conselho Tutelar. |
| **4\. Escala** | 36–48 meses | 50+ municípios. Uso formal em decisões judiciais. Equipe de 25+ pessoas. | 10.000 Cubes implementados. 5 comarcas utilizando dados do Cube. |
| **5\. Infraestrutura Pública** | 48–60 meses | Cube reconhecido como parte da infraestrutura nacional de justiça familiar e apoio precoce. Cofinanciado pelo governo federal (FNCA). Pilotos internacionais. | 50.000+ Cubes. Orientação política emitida. Reconhecimento internacional. |

---

## 11\. Junte-se a Este Movimento

**Comissione, pesquise, defenda, crie, governe**

*“Toda criança merece ouvir a voz de alguém que a ama.* *Todo genitor merece alcançar seu filho.* *O Story Cube torna isso possível — com simplicidade, segurança e calor.”*

Estamos construindo mais que um dispositivo. Estamos construindo um movimento pelos direitos da infância, baseado em evidências e projetado para o setor público.

Seja você um prefeito, um membro de Conselho Tutelar, um juiz de Vara de Família, um promotor de Justiça, um pesquisador acadêmico, um serviço de apoio a vítimas de violência, ou um genitor que conhece essa luta em primeira mão — **há um lugar para você neste trabalho.**

- **Comissionar:** Municípios, Conselhos Tutelares e Varas de Família: testem o Cube em sua área como parte de sua estratégia de apoio precoce ou proteção pública.  
- **Pesquisar:** Universidades: estabeleçam parcerias para avaliar o impacto no bem-estar infantil, no apego e no desenvolvimento da linguagem.  
- **Defender:** Profissionais do direito de família, membros do Ministério Público e do Poder Judiciário: ajudem a moldar o Cube como uma ferramenta reconhecida para o contato e a evidência.  
- **Criar:** Ilustradores, narradores e animadores: contribuam para uma biblioteca aberta de temas e histórias.  
- **Governar:** Junte-se ao nosso conselho de administração. Ajude a guiar a organização com transparência e rigor.

---

**Cubo de Histórias (Story Cube)** *Conexão que transforma — uma ponte de amor entre pais e filhos* Alineado com a Convenção das Nações Unidas sobre os Direitos da Criança · Art. 9 Organização da sociedade civil brasileira em formação Feito com cuidado para famílias em todas as partes

---

