Here is a complete, standalone UK version of the Cubo de Histórias vision document, aligned with safeguarding language, UK law, and the kind of government delivery focus that Darren Bradley’s career represents. You can present this as a ready-to-share proposal for UK stakeholders.

---

# Cubo de Histórias (Story Cube)

**Vision & Impact Roadmap – UK Edition** *Document v3.1 · 2026 · English*

*“Your life should be applied to a cause, not to things.”*  
That spirit drives the Story Cube — an initiative that seeks not financial return, but the restoration of a fundamental right: the bond between a child and the parent who loves them, even when they live apart.

---

## 1\. Why This Exists

When a child is kept apart from a parent — by distance, separation, or deliberate obstruction — they lose something irreplaceable: the everyday sound of the person who loves them.

The Story Cube is not a product that creates social good as a side effect. It is a social mission that uses technology as a tool. That is why its natural institutional form is a **not-for-profit organisation** — where purpose governs structure, not the other way around.

This document sets out the vision and the path to building the Story Cube into a public-interest movement: a scalable, evidence-based tool that protects children’s right to family life, supports the family justice system, and helps public services intervene earlier. Everything is anchored in **Article 9 of the UN Convention on the Rights of the Child**, which guarantees a child’s right to maintain regular contact with both parents unless that is contrary to their best interests.

---

## 2\. The Story Behind the Cube

**From one parent’s distance to every child’s right to be heard**

The Story Cube was born from a lived experience: a parent blocked from speaking with their child for almost a month. Calls forwarded, messages unanswered. The small daily moments — *what did you watch today? did you enjoy it? what did you draw?* — vanishing into silence.

What followed was a painful realisation: the problem isn’t a missing app or a slow phone. The problem is that a child’s contact with one parent is often treated as a privilege granted by the other, when in fact it is a right that belongs to the child themselves.

*“Children need a voice. They have rights. Communication with the parent who is not the main carer should be the child’s choice — not something filtered through an intermediary.”*

The Cube transforms that idea into a physical object: a beautifully crafted wooden box, with a screen, microphone, speaker, and LTE connectivity all embedded as one unit. It lives in the child’s bedroom. It cannot be blocked, diverted, or repurposed. It carries only the voice and stories of the parent who loves them — and nothing else from the internet.

| Not an app | Unblockable | Child-led | Warm and safe |
| :---- | :---- | :---- | :---- |
| A dedicated device. It cannot be uninstalled, hijacked by TikTok, or used to access anything else. | Built-in LTE ensures no intermediary can sever the connection. | One button to listen, one button to record. No permission needed from an adult in the room. | A wooden bedside companion — not another screen fighting for attention. |

---

## 3\. The Problem

**Family separation, contact obstruction, and the harm to children**

In the UK, around **3.2 million children** live in separated families (Office for National Statistics). In over 86% of lone-parent households, the parent with care is the mother. The non-resident parent — overwhelmingly the father — often depends on the goodwill of the other parent for everyday contact. When that goodwill breaks down, the child pays the price.

- **Emotional harm:** Prolonged obstruction of contact is increasingly recognised as a form of emotional abuse. Children caught in high-conflict separation show elevated rates of anxiety, depression, and behavioural difficulties.  
- **Family court overload:** Over 50,000 new private family law cases were started in England and Wales in 2023, many involving disputes over child arrangements. Courts often have to rely on contested, subjective accounts.  
- **System gap:** Despite clear statutory duties under the Children Act 1989 and the Human Rights Act 1998, local authorities and family courts lack a simple, objective tool to preserve and evidence parental contact in real time.

**Where current tools fail**

- **Phones and apps are gatekept.** The resident parent can delete, restrict, or monitor communication. The other parent’s voice never reaches the child.  
- **Ordinary screens are toxic to young children.** Algorithm-driven content and advertising are designed to capture attention, not to nurture attachment.  
- **Children have no direct voice.** They rely on someone else’s device, someone else’s timetable, and often speak under observation.  
- **Non-resident parents lack affordable support.** The family justice system is expensive and hard to navigate alone. Most parents manage without any strategic guidance.

Beyond individual families, the state has a structural gap: there is no widely deployed, scalable tool to help uphold the child’s right to family life. The Story Cube is designed to fill that gap — not as charity, but as an effective public protection and early intervention instrument.

---

## 4\. The Solution: The Story Cube

**A wooden cube. Screen, microphone and speaker built in. One purpose.**

The Cube is deliberately radical in its simplicity. It is a single, self-contained device. It does only what it needs to do, and it does it with warmth and care.

- **Record:** A red button. The child speaks, the other parent receives.  
- **Listen:** A green button. The voice of the person who loves them, instantly.  
- **Share to TV:** Swap passive cartoons for stories the family has created together.  
- **Dual cloud:** Built-in LTE means the connection cannot be cut. Both parents always have secure access.  
- **Made from FSC-certified wood.** Themes are customisable — space, animals, fairy tales.  
- **Parent platform:** A web app for uploading illustrations, choosing themes, and accessing a legal navigation toolkit.

**Where we are today:** A functioning digital MVP already runs in any browser — with 2D and 3D story engines, voice commands, and body tracking — allowing the first families to test the experience immediately on a tablet or phone. This is the embryo of the physical Cube, which is now in development and will bring all that capability into a single, autonomous wooden device.

**What it is not:** It is not a tablet. Not a phone app. Not a YouTube screen. It is nothing that can be diverted, blocked, or filled with content the parents haven’t chosen. The discipline of the Cube is its greatest strength.

---

## 5\. Who Benefits

**Children, parents, the family justice system, police and local authorities — and society as a whole**

### For the child

- **Emotional safety:** Hearing the absent parent’s voice every day helps preserve secure attachment and protects mental health.  
- **Healthy screen time:** No algorithms, no adverts, no harmful content — only the stories the family chooses.  
- **A voice of their own:** The child can reach out whenever they want. Not when permitted. Not under surveillance.  
- **Bedtime ritual:** A story recorded by the other parent replaces the anxiety of separation with comfort.

### For the non-resident parent

- **Unblockable presence:** LTE ensures every message reaches the child. No app to be deleted.  
- **Legal navigation support:** A secure web portal with plain-English guides, templates for position statements, and an evidence locker — helping litigants in person navigate the family court system. It complements, but does not replace, independent legal advice.  
- **Documented engagement:** Every interaction is timestamped and recorded, providing objective proof of continuous parental care for court proceedings.  
- **Creative parenting:** Upload drawings, build animated stories, personalise the Cube for the child.

### For the Family Court, CAFCASS and the Judiciary

- **Verifiable communication channel:** The Cube can be ordered by the court as a way of facilitating contact — an objective, auditable channel free from interference.  
- **Record of parental engagement:** Timestamped logs replace contradictory narratives with data. Judges and guardians see exactly how often a parent connected and what they shared.  
- **Reducing litigation:** When contact is objectively recorded, disputes over obstruction and non-compliance decline, freeing up court time and reducing acrimony.

### For Police and Local Authorities

- **Early intervention in family conflict:** The Cube can be deployed as part of a triage and prevention strategy, reducing repeat calls for service and safeguarding referrals.  
- **Evidence for safeguarding and criminal investigations:** In cases where one parent uses the child to control the other, the Cube provides an unfiltered, immutable record that can be used in investigations under the Serious Crime Act 2015 (coercive control) or the Domestic Abuse Act 2021\.  
- **Cost avoidance:** Each family supported at this early stage avoids escalation into statutory child protection, care proceedings, or criminal justice — saving thousands of pounds per case and preventing intergenerational harm.

### For universities and research centres

The Cube also functions as research infrastructure on the impact of contact obstruction on child development. Through partnerships with UK universities, it can generate longitudinal data on emotional well-being, language acquisition, and attachment — turning lived experience into published evidence that shapes policy.

### For society

The rupture of family bonds creates intergenerational costs: higher rates of mental ill-health, school exclusion, substance misuse, and youth offending. Every family that remains connected is a strengthened social cell. The Story Cube works at the point of prevention — ensuring that a loving bond survives separation, reducing child suffering, and stopping harm before it escalates. The social return on that investment is measured not in quarters, but in generations.

---

## 6\. Institutional Path

**A not-for-profit structure to serve the mission**

The Story Cube will be established as a not-for-profit social enterprise. All resources generated — whether from grants, contracts, or donations — are reinvested entirely into the mission: manufacturing more Cubes, improving the platform, funding independent research, and expanding to new areas.

Governance will be exercised through a board of trustees with expertise in child safeguarding, family law, digital ethics, and public service delivery. In time, the organisation can seek registration with the Charity Commission or incorporate as a Community Interest Company (CIC), whichever best enables partnership with the public sector.

The Story Cube does not belong to shareholders. It belongs to the cause.

---

## 7\. Ecosystem of Support

**UK funding streams, partnerships, and a three-wave strategy**

As a not-for-profit tool designed for the public sector, the Story Cube can draw on a diverse mix of resources:

- **Police and Crime Commissioners (PCCs) / Violence Reduction Units:** Funding for early intervention and public protection innovation.  
- **Home Office:** Early intervention grants, domestic abuse perpetrator programmes, and serious violence prevention.  
- **Ministry of Justice:** Innovation Fund, support for litigants in person, family justice modernisation.  
- **Department for Education:** Children’s social care innovation programme, family hubs, strengthening families.  
- **Local authorities:** Commissioning of family support services through children’s services budgets.  
- **Trusts and foundations:** Nuffield Foundation, NSPCC, Esmée Fairbairn Foundation, BBC Children in Need, the National Lottery Community Fund.  
- **Research councils:** ESRC and UKRI for longitudinal studies on child wellbeing and family contact.

### Three-wave strategy

1. **Seed (Years 1–2):** Foundation grants, early pilot with one local authority and one police force, academic partnership established. First physical prototypes deployed.  
2. **Sustain (Years 3–4):** Direct commissioning by local authorities, adoption by Violence Reduction Units, evidence base published, scaling to multiple regions.  
3. **Scale (Year 5 onwards):** National rollout with co-funding from central government, embedding in family court orders and safeguarding pathways. International pilots (Italy, Chile) in parallel.

---

## 8\. Alignment with UK Law and Safeguarding Frameworks

The Story Cube is designed to sit at the intersection of the UK’s legal and child protection architecture:

- **Children Act 1989:** The child’s welfare is paramount. The Cube provides direct evidence of what the child says and feels, helping courts make orders that reflect their lived experience.  
- **Human Rights Act 1998, Article 8:** The right to respect for family life. The Cube is a practical tool for upholding that right when distance or obstruction threatens it.  
- **Domestic Abuse Act 2021:** Emotional and psychological harm are recognised forms of abuse. Where a child is used as a weapon against the other parent, the Cube’s immutable record can serve as evidence of coercive control — and can be configured to allow only safe, monitored contact where risk is present.  
- **Working Together to Safeguard Children (2023):** The statutory guidance emphasises early help and the need for objective, multi-agency information. The Cube provides a new source of direct safeguarding data.  
- **Serious Violence Duty:** The Cube contributes to prevention by addressing family breakdown, a known risk factor for later violence.

---

## 9\. Five-Year Roadmap

**From concept to national infrastructure**

| Phase | Period | Key Activities | Milestones |
| :---- | :---- | :---- | :---- |
| **1\. Foundation** | 0–12 months | Establish the not-for-profit entity. Complete first physical Cube prototype (screen, audio, LTE). Secure initial grant funding. Formalise research partnership with a UK university. | Legal entity registered. Functional prototype ready. 3 strategic partnerships. |
| **2\. Pilot** | 12–24 months | Deploy 100–150 Cubes in 2–3 local authority areas, integrated with family support and early help teams. Collect safeguarding and well-being data. First round of evaluation published. | 150 families supported. First independent evaluation report. |
| **3\. Evidence** | 24–36 months | Peer-reviewed publication of outcomes. Adoption by a Violence Reduction Unit. Expand to 10 local authorities. | 2 academic papers. Contract with at least one PCC. |
| **4\. Scale** | 36–48 months | 50+ local authorities. Formal use in family court directions. Team of 25+. | 10,000 Cubes deployed. 5 court areas using Cube data. |
| **5\. Public Infrastructure** | 48–60 months | Cube recognised as part of national family justice and early help infrastructure. Co-funded by central government. International pilots begin. | 50,000+ Cubes. Policy guidance issued. International recognition. |

---

## 10\. Join This Movement

**Commission, research, advocate, create, govern**

*“Every child deserves to hear the voice of someone who loves them.*  
*Every parent deserves to reach their child.*  
*The Story Cube makes that possible — with simplicity, safety, and warmth.”*

We are building more than a device. We are building a movement for children’s rights, grounded in evidence and designed for the public sector.

Whether you are a Police and Crime Commissioner, a Director of Children’s Services, a family judge, an academic researcher, a domestic abuse service, or a parent who knows this struggle firsthand — **there is a place for you in this work.**

- **Commission:** PCCs and local authorities: pilot the Cube in your area as part of your early help or public protection strategy.  
- **Research:** Universities: partner with us to evaluate the impact on child wellbeing, attachment and language development.  
- **Advocate:** Family law professionals and CAFCASS: help shape the Cube as a recognised tool for contact and evidence.  
- **Create:** Illustrators, storytellers and animators: contribute to an open library of themes and stories.  
- **Govern:** Join our board of trustees. Help guide the organisation with transparency and rigour.

---

**Cubo de Histórias (Story Cube)**  
*Connection that transforms — a bridge of love between parents and children*  
Aligned with the UN Convention on the Rights of the Child · Article 9  
UK not-for-profit in formation  
Made with care for families everywhere

---

This is your UK-ready document. If you would like me to now draft the short cover email to Darren Bradley that references his specific background and invites a conversation, just say the word and I’ll write it in the same tone.  
