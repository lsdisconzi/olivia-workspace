---

## Cubo de Histórias (Story Cube)

### Wizja i Mapa Drogowa Wpływu – Dokument Polski v3.1 · 2026 · Polski

*„Twoje życie powinno być poświęcone sprawie, nie rzeczom."* Ten duch napędza Story Cube — inicjatywę, która nie szuka zwrotu finansowego, ale przywrócenia podstawowego prawa: więzi między dzieckiem a rodzicem, który je kocha, nawet gdy żyją osobno.

---

### 1\. Dlaczego To Istnieje

Gdy dziecko jest odseparowane od jednego z rodziców — z powodu odległości, rozstania lub celowego utrudniania kontaktu — traci coś niezastąpionego: codzienny głos osoby, która je kocha.

Story Cube nie jest produktem, który generuje dobro społeczne jako efekt uboczny. To misja społeczna, która wykorzystuje technologię jako narzędzie. Jego naturalną formą instytucjonalną jest więc organizacja non-profit — gdzie cel rządzi strukturą, a nie odwrotnie.

Niniejszy dokument określa wizję i drogę do przekształcenia Story Cube w ruch interesu publicznego: skalowalne, oparte na dowodach narzędzie, które chroni prawo dziecka do życia rodzinnego, wspiera system wymiaru sprawiedliwości rodzinnej i pomaga służbom publicznym interweniować wcześnie. Wszystko oparte na **Artykule 9 Konwencji ONZ o prawach dziecka**, który gwarantuje prawo dziecka do utrzymywania regularnego kontaktu z obojgiem rodziców, chyba że jest to sprzeczne z jego dobrem.

---

### 2\. Historia za Kostką

Od dystansu jednego rodzica do prawa każdego dziecka do bycia wysłuchanym

Story Cube narodził się z przeżytego doświadczenia: rodzic, któremu uniemożliwiono rozmowę z dzieckiem przez prawie miesiąc. Połączenia przekierowywane, wiadomości bez odpowiedzi. Drobne codzienne chwile — co dzisiaj widziałeś? podobało ci się? co narysowałeś? — znikały w ciszy.

Potem nastąpiło bolesne uświadomienie: problemem nie jest brakująca aplikacja czy wolny telefon. Problemem jest to, że kontakt dziecka z jednym z rodziców jest często traktowany jako przywilej nadawany przez drugiego rodzica, podczas gdy w rzeczywistości jest to prawo należące do samego dziecka.

*„Dzieci potrzebują głosu. Mają prawa. Komunikacja z rodzicem, który nie jest głównym opiekunem, powinna być wyborem dziecka — a nie czymś filtrowanym przez pośrednika."*

Kostka przekształca tę ideę w fizyczny przedmiot: pięknie wykonane drewniane pudełko z ekranem, mikrofonem, głośnikiem i wbudowaną łącznością LTE w jednej jednostce. Mieszka w pokoju dziecka. Nie może być zablokowana, przekierowana ani wykorzystana do innych celów. Przenosi tylko głos i historie rodzica, który kocha dziecko — i nic więcej z internetu.

|  |  |
| :---- | :---- |
| **To nie jest aplikacja** | Dedykowane urządzenie. Nie można go odinstalować, przejąć przez TikToka ani użyć do niczego innego. |
| **Nieblokowalne** | Wbudowane LTE gwarantuje, że żaden pośrednik nie może przerwać połączenia. |
| **Prowadzone przez dziecko** | Jeden przycisk do słuchania, jeden do nagrywania. Bez potrzeby zgody osoby dorosłej w pokoju. |
| **Przyjazne i bezpieczne** | Drewniany towarzysz przy łóżku — nie kolejny ekran rywalizujący o uwagę. |

---

### 3\. Problem

Rozpad rodziny, utrudnianie kontaktu i krzywda wyrządzana dzieciom

W Polsce żyje około **6,7 miliona dzieci w wieku 0–17 lat**, co stanowi około **17,6%** populacji. Dostępne dane statystyczne ukazują powagę sytuacji:

- **Rozwody:** W 2024 roku w Polsce orzeczono **64 935 rozwodów** (spadek o 0,8% w porównaniu z 2023 rokiem). W 2024 roku sędziowie orzekli rozwód w **65 221** sprawach (w 2023 roku – 65 302). Liczba orzeczonych rozwodów w przeliczeniu na 10 000 ludności wyniosła **17,3** (w 2023 roku – 17,3).  
- **Dzieci w rozwodach:** Rozwód dotknął **63 995 małoletnich dzieci**, z czego:  
  - 12 381 (19,4%) – dzieci w wieku 0–6 lat  
  - 19 806 (30,9%) – dzieci w wieku 7–13 lat  
  - 31 808 (49,7%) – dzieci w wieku 14–17 lat  
- **Pieczę nad dziećmi:** W sprawach o rozwód sądy orzekły o:  
  - **55,9%** – piecza naprzemienna (wspólna)  
  - **35,2%** – piecza wyłączna matki  
  - **0,5%** – piecza wyłączna ojca  
  - W **8,4%** spraw nie orzeczono o pieczy nad dziećmi  
- **Przeciążenie systemu:** Sądy rodzinne i ośrodki pomocy społecznej borykają się z dużą liczbą spraw. W 2023 roku wpłynęło około **32 600 nowych spraw** o rozwód, a liczba spraw o kontakty z dzieckiem pozostaje wysoka.  
- **System ochrony:** **Sądy rodzinne** (wydziały rodzinne i nieletnich sądów rejonowych) oraz **ośrodki pomocy społecznej** i **asystenci rodziny** są kluczowymi instytucjami zapewniającymi ochronę praw dzieci. **Ustawa z dnia 9 czerwca 2022 r. o wspieraniu i resocjalizacji nieletnich** oraz **Ustawa z dnia 26 października 1982 r. o postępowaniu w sprawach nieletnich** określają ramy ochrony dzieci i młodzieży.

**Gdzie zawodzą obecne narzędzia**

- **Telefony i aplikacje są kontrolowalne.** Rodzic, z którym dziecko mieszka, może usunąć, ograniczyć lub monitorować komunikację. Głos drugiego rodzica nigdy nie dociera do dziecka.  
- **Zwykłe ekrany są toksyczne dla małych dzieci.** Treści napędzane algorytmami i reklamami są zaprojektowane tak, aby przyciągać uwagę, a nie wzmacniać więzi.  
- **Dzieci nie mają bezpośredniego głosu.** Są zależne od cudzego urządzenia, cudzego harmonogramu i często mówią pod obserwacją.  
- **Rodzice nierezydenci nie mają dostępnego wsparcia.** System wymiaru sprawiedliwości rodzinnej jest kosztowny i trudny do samodzielnego prowadzenia bez pomocy prawnej.

Poza indywidualnymi rodzinami istnieje strukturalna luka w systemie państwowym: nie ma powszechnie dostępnego, skalowalnego narzędzia, które pomagałoby egzekwować prawo dziecka do życia rodzinnego. Story Cube został zaprojektowany, aby wypełnić tę lukę — nie jako działalność charytatywna, ale jako skuteczny instrument ochrony publicznej i wczesnej interwencji.

---

### 4\. Rozwiązanie: Story Cube

Drewniana kostka. Wbudowany ekran, mikrofon i głośnik. Jeden cel.

Kostka jest celowo radykalna w swojej prostocie. To jedno, samodzielne urządzenie. Robi tylko to, co musi, i robi to z ciepłem i troską.

| Funkcja | Opis |
| :---- | :---- |
| **Nagrywaj** | Czerwony przycisk. Dziecko mówi, drugi rodzic odbiera. |
| **Słuchaj** | Zielony przycisk. Głos osoby, która je kocha, natychmiast. |
| **Udostępnij na TV** | Zastąpienie pasywnych bajek historiami, które rodzina stworzyła razem. |
| **Podwójna chmura** | Wbudowane LTE oznacza, że połączenie nie może zostać przerwane. Oboje rodzice zawsze mają bezpieczny dostęp. |
| **Materiał** | Wykonane z drewna z certyfikatem FSC. Możliwe do dostosowania motywy — kosmos, zwierzęta, bajki. |
| **Platforma dla rodziców** | Aplikacja internetowa do przesyłania ilustracji, wyboru motywów i dostępu do zestawu narzędzi nawigacji prawnej. |

**Gdzie jesteśmy dzisiaj:** Funkcjonalne cyfrowe MVP działa już w każdej przeglądarce — z silnikami opowieści 2D i 3D, poleceniami głosowymi i śledzeniem ciała — umożliwiając pierwszym rodzinom natychmiastowe przetestowanie doświadczenia na tablecie lub telefonie. To jest zalążek fizycznej Kostki, która jest obecnie w fazie rozwoju i przyniesie wszystkie te możliwości do jednego, autonomicznego drewnianego urządzenia.

**Czym nie jest:** To nie tablet. To nie aplikacja telefoniczna. To nie ekran YouTube. To nie jest nic, co mogłoby zostać przekierowane, zablokowane lub wypełnione treściami, których rodzice nie wybrali. Dyscyplina Kostki jest jej największą siłą.

---

### 5\. Kto Zyskuje

Dzieci, rodzice, system wymiaru sprawiedliwości rodzinnej, służby porządkowe, gminy i całe społeczeństwo

**Dla dziecka**

- **Bezpieczeństwo emocjonalne:** Codzienne słyszenie głosu nieobecnego rodzica pomaga utrzymać bezpieczną więź i chroni zdrowie psychiczne.  
- **Zdrowy czas przed ekranem:** Żadnych algorytmów, żadnych reklam, żadnych szkodliwych treści — tylko historie, które wybiera rodzina.  
- **Własny głos:** Dziecko może kontaktować się, kiedy chce. Nie wtedy, gdy mu pozwolono. Nie pod obserwacją.  
- **Rytuał przed snem:** Historia nagrana przez drugiego rodzica zastępuje lęk przed separacją pocieszeniem.

**Dla rodzica nierezydenta**

- **Nieblokowalna obecność:** LTE gwarantuje, że każda wiadomość dotrze do dziecka. Żadna aplikacja do usunięcia.  
- **Wsparcie w nawigacji prawnej:** Bezpieczny portal internetowy z przewodnikami w języku polskim, szablonami oświadczeń i archiwum dowodów — pomagający uczestnikom postępowania poruszać się w systemie sądowym. Uzupełnia, ale nie zastępuje niezależnego poradnictwa prawnego.  
- **Udokumentowany zapis:** Każda interakcja jest opatrzona znacznikiem czasu, co stanowi obiektywny dowód ciągłej opieki rodzicielskiej w postępowaniach sądowych.  
- **Kreatywne rodzicielstwo:** Przesyłanie rysunków, tworzenie animowanych historii, personalizacja Kostki dla dziecka.

**Dla sądów rodzinnych i kuratorów sądowych**

- **Weryfikowalny kanał komunikacji:** Kostka może być zarządzona przez sąd jako sposób ułatwienia kontaktu — obiektywny, audytowalny kanał wolny od zakłóceń.  
- **Zapis zaangażowania rodzicielskiego:** Rejestry z datami i godzinami zastępują sprzeczne narracje danymi. Sędziowie i kuratorzy widzą dokładnie, jak często rodzic się łączył i co udostępniał.  
- **Zmniejszenie liczby sporów:** Gdy kontakt jest obiektywnie rejestrowany, spory o utrudnianie kontaktu i niewywiązywanie się z obowiązków maleją, uwalniając czas sądowy i zmniejszając wrogość.

**Dla policji i gmin**

- **Wczesna interwencja w konfliktach rodzinnych:** Kostka może być wdrożona jako część strategii zapobiegawczej, zmniejszając liczbę powtarzających się wezwań i zgłoszeń do ośrodków pomocy społecznej.  
- **Dowody w postępowaniach ochronnych i karnych:** W przypadkach, gdy jeden rodzic używa dziecka do kontrolowania drugiego, niezmienny zapis z Kostki może służyć jako dowód — i może być skonfigurowany tak, aby umożliwiać tylko bezpieczny, monitorowany kontakt w przypadkach ryzyka.  
- **Oszczędność kosztów:** Każda rodzina wsparta na tym wczesnym etapie zapobiega eskalacji do opieki instytucjonalnej, postępowań opiekuńczych lub karnych — oszczędzając tysiące złotych na przypadek i zapobiegając szkodom międzypokoleniowym.

**Dla uniwersytetów i ośrodków badawczych** Kostka funkcjonuje również jako infrastruktura badawcza do badania wpływu utrudniania kontaktu na rozwój dziecka. Poprzez partnerstwa z polskimi uniwersytetami (np. Uniwersytet Warszawski, Uniwersytet Jagielloński, Uniwersytet im. Adama Mickiewicza, SWPS) może generować dane podłużne na temat dobrostanu emocjonalnego, przyswajania języka i więzi — przekształcając przeżyte doświadczenie w opublikowane dowody, które kształtują polityki publiczne.

**Dla społeczeństwa** Zerwanie więzi rodzinnych tworzy koszty międzypokoleniowe: wyższy wskaźnik problemów psychicznych, niepowodzeń szkolnych, uzależnień i przestępczości nieletnich. Każda rodzina, która pozostaje połączona, jest wzmocnioną komórką społeczną. Story Cube działa w punkcie zapobiegania — zapewniając, że miłosna więź przetrwa separację, zmniejszając cierpienie dzieci i zapobiegając pogłębianiu się szkody. Społeczny zwrot z tej inwestycji mierzy się nie w kwartałach, ale w pokoleniach.

---

### 6\. Droga Instytucjonalna

Struktura non-profit w służbie misji

Story Cube zostanie ustanowiony jako **organizacja non-profit** (fundacja lub stowarzyszenie) zgodnie z polskim prawem. Wszystkie uzyskane środki — z dotacji, umów lub darowizn — są w całości reinwestowane w misję: produkcję większej liczby Kostek, ulepszanie platformy, finansowanie niezależnych badań i ekspansję na nowe obszary.

Zarządzanie będzie sprawowane przez **zarząd** z doświadczeniem w ochronie dzieci, prawie rodzinnym, etyce cyfrowej i świadczeniu usług publicznych. Organizacja może w odpowiednim czasie ubiegać się o **status organizacji pożytku publicznego (OPP)** , co najlepiej umożliwi partnerstwo z sektorem publicznym, w tym możliwość zawierania **umów partnerskich** z organami władzy publicznej.

Story Cube nie należy do akcjonariuszy. Należy do sprawy.

---

### 7\. Ekosystem Wsparcia

Źródła finansowania w Polsce, partnerstwa i trójfazowa strategia

Jako narzędzie non-profit zaprojektowane dla sektora publicznego, Story Cube może korzystać z różnorodnej kombinacji źródeł:

**A. Krajowe programy dotacyjne**

| Źródło | Opis |
| :---- | :---- |
| **Program „Rodzina" – Ministerstwo Rodziny, Pracy i Polityki Społecznej (MRPiPS)** | Najbardziej bezpośrednio powiązany program dotacyjny dla misji Story Cube. Wspiera projekty z zakresu wspierania rodziny i systemu pieczy zastępczej. W 2026 roku budżet na wspieranie rodziny wynosi **około 1,5 mld zł**. Obejmuje:   – wsparcie asystentów rodziny,   – ośrodki wsparcia rodziny,   – rodzinną pieczę zastępczą,   – instytucjonalną pieczę zastępczą,   – pomoc na usamodzielnienie. |
| **Program „Sprawiedliwość" – Ministerstwo Sprawiedliwości** | Wsparcie dla innowacji w wymiarze sprawiedliwości. W 2026 roku budżet na program wynosi **około 17,9 mln zł**. |
| **Programy Funduszy Europejskich – Fundusz Europejski na Rzecz Rozwoju Społecznego (FERS)** | Polski program operacyjny realizujący Europejski Fundusz Społeczny+ (EFS+) na lata 2021–2027. Budżet FERS wynosi **ponad 5,2 mld zł**. |
| **Rządowy Program „Maluch+"** | Program wsparcia instytucji opieki nad dziećmi w wieku do lat 3\. W 2026 roku budżet wynosi **około 800 mln zł**. Wspiera tworzenie nowych miejsc opieki oraz modernizację i doposażenie istniejących żłobków, klubów dziecięcych i dziennych opiekunów. |

**B. Fundusze Unii Europejskiej**

| Źródło | Opis |
| :---- | :---- |
| **Fundusz Europejski na Rzecz Rozwoju Społecznego (FERS)** | Realizuje Europejski Fundusz Społeczny+ (EFS+) w Polsce. Obszary wsparcia obejmują zatrudnienie, edukację, włączenie społeczne i opiekę zdrowotną. |
| **Program „Prawo i Sprawiedliwość" – Fundusz na rzecz Wymiaru Sprawiedliwości 2026–2027** | Wyodrębniony w ramach FERS priorytet: *Praworządność i wymiar sprawiedliwości*. Budżet wynosi **ponad 220 mln zł**. |
| **Fundusz na rzecz Sprawiedliwej Transformacji (FST)** | Wspiera regiony przechodzące transformację przemysłową, z naciskiem na pomoc społeczną i dzieci. Budżet FST na Śląsku wynosi **prawie 3 mld zł**. |
| **Program Interreg Polska-Słowacja 2021-2027** | Możliwości współpracy transgranicznej w obszarze ochrony dzieci i rodzin. |

**C. Fundacje i organizacje filantropijne**

| Źródło | Opis |
| :---- | :---- |
| **Fundacja Dajemy Dzieciom Siłę (FDDS)** | Największa polska organizacja pozarządowa działająca na rzecz ochrony dzieci przed krzywdzeniem. Prowadzi kampanie społeczne, interweniuje w sprawach krzywdzonych dzieci. Potencjalny partner strategiczny. |
| **Fundacja Świętego Mikołaja** | Działa na rzecz dzieci w trudnej sytuacji życiowej, w tym dzieci w rodzinach zastępczych i domach dziecka. Realizuje programy pomocowe i edukacyjne. |
| **Fundacja Szczęśliwe Dzieciństwo** | Wspiera dzieci i rodziny w kryzysie. Może być potencjalnym partnerem. |
| **Fundacja Orange** | Realizuje programy edukacyjne i cyfrowe dla dzieci i młodzieży. |
| **Fundacja PZU** | Wspiera projekty społeczne, w tym dotyczące zdrowia psychicznego dzieci. |

**D. Środki samorządowe**

| Źródło | Opis |
| :---- | :---- |
| **Program „Za życiem"** | Rządowy program wsparcia rodzin z dziećmi. |
| **Fundusze wojewódzkie** | Środki z budżetów województw na wspieranie rodziny i ochronę dzieci. |
| **Środki gminne** | Budżety gmin na wspieranie rodziny, w tym asystentów rodziny, świetlice środowiskowe, pomoc społeczną. |
| **Program „Kronika"** | Program wsparcia pieczy zastępczej na poziomie powiatowym. |
| **Fundusz „Polityka Rodzinna"** | Obsługa finansowa świadczeń rodzinnych (500+, Dobry Start, Rodzinny Kapitał Opiekuńczy itp.). |

**E. Inne źródła i potencjalni partnerzy**

| Typ instytucji | Konkretny podmiot |
| :---- | :---- |
| **Ministerstwo Rodziny, Pracy i Polityki Społecznej** | MRPiPS |
| **Ministerstwo Sprawiedliwości** | Departament postępowań cywilnych / Sądy rodzinne |
| **Rzecznik Praw Dziecka** | Biuro Rzecznika Praw Dziecka |
| **Sądy rodzinne** | Wydziały rodzinne i nieletnich sądów rejonowych |
| **Kuratorzy sądowi** | Zawodowi i społeczni kuratorzy sądowi |
| **Ośrodki pomocy społecznej** | Miejskie i gminne ośrodki pomocy społecznej |
| **Organizacje pozarządowe** | Fundacje i stowarzyszenia działające na rzecz rodziny |
| **Uniwersytety** | UW, UJ, UAM, SWPS, Uniwersytet Śląski |

**F. Strategia trójfazowa**

| Faza | Okres | Główne działania | Kamienie milowe |
| :---- | :---- | :---- | :---- |
| **Ziarno** | 0–12 miesięcy | Dotacje fundacyjne, pilotaż z jedną gminą i jednym sądem rodzinnym, partnerstwo akademickie. Pierwsze fizyczne prototypy. | Podmiot prawny zarejestrowany. Funkcjonalny prototyp. 3 partnerstwa strategiczne. |
| **Zrównoważenie** | 12–36 miesięcy | Bezpośrednie zamówienia od gmin. Przyjęcie przez system pomocy społecznej. Opublikowana baza dowodowa. Ekspansja do wielu województw. | 150 rodzin wspartych. Niezależna ocena. 2 artykuły akademickie. |
| **Skala** | 36+ miesięcy | Wdrożenie ogólnopolskie ze współfinansowaniem rządowym. Integracja z orzeczeniami sądowymi. Pilotaże międzynarodowe. | 10 000+ Kostek. 5 okręgów sądowych korzysta z danych Kostki. Uznanie jako infrastruktury publicznej. |

---

### 8\. Zgodność z Polskim Prawem i Ramami Ochronnymi

Story Cube jest zaprojektowany tak, aby znajdować się na przecięciu polskiej architektury prawnej i ochrony dzieci:

- **Konstytucja Rzeczypospolitej Polskiej, Art. 18 i 71:** Ochrona rodziny jako podstawowej komórki społecznej oraz ochrona macierzyństwa, rodzicielstwa i rodziny.  
- **Konwencja ONZ o prawach dziecka:** Polska ratyfikowała Konwencję w 1991 roku. Art. 9 gwarantuje prawo dziecka do utrzymywania osobistych relacji i bezpośredniego kontaktu z obojgiem rodziców, chyba że jest to sprzeczne z jego dobrem.  
- **Ustawa z dnia 25 lutego 1964 r. – Kodeks rodzinny i opiekuńczy:** Reguluje władzę rodzicielską, kontakty z dzieckiem, obowiązek alimentacyjny oraz pieczę nad dzieckiem.  
- **Ustawa z dnia 9 czerwca 2022 r. o wspieraniu i resocjalizacji nieletnich:** Określa środki wychowawcze, resocjalizacyjne i terapeutyczne wobec nieletnich.  
- **Ustawa z dnia 26 października 1982 r. o postępowaniu w sprawach nieletnich:** Określa postępowanie wobec nieletnich.  
- **Ustawa z dnia 29 lipca 2005 r. o przeciwdziałaniu przemocy w rodzinie:** Określa działania na rzecz przeciwdziałania przemocy w rodzinie. Obejmuje procedurę "Niebieskiej Karty".  
- **Ustawa z dnia 13 maja 2016 r. o przeciwdziałaniu zagrożeniom przestępczością na tle seksualnym:** Reguluje Rejestr Sprawców Przestępstw na Tle Seksualnym i zasady bezpiecznego kontaktu z dziećmi.  
- **Ustawa z dnia 9 czerwca 2022 r. o wspieraniu rodziny i systemie pieczy zastępczej:** Określa system wsparcia rodziny i pieczy zastępczej.  
- **Program "Rodzina" (MRPiPS):** Program polityki prorodzinnej obejmujący świadczenia rodzinne i wsparcie dla rodzin.  
- **Program "Sprawiedliwość" (Ministerstwo Sprawiedliwości):** Program wsparcia modernizacji wymiaru sprawiedliwości.

---

### 9\. Pięcioletnia Mapa Drogowa – Polska

| Faza | Okres | Główne działania | Kamienie milowe |
| :---- | :---- | :---- | :---- |
| **1\. Podstawa** | 0–12 miesięcy | Założenie podmiotu non-profit w Polsce. Ukończenie pierwszego fizycznego prototypu Kostki. Zabezpieczenie początkowego finansowania. Sformalizowanie partnerstwa badawczego z polskim uniwersytetem. | Podmiot prawny zarejestrowany. Funkcjonalny prototyp. 3 partnerstwa strategiczne. |
| **2\. Pilotaż** | 12–24 miesięcy | Wdrożenie 100–150 Kostek w 2–3 gminach, integracja z ośrodkami pomocy społecznej i sądami rodzinnymi. Zbieranie danych ochronnych i dotyczących dobrostanu. Pierwsza ocena opublikowana. | 150 rodzin wspartych. Pierwszy niezależny raport ewaluacyjny. |
| **3\. Dowody** | 24–36 miesięcy | Recenzowana publikacja wyników. Przyjęcie przez co najmniej jedno województwo. Ekspansja do 10 gmin. | 2 artykuły akademickie. Umowa z co najmniej jedną gminą/województwem. |
| **4\. Skalowanie** | 36–48 miesięcy | 50+ gmin. Formalne wykorzystanie w orzeczeniach sądowych. Zespół 25+ osób. | 10 000 Kostek wdrożonych. 5 okręgów sądowych korzysta z danych Kostki. |
| **5\. Infrastruktura publiczna** | 48–60 miesięcy | Kostka uznana za część krajowej infrastruktury wymiaru sprawiedliwości rodzinnej i wczesnego wsparcia. Współfinansowana przez rząd (MRPiPS). Pilotaże międzynarodowe. | 50 000+ Kostek. Wydane zalecenia polityczne. Międzynarodowe uznanie. |

---

### 10\. Dołącz do Tego Ruchu

Zamawiaj, badaj, wspieraj, twórz, zarządzaj

*„Każde dziecko zasługuje na to, by słyszeć głos kogoś, kto je kocha. Każdy rodzic zasługuje na to, by dotrzeć do swojego dziecka. Story Cube to umożliwia — z prostotą, bezpieczeństwem i ciepłem."*

Budujemy więcej niż urządzenie. Budujemy ruch na rzecz praw dzieci, oparty na dowodach i zaprojektowany dla sektora publicznego.

Niezależnie od tego, czy jesteś **wójtem/burmistrzem**, **pracownikiem ośrodka pomocy społecznej**, **sędzią rodzinnym**, **kuratorem sądowym**, **naukowcem akademickim**, **prawnikiem specjalizującym się w prawie rodzinnym** czy **rodzicem**, który zna tę walkę z pierwszej ręki — jest w tej pracy miejsce dla Ciebie.

- **Zamawiać:** Gminy, ośrodki pomocy społecznej i sądy rodzinne: przetestujcie Kostkę na swoim terenie jako część swojej strategii wczesnego wsparcia lub ochrony publicznej.  
- **Badać:** Uniwersytety: nawiązujcie partnerstwa w celu oceny wpływu na dobrostan dzieci, więź i rozwój językowy.  
- **Wspierać:** Prawnicy rodzinni, kuratorzy i sędziowie: pomóżcie ukształtować Kostkę jako uznane narzędzie kontaktu i dowodu.  
- **Tworzyć:** Ilustratorzy, narratorzy i animatorzy: wnieście wkład do otwartej biblioteki motywów i historii.  
- **Zarządzać:** Dołącz do naszego zarządu. Pomóż prowadzić organizację z przejrzystością i rygorem.

---

## Cubo de Histórias (Story Cube)

### Połączenie, które przemienia — most miłości między rodzicami a dziećmi

**Zgodne z Konwencją ONZ o prawach dziecka · Artykuł 9** **Polska organizacja non-profit w fazie tworzenia** **Stworzone z troską dla rodzin na całym świecie**  
