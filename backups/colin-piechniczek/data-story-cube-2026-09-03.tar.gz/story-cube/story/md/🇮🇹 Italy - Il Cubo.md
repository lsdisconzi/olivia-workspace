---

# Cubo de Histórias (Story Cube)

**Visione e Roadmap di Impatto – Italia** *Documento v3.1 · 2026 · Italiano (versione inglese disponibile)*

*"La tua vita dovrebbe essere applicata a una causa, non alle cose."* È questo spirito che guida lo Story Cube — un'iniziativa che non cerca un ritorno finanziario, ma il ripristino di un diritto fondamentale: il legame tra un bambino e il genitore che lo ama, anche quando vivono separati.

---

## 1\. Perché Questo Esiste

Quando un bambino viene tenuto lontano da un genitore — per distanza, separazione o ostruzione deliberata — perde qualcosa di insostituibile: il suono quotidiano della persona che lo ama.

Lo Story Cube non è un prodotto che genera beneficio sociale come effetto collaterale. È una missione sociale che utilizza la tecnologia come strumento. La sua forma istituzionale naturale è quindi quella di un'**organizzazione senza scopo di lucro** — dove lo scopo governa la struttura, e non il contrario.

Questo documento definisce la visione e il percorso per trasformare lo Story Cube in un movimento di interesse pubblico: uno strumento scalabile, basato sull'evidenza, che protegge il diritto del bambino alla vita familiare, supporta il sistema di giustizia minorile e aiuta i servizi pubblici a intervenire precocemente. Tutto è ancorato all'**Articolo 9 della Convenzione delle Nazioni Unite sui Diritti dell'Infanzia**, che garantisce il diritto del bambino a mantenere un contatto regolare con entrambi i genitori, salvo che ciò sia contrario al suo superiore interesse.

---

## 2\. La Storia Dietro il Cubo

**Dalla distanza di un genitore al diritto di ogni bambino a essere ascoltato**

Lo Story Cube è nato da un'esperienza vissuta: un genitore impedito di parlare con il proprio figlio per quasi un mese. Chiamate reindirizzate, messaggi senza risposta. I piccoli momenti quotidiani — *cosa hai visto oggi? ti è piaciuto? cosa hai disegnato?* — che svaniscono nel silenzio.

Ne è seguita una dolorosa consapevolezza: il problema non è un'app mancante o un telefono lento. Il problema è che il contatto di un bambino con uno dei genitori è spesso trattato come un privilegio concesso dall'altro, quando in realtà è un diritto che appartiene al bambino stesso.

*"I bambini hanno bisogno di voce. Hanno diritti. La comunicazione con il genitore che non è il principale caregiver dovrebbe essere una scelta del bambino — non qualcosa filtrata da un intermediario."*

Il Cube trasforma questa idea in un oggetto fisico: una scatola di legno splendidamente lavorata, con schermo, microfono, altoparlante e connettività LTE integrati in un'unica unità. Vive nella cameretta del bambino. Non può essere bloccato, deviato o riutilizzato. Trasporta solo la voce e le storie del genitore che lo ama — e nient'altro da internet.

| Non è un'app | Inbloccabile | Guidato dal bambino | Accogliente e sicuro |
| :---- | :---- | :---- | :---- |
| Un dispositivo dedicato. Non può essere disinstallato, dirottato da TikTok o utilizzato per qualsiasi altra cosa. | LTE integrato garantisce che nessun intermediario possa interrompere la connessione. | Un pulsante per ascoltare, un pulsante per registrare. Nessuna autorizzazione necessaria da un adulto nella stanza. | Un compagno di legno accanto al letto — non un altro schermo che lotta per attenzione. |

---

## 3\. Il Problema

**Separazione familiare, ostruzione del contatto e il danno ai bambini**

In Italia, circa **2,8 milioni di bambini** sono coinvolti in situazioni di separazione parentale. Quasi **2 milioni di genitori** in Italia sono separati. La realtà attuale rivela un quadro preoccupante:

- **Collocamento dei figli:** Nell'**80%** dei casi, i figli vengono "collocati" (affidati fisicamente) alla madre. Attualmente: **79%** sono madri single, **21%** padri single. Entro il 2050, si prevede che i padri single aumenteranno solo al **25%**. Nonostante l'esistenza della **Legge n. 54 del 2006** (legge sull'affidamento condiviso), i tribunali collocano ancora i figli minori con la madre nel **75%** dei casi, discostandosi raramente da questo standard.  
- **Progressi sull'affidamento condiviso:** Prima del 2006: il **90%** dei casi di separazione consensuale portava ad affidamento esclusivo. Oggi: solo il **10%** è affidamento esclusivo (cioè il 90% è affidamento condiviso in termini legali, sebbene il collocamento fisico sia ancora fortemente sbilanciato verso la madre). Significativa variazione regionale: dal 70-80% a Palermo al 95% a Bologna.  
- **Autorità Garante per l'Infanzia e l'Adolescenza nota:** *"Si tratta di un provvedimento importante, ma il cambiamento culturale non è ancora completo."*  
- **Esposizione alla violenza assistita:** Migliaia di bambini in Italia sono esposti a violenza assistita, con effetti devastanti sul loro sviluppo. Il sistema giudiziario italiano fatica a proteggere coloro che più necessitano di tutela.  
- **Sovraccarico del sistema:** I tribunali per i minorenni e le sezioni famiglia dei tribunali ordinari sono spesso sovraccarichi, con procedure che si protraggono nel tempo, danneggiando i bambini.

**Dove gli strumenti attuali falliscono**

- **Telefoni e app sono controllabili.** Il genitore residente può cancellare, limitare o monitorare la comunicazione. La voce dell'altro genitore non arriva mai al bambino.  
- **Gli schermi comuni sono tossici per i bambini piccoli.** Contenuti guidati da algoritmi e pubblicità sono progettati per catturare l'attenzione, non per nutrire l'attaccamento.  
- **I bambini non hanno voce diretta.** Dipendono dal dispositivo di qualcun altro, dal programma di qualcun altro, e spesso parlano sotto osservazione.  
- **I genitori non residenti mancano di supporto accessibile.** Il sistema di giustizia familiare è costoso e difficile da navigare da soli.

Oltre alle singole famiglie, lo Stato ha una lacuna strutturale: non esiste uno strumento ampiamente disponibile e scalabile per aiutare a sostenere il diritto del bambino alla vita familiare. Lo Story Cube è progettato per colmare questa lacuna — non come beneficenza, ma come strumento efficace di protezione pubblica e intervento precoce.

---

## 4\. La Soluzione: Lo Story Cube

**Un cubo di legno. Schermo, microfono e altoparlante integrati. Un unico scopo.**

Il Cube è deliberatamente radicale nella sua semplicità. È un dispositivo unico e autonomo. Fa solo ciò che deve fare, e lo fa con calore e cura.

- **Registrare:** Un pulsante rosso. Il bambino parla, l'altro genitore riceve.  
- **Ascoltare:** Un pulsante verde. La voce della persona che lo ama, istantaneamente.  
- **Condividere in TV:** Sostituire i cartoni animati passivi con storie che la famiglia ha creato insieme.  
- **Doppia nuvola:** LTE integrato significa che la connessione non può essere interrotta. Entrambi i genitori hanno sempre accesso sicuro.  
- **Realizzato in legno certificato FSC.** Temi personalizzabili — spazio, animali, fiabe.  
- **Piattaforma per genitori:** Un'applicazione web per caricare illustrazioni, scegliere temi e accedere a un kit di strumenti di navigazione legale.

**Dove siamo oggi:** Un MVP digitale funzionante è già operativo in qualsiasi browser — con motori di storie 2D e 3D, comandi vocali e tracciamento del corpo — consentendo alle prime famiglie di testare immediatamente l'esperienza su tablet o telefono. Questo è l'embrione del Cube fisico, ora in fase di sviluppo, che porterà tutte queste capacità in un unico dispositivo autonomo in legno.

**Cosa non è:** Non è un tablet. Non è un'app per telefono. Non è uno schermo di YouTube. Non è nulla che possa essere deviato, bloccato o riempito con contenuti che i genitori non hanno scelto. La disciplina del Cube è la sua più grande forza.

---

## 5\. Chi Beneficia

**Bambini, genitori, il sistema di giustizia minorile, forze dell'ordine, comuni e la società nel suo insieme**

### Per il bambino

- **Sicurezza emotiva:** Ascoltare la voce del genitore assente ogni giorno aiuta a preservare l'attaccamento sicuro e protegge la salute mentale.  
- **Tempo di schermo sano:** Nessun algoritmo, nessun annuncio, nessun contenuto dannoso — solo le storie che la famiglia sceglie.  
- **Una voce propria:** Il bambino può contattare quando vuole. Non quando è permesso. Non sotto sorveglianza.  
- **Rituale della buonanotte:** Una storia registrata dall'altro genitore sostituisce l'ansia della separazione con il comfort.

### Per il genitore non residente

- **Presenza inbloccabile:** Il LTE garantisce che ogni messaggio arrivi al bambino. Nessuna app da eliminare.  
- **Supporto alla navigazione legale:** Un portale web sicuro con guide in italiano semplice, modelli per dichiarazioni e un archivio di prove — aiutando i litiganti a navigare nel sistema giudiziario. Complementa, ma non sostituisce, la consulenza legale indipendente.  
- **Registro documentato:** Ogni interazione è registrata con data e ora, fornendo prova oggettiva di cura parentale continua per i procedimenti giudiziari.  
- **Genitorialità creativa:** Caricare disegni, costruire storie animate, personalizzare il Cube per il bambino.

### Per il Tribunale per i Minorenni, il Giudice e la Magistratura

- **Canale di comunicazione verificabile:** Il Cube può essere ordinato dal tribunale come modalità per facilitare il contatto — un canale oggettivo, verificabile e libero da interferenze.  
- **Registro dell'impegno parentale:** Registri con data e ora sostituiscono narrazioni contraddittorie con dati. Giudici e procuratori vedono esattamente con quale frequenza un genitore si è connesso e cosa ha condiviso.  
- **Riduzione dei contenziosi:** Quando il contatto viene registrato oggettivamente, le controversie su ostruzione e inadempienza diminuiscono, liberando tempo giudiziario e riducendo l'acrimonia.

### Per le Forze dell'Ordine e i Comuni

- **Intervento precoce nei conflitti familiari:** Il Cube può essere implementato come parte di una strategia di prevenzione, riducendo le chiamate ripetute ai servizi e le segnalazioni ai servizi sociali.  
- **Prove per indagini di salvaguardia e penali:** Nei casi in cui un genitore utilizza il bambino per controllare l'altro, il registro immutabile del Cube può servire come prova di violenza psicologica — e può essere configurato per consentire solo contatti sicuri e monitorati quando esiste un rischio.  
- **Risparmio di costi:** Ogni famiglia supportata in questa fase precoce evita l'escalation verso procedimenti di protezione, allontanamento o giustizia penale — risparmiando migliaia di euro per caso e prevenendo danni intergenerazionali.

### Per università e centri di ricerca

Il Cube funziona anche come infrastruttura di ricerca sull'impatto dell'ostruzione del contatto sullo sviluppo infantile. Attraverso partnership con università italiane, può generare dati longitudinali su benessere emotivo, acquisizione del linguaggio e attaccamento — trasformando l'esperienza vissuta in evidenza pubblicata che plasma le politiche pubbliche.

### Per la società

La rottura dei legami familiari crea costi intergenerazionali: tassi più elevati di problemi di salute mentale, dispersione scolastica, consumo di sostanze e devianza giovanile. Ogni famiglia che rimane connessa è una cellula sociale rafforzata. Lo Story Cube agisce nel punto della prevenzione — garantendo che un legame d'amore sopravviva alla separazione, riducendo la sofferenza infantile e impedendo che il danno si aggravi. Il ritorno sociale di questo investimento si misura non in trimestri, ma in generazioni.

---

## 6\. Percorso Istituzionale

**Una struttura senza scopo di lucro al servizio della missione**

Lo Story Cube sarà costituito come **organizzazione senza scopo di lucro** (Ente del Terzo Settore). Tutte le risorse generate — da contributi, contratti o donazioni — sono reinvestite integralmente nella missione: produrre più Cube, migliorare la piattaforma, finanziare la ricerca indipendente ed espandersi in nuove aree.

La governance sarà esercitata da un **consiglio di amministrazione** con competenze in protezione dell'infanzia, diritto di famiglia, etica digitale ed erogazione di servizi pubblici. L'organizzazione può, a tempo debito, richiedere il riconoscimento come **ETS (Ente del Terzo Settore)** , **APS (Associazione di Promozione Sociale)** o **Impresa Sociale** (ai sensi del D.Lgs. n. 112/2017), a seconda di ciò che meglio consente la partnership con il settore pubblico.

Lo Story Cube non appartiene agli azionisti. Appartiene alla causa.

---

## 7\. Ecosistema di Supporto

**Fonti di finanziamento in Italia, partnership e una strategia in tre fasi**

Come strumento senza scopo di lucro progettato per il settore pubblico, lo Story Cube può attingere a una combinazione diversificata di risorse:

**A. Finanziamenti Pubblici Nazionali**

- **PNRR (Piano Nazionale di Ripresa e Resilienza) – Missione 5 (Inclusione e Coesione Sociale)** :  
    
  - **M5C2 \- Investimento 1.1**: **Sostegno alle capacità genitoriali e prevenzione della vulnerabilità delle famiglie e dei bambini** – finanziamento: **€84,6 milioni**.  
  - Copre: educazione familiare, sostegno reciproco tra famiglie, gruppi genitori-figli, integrazione tra scuola e servizi.  
  - Obiettivo: **spezzare il "circolo dello svantaggio sociale"** .


- **Fondo per le Politiche della Famiglia**:  
    
  - 2024: circa **€28 milioni**.  
  - 2025: **€32 milioni**.  
  - Include finanziamenti per **hub di innovazione sociale**.


- **Bando "Centri per le Famiglie – Hub di Innovazione Sociale"** :  
    
  - Oltre **€2 milioni** stanziati per rafforzare il ruolo della famiglia come motore di coesione sociale.

**B. Bandi e Fondazioni**

- **Fondazione Cariplo – Programma InnovaWelfare**:  
    
  - Prima edizione: **€1,45 milioni**.  
  - Supporta il non profit nell'innovazione tecnologica e trasformazione digitale dei servizi welfare.  
  - Aree coperte: **Parent Training**, telemedicina, invecchiamento attivo, ecc.


- **Fondo per la Repubblica Digitale**:  
    
  - Bando da **€2,6 milioni** lanciato a marzo 2025\.  
  - Contributi tra **€200.000 e €300.000**.


- **Fondazione Con il Sud** – per progetti nel Mezzogiorno.  
    
- **Fondazioni di origine bancaria** – numerose fondazioni locali.

**C. Appalti Pubblici per l'Innovazione**

- **Smarter Italy** – Programma nazionale per promuovere l'uso strategico degli appalti pubblici come leva per l'innovazione:  
    
  - Obiettivi: rispondere ai bisogni delle comunità locali e trasformare città e territori in **laboratori sperimentali**.  
  - Aperto a tutte le pubbliche amministrazioni.  
  - Basato su **open innovation** e **innovation procurement**.  
  - Promosso dal **Dipartimento per la Trasformazione Digitale** e **AgID**.


- **Piemonte Innova – Bando "Start-up Innovative"**:  
    
  - Istituisce una vetrina dedicata per start-up innovative sulla piattaforma MePA.

**D. Finanziamenti Locali e Regionali**

- **Città di Torino – Avviso Pubblico**: Sostiene progetti di innovazione circolare con impatto urbano, con **contributi a fondo perduto** fino all'80% dei costi ammissibili, massimo **€120.000**.  
- **Regione Piemonte – Voucher Vesta**: Lanciati nel 2025, sostengono le famiglie con bambini 0-6 anni.

### E. Potenziali Istituzioni Partner

| Tipo di Istituzione | Ente Specifico |
| :---- | :---- |
| Autorità Nazionale per l'Infanzia | Autorità Garante per l'Infanzia e l'Adolescenza (AGIA) |
| Dipartimento Politiche Famiglia | Dipartimento per le politiche della famiglia |
| Dipartimento Trasformazione Digitale | Dipartimento per la trasformazione digitale |
| Ministero del Lavoro | Ministero del Lavoro e delle Politiche Sociali |
| Ministero Università e Ricerca | Ministero dell'Università e della Ricerca |
| Ministero Imprese | Ministero delle Imprese e del Made in Italy |
| Servizi Sociali Locali | Servizi sociali dei comuni |
| Tribunale per i Minorenni | Tribunale per i minorenni |
| Tribunale Ordinario | Tribunale ordinario \- sezione famiglia |

### F. Strategia in tre fasi

1. **Seme (Anni 1–2):** Contributi da fondazioni, pilota iniziale con un comune e un servizio sociale, partnership accademica stabilita. Primi prototipi fisici implementati.  
2. **Sostenibilità (Anni 3–4):** Commissione diretta da comuni, adozione da parte dei servizi sociali, base di evidenze pubblicata, espansione a più regioni.  
3. **Scala (Anno 5 in poi):** Implementazione nazionale con co-finanziamento dal governo centrale, integrazione in provvedimenti giudiziari e percorsi di salvaguardia. Piloti internazionali in parallelo.

---

## 8\. Allineamento con il Quadro Legale e di Salvaguardia Italiano

Lo Story Cube è progettato per collocarsi all'intersezione dell'architettura legale e di protezione dell'infanzia italiana:

- **Codice Civile Italiano, Articolo 337-ter** (ex Articolo 155):  
    
  *"Anche in caso di separazione personale dei genitori il figlio minore ha il diritto di mantenere un rapporto equilibrato e continuativo con ciascuno di essi, di ricevere cura, educazione e istruzione da entrambi e di conservare rapporti significativi con gli ascendenti e con i parenti di ciascun ramo genitoriale."* Questo articolo sancisce il **principio di bigenitorialità** — l'affidamento condiviso è la norma, l'affidamento esclusivo è l'eccezione.  
    
- **Responsabilità Genitoriale:** La riforma introdotta dalla **Legge n. 219 del 2012** e dal **D.Lgs. n. 154 del 2013** (in vigore dal 7 febbraio 2014\) ha sostituito il concetto di "potestà genitoriale" con **"responsabilità genitoriale"** . È definita come il dovere di **mantenere, educare, istruire e assistere moralmente il figlio**, rispettandone le capacità, le inclinazioni e le aspirazioni. È esercitata da entrambi i genitori di **comune accordo**.  
    
- **Convenzione ONU sui Diritti dell'Infanzia:** L'Italia ha ratificato e reso esecutiva la Convenzione attraverso la **Legge n. 176 del 27 maggio 1991**. L'**Articolo 9** garantisce il diritto del bambino a mantenere contatti diretti con entrambi i genitori, salvo che ciò sia contrario al suo superiore interesse.  
    
- **Riforma Cartabia (2022) – D.Lgs. n. 149 del 10 ottobre 2022:** Ha introdotto un **procedimento unico** per le materie relative alle persone, ai minori e alle famiglie. Innovazioni chiave:  
    
  - Un unico quadro procedurale per separazione, divorzio, affidamento dei figli di coppie non sposate e casi di responsabilità genitoriale.  
  - Maggiore enfasi sugli **accordi parentali** formalizzati attraverso il **piano genitoriale**.  
  - In casi di violenza domestica, **sono esclusi i procedimenti di riconciliazione**.


- **Trattativa Assistita:** È stato istituito anche uno strumento flessibile e innovativo per la risoluzione delle controversie familiari.  
    
- **Sistema di Protezione e Servizi Sociali:**  
    
  - **Centri per le Famiglie:** Diffusi su tutto il territorio nazionale, offrono servizi di mediazione familiare per aiutare i genitori in separazione a continuare il loro ruolo genitoriale condiviso.  
  - **Centro di Mediazione Familiare Gea "Irene Bernardini"** (Milano) – Un servizio pubblico leader nel supportare i genitori separati.  
  - **"Spazio Neutro"** – Spazi fisici e psicologici per **supportare, mantenere o ricostruire legami genitore-figlio fragili**.


- **Piano Nazionale di Azione per l'Infanzia e l'Adolescenza (2025-2027):** Pubblicato dal Dipartimento per le Politiche della Famiglia, comprende 16 azioni in tre aree interconnesse: a) Competenze genitoriali, b) Educazione, c) Salute. Obiettivo: **rafforzare le competenze genitoriali** e **promuovere l'affidamento familiare come rete di solidarietà**.  
    
- **Autorità Garante per l'Infanzia e l'Adolescenza (AGIA):** Istituita dalla **Legge n. 112 del 12 luglio 2011**, con la missione di **promuovere e proteggere i diritti e gli interessi dei minori**, garantendo la piena attuazione della Convenzione ONU in Italia.

---

## 9\. Roadmap Quinquennale

**Dal concetto all'infrastruttura nazionale**

| Fase | Periodo | Attività Principali | Traguardi |
| :---- | :---- | :---- | :---- |
| **1\. Fondazione** | 0–12 mesi | Costituire l'ente del terzo settore. Completare il primo prototipo fisico del Cube (schermo, audio, LTE). Ottenere il finanziamento iniziale. Formalizzare la partnership di ricerca con un'università italiana. | Ente legale registrato. Prototipo funzionale pronto. 3 partnership strategiche. |
| **2\. Pilota** | 12–24 mesi | Implementare 100–150 Cube in 2–3 aree comunali, integrati con i servizi sociali e i Centri per le Famiglie. Raccogliere dati di salvaguardia e benessere. Prima valutazione pubblicata. | 150 famiglie supportate. Primo rapporto di valutazione indipendente. |
| **3\. Evidenza** | 24–36 mesi | Pubblicazione peer-reviewed dei risultati. Adozione da parte di un servizio sociale. Espansione a 10 comuni. | 2 articoli accademici. Contratto con almeno un comune/servizio sociale. |
| **4\. Scala** | 36–48 mesi | 50+ comuni. Utilizzo formale in provvedimenti giudiziari. Team di 25+ persone. | 10.000 Cube implementati. 5 distretti giudiziari che utilizzano i dati del Cube. |
| **5\. Infrastruttura Pubblica** | 48–60 mesi | Cube riconosciuto come parte dell'infrastruttura nazionale di giustizia minorile e sostegno precoce. Co-finanziato dal governo centrale. Piloti internazionali. | 50.000+ Cube. Orientamento politico emesso. Riconoscimento internazionale. |

---

## 10\. Unisciti a Questo Movimento

**Comissiona, ricerca, sostieni, crea, governa**

*"Ogni bambino merita di ascoltare la voce di qualcuno che lo ama.* *Ogni genitore merita di raggiungere il proprio figlio.* *Lo Story Cube rende tutto questo possibile — con semplicità, sicurezza e calore."*

Stiamo costruendo più di un dispositivo. Stiamo costruendo un movimento per i diritti dell'infanzia, basato sull'evidenza e progettato per il settore pubblico.

Che tu sia un sindaco, un membro dei servizi sociali, un giudice del tribunale per i minorenni, un ricercatore accademico, un servizio di supporto alle vittime di violenza domestica, o un genitore che conosce questa lotta in prima persona — **c'è un posto per te in questo lavoro.**

- **Comissionare:** Comuni e servizi sociali: testate il Cube nella vostra area come parte della vostra strategia di sostegno precoce o protezione pubblica.  
- **Ricercare:** Università: stabilite partnership per valutare l'impatto sul benessere infantile, l'attaccamento e lo sviluppo del linguaggio.  
- **Sostenere:** Professionisti del diritto di famiglia e magistratura: aiutate a plasmare il Cube come strumento riconosciuto per il contatto e l'evidenza.  
- **Creare:** Illustratori, narratori e animatori: contribuite a una biblioteca aperta di temi e storie.  
- **Governare:** Unitevi al nostro consiglio di amministrazione. Aiutate a guidare l'organizzazione con trasparenza e rigore.

---

**Cubo de Histórias (Story Cube)** *Connessione che trasforma — un ponte d'amore tra genitori e figli* Allineato con la Convenzione delle Nazioni Unite sui Diritti dell'Infanzia · Articolo 9 Ente del Terzo Settore italiano in formazione Realizzato con cura per le famiglie ovunque

---

