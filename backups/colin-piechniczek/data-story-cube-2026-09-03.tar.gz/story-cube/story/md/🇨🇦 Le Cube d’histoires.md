# Story Cube / Le Cube d’histoires

**Vision and Impact Roadmap – Canada**  
*Document v3.1 · 2026 · English*  
*(Version française disponible sur demande)*

*“Your life must be applied to a cause, not to things.”*  
That spirit drives the Story Cube — an initiative that seeks no financial return, only the restoration of a fundamental right: the bond between a child and the parent who loves them, even when they live apart.

---

## 1\. Why This Exists

When a child is kept from a parent — by distance, separation, or deliberate obstruction — they lose something irreplaceable: the everyday sound of someone who loves them.

The Story Cube is not a product that generates social good as a side effect. It is a social mission that uses technology as a tool. Its natural institutional form is therefore a **non‑profit organization** — where purpose governs structure, not the other way around.

This document sets out the vision and the path to transform the Story Cube into a public‑interest movement: a scalable, evidence‑based tool that protects a child’s right to family connection, supports the justice system, and helps public services intervene early. Everything is anchored in **Article 9 of the United Nations Convention on the Rights of the Child**, which guarantees the right of the child to maintain regular contact with both parents, unless that is contrary to their best interests.

---

## 2\. The Story Behind the Cube

**From one parent’s distance to every child’s right to be heard**

The Story Cube was born from lived experience: a parent blocked from speaking with their child for nearly a month. Calls diverted, messages unanswered. The tiny everyday moments — *what did you see today? did you like it? what did you draw?* — vanishing into silence.

What followed was a painful realization: the problem is not a missing app or a slow phone. The problem is that a child’s contact with one parent is too often treated as a privilege granted by the other, when it is, in truth, a right that belongs to the child.

*“Children need a voice. They have rights. Communication with the non‑primary parent should be the child’s choice — not something filtered through a gatekeeper.”*

The Cube turns that idea into a physical object: a beautifully crafted wooden box, with a screen, microphone, speaker, and built‑in LTE connectivity — all in one unit. It lives in the child’s room. It cannot be blocked, diverted, or repurposed. It carries only the voice and stories of the parent who loves them — and nothing else from the internet.

| Not an app | Unblockable | Child-led | Welcoming and safe |
| :---- | :---- | :---- | :---- |
| A dedicated device. It cannot be uninstalled, hijacked by TikTok, or used for anything else. | Built‑in LTE guarantees no intermediary can cut the connection. | One button to listen, one button to record. No adult permission needed in the child’s home. | A wooden companion by the bedside — not another screen competing for attention. |

---

## 3\. The Problem

**Family separation, contact obstruction, and the harm to childhood**

In Canada, parental separation affects tens of thousands of children each year. While divorce rates have moderated, the number of families navigating separation remains substantial.

- **Children in separated families:** According to Statistics Canada, about **38 % of divorces involve children**, affecting approximately **20,000 children annually**. Many more children live in separated families formed outside marriage. Canada has over **1.4 million children living in low‑income households**, and separation often deepens that vulnerability.  
- **Shared parenting:** Over the last decade, shared physical custody arrangements — where the child spends at least 40 % of their time with each parent — have become more common, but they are still contested in many cases. The 2021 amendments to the federal **Divorce Act** emphasize the best interests of the child and the principle of maximum contact with both parents, while removing the language of “custody” and “access” in favour of **parenting time** and **decision‑making responsibility**. Provincial legislation largely parallels this approach.  
- **Justice system overload:** Family courts in every province and territory face chronic backlogs. Cases that drag on for years harm children by prolonging uncertainty and conflict.  
- **Child protection system:** Canada has a decentralized child welfare system, with each province and territory operating its own legislation and services (e.g., Children’s Aid Societies in Ontario, child and family services agencies elsewhere). These systems intervene when a child is in need of protection, but they lack simple, scalable tools to support safe family contact at the front end.

**Where current tools fail**

- **Phones and apps are controllable.** The resident parent can delete, restrict, or monitor communication. The other parent’s voice never reaches the child.  
- **Ordinary screens are toxic for young children.** Algorithm‑driven content and advertising are designed to capture attention, not to nurture attachment.  
- **Children lack a direct voice.** They depend on someone else’s device, someone else’s schedule, and often speak under observation.  
- **Non‑resident parents lack accessible support.** The family justice system is expensive, hard to navigate alone, and can feel adversarial.

Beyond individual families, the state has a structural gap: there is no widely available, scalable tool to help uphold a child’s right to family connection. The Story Cube is designed to fill that gap — not as charity, but as an effective instrument of public protection and early intervention.

---

## 4\. The Solution: The Story Cube

**A wooden cube. Built‑in screen, microphone, and speaker. A single purpose.**

The Cube is deliberately radical in its simplicity. It is a unique, standalone device. It does only what it needs to do, and it does so with warmth and care.

- **Record:** A red button. The child speaks, the other parent receives it.  
- **Listen:** A green button. The voice of the person who loves them, instantly.  
- **Share on TV:** Replace passive cartoons with stories the family creates together.  
- **Dual cloud:** Built‑in LTE means the connection cannot be severed. Both parents always have secure access.  
- **Made of FSC‑certified wood.** Customizable themes — space, animals, fairy tales.  
- **Parent platform:** A web app to send illustrations, choose themes, and access a legal‑navigation toolkit.

**Where we are today:** A working digital MVP already runs in any browser — with 2D and 3D story engines, voice commands, and body tracking — allowing the first families to test the experience immediately on a tablet or phone. This is the embryo of the physical Cube, now in development, which will bring all that capability into a single, autonomous wooden device.

**What it is not:** It is not a tablet. It is not a phone app. It is not a YouTube screen. It is nothing that can be diverted, blocked, or filled with content the parents did not choose. The Cube’s discipline is its greatest strength.

---

## 5\. Who Benefits

**Children, parents, the justice system, child protection services, police, provinces and territories, and society as a whole**

### For the child

- **Emotional security:** Hearing the absent parent’s voice every day helps preserve secure attachment and protect mental health.  
- **Healthy screen time:** No algorithms, no ads, no harmful content — only stories the family chooses.  
- **A voice of their own:** The child can reach out whenever they want. Not when they are allowed. Not under surveillance.  
- **Bedtime ritual:** A story recorded by the other parent replaces separation anxiety with comfort.

### For the non‑resident parent

- **Unblockable presence:** LTE guarantees every message reaches the child. No app to be deleted.  
- **Legal navigation support:** A secure web portal with guides in plain English and French, templates for affidavits and motions, and an evidence log — helping self‑represented litigants navigate provincial and federal family courts. It complements, but does not replace, independent legal advice.  
- **Documented record:** Every interaction is time‑stamped, providing objective proof of ongoing parental care for court proceedings.  
- **Creative parenting:** Send drawings, build animated stories, customize the Cube for the child.

### For the justice system (unified family courts, provincial family courts, and the Office of the Children’s Lawyer)

- **Verifiable communication channel:** The Cube can be ordered by a judge as a means of facilitating contact — an objective, auditable channel free from interference.  
- **Record of parental engagement:** Time‑stamped logs replace contradictory narratives with data. Judges and children’s lawyers see exactly how often a parent connected and what they shared.  
- **Reduction in litigation:** When contact is objectively recorded, disputes about obstruction and non‑compliance decrease, freeing court time and reducing animosity.

### For child protection agencies, police, and provincial/territorial governments

- **Early intervention in family conflict:** The Cube can be deployed as part of a prevention strategy, reducing repeat calls for service and referrals to the child welfare system.  
- **Evidence for protection and criminal investigations:** In cases where one parent uses the child to control the other, the Cube’s immutable log can serve as evidence — and it can be configured to allow only safe, monitored contact when risk exists.  
- **Cost savings:** Every family supported at this early stage avoids escalation to formal child protection proceedings, foster care placements, or criminal justice involvement — saving tens of thousands of dollars per case and preventing intergenerational harm.

### For universities and research centres

The Cube also serves as research infrastructure on the impact of contact obstruction on child development. Through partnerships with Canadian universities — including the University of Toronto, McGill University, the University of British Columbia, Université de Montréal, and others — it can generate longitudinal data on emotional well‑being, language acquisition, and attachment, turning lived experience into published evidence that shapes public policy.

### For society

The rupture of family bonds creates intergenerational costs: higher rates of mental health problems, school failure, substance use, and youth delinquency. Every family that stays connected is a strengthened social cell. The Story Cube acts at the point of prevention — ensuring that a loving bond survives separation, reducing child suffering, and stopping harm before it escalates. The social return on that investment is not measured in quarters, but in generations.

---

## 6\. Institutional Path

**A non‑profit structure in service of the mission**

The Story Cube will be established as a **federal not‑for‑profit corporation** under the *Canada Not‑for‑profit Corporations Act* (or the equivalent provincial legislation, as appropriate), and will apply for **registered charity status** with the Canada Revenue Agency. All resources generated — whether through grants, contracts, or donations — will be reinvested entirely in the mission: manufacturing more Cubes, improving the platform, funding independent research, and expanding to new areas.

Governance will be exercised by a **board of directors** with expertise in child protection, family law, digital ethics, and public service delivery. The organization may also establish an advisory council that includes youth voices, Indigenous representatives, and family‑justice practitioners.

The Story Cube belongs to no shareholders. It belongs to the cause.

---

## 7\. Support Ecosystem

**Funding sources in Canada, partnerships, and a three‑phase strategy**

As a non‑profit tool designed for the public sector, the Story Cube can draw on a diverse mix of resources:

**A. Federal and Provincial/Territorial Public Funding**

- **Department of Justice Canada – Family Justice Fund:** Supports projects that improve access to family justice and promote the best interests of children.  
- **Public Health Agency of Canada:** Programs addressing child and family well‑being, early intervention, and mental health.  
- **Provincial/territorial ministries** responsible for children and family services (e.g., Ontario Ministry of Children, Community and Social Services; British Columbia Ministry of Children and Family Development; Quebec Ministère de la Famille).  
- **Law foundations:** The Law Foundation of Ontario, the Law Foundation of British Columbia, and similar bodies in other provinces offer grants for access‑to‑justice initiatives.

**B. Foundations and Philanthropic Organizations**

- **United Way Centraide Canada:** Local and national funding for community‑based social services.  
- **The McConnell Foundation:** Supports social innovation and community resilience.  
- **The Lawson Foundation:** Focuses on healthy development of children and youth.  
- **The Counselling Foundation of Canada:** Funds projects that strengthen families and communities.  
- **Children’s Aid Foundation of Canada:** Supports initiatives that improve the lives of children and youth involved in child welfare.  
- **The Lucie and André Chagnon Foundation (Quebec):** Dedicated to the development of children and the prevention of poverty.

**C. International Cooperation**

- **UNICEF Canada:** Present in Canada, UNICEF advocates for child rights and can be a strategic partner.  
- **Multilateral agencies** with programs in child protection and family support.

**D. Public‑Private Partnerships and Philanthropic Donors**

- **Corporate social responsibility programs:** Companies may support the Cube through sponsorship or in‑kind contributions.  
- **Individual and corporate donors:** Donations to a registered charity are eligible for charitable tax receipts under the *Income Tax Act*.

**E. Potential Collaborating Institutions**

| Type of Institution | Specific Entity |
| :---- | :---- |
| Federal Government | Department of Justice Canada, Public Health Agency of Canada |
| Provincial/Territorial Governments | Ministries of Children and Family Services, Ministries of the Attorney General |
| Family Courts | Unified Family Courts (e.g., Ontario, Nova Scotia), Provincial Family Courts |
| Children’s Legal Representatives | Office of the Children’s Lawyer (Ontario), BC Representative for Children and Youth |
| Child Protection Agencies | Children’s Aid Societies (Ontario), Batshaw Youth and Family Centres (Quebec), Alberta Children’s Services |
| Police Services | RCMP, municipal and provincial police forces |
| Universities | University of Toronto, McGill, UBC, Université de Montréal, Dalhousie, Université Laval, and others |
| National Indigenous Organizations | Assembly of First Nations, Inuit Tapiriit Kanatami, Métis National Council |

### F. Three‑Phase Strategy

1. **Seed (Years 1–2):** Foundation grants, initial pilot with one province and one unified family court site, academic partnership established. First physical prototypes deployed.  
2. **Sustainability (Years 3–4):** Direct contracting with provincial governments and child welfare agencies, published evidence base, expansion to multiple provinces and territories.  
3. **Scale (Year 5 onward):** National rollout co‑funded by federal programs (e.g., Family Justice Fund), integration into court orders and child protection pathways, international pilots in parallel.

---

## 8\. Alignment with Canada’s Legal and Child‑Protection Framework

The Story Cube is designed to sit at the intersection of Canada’s legal architecture for children and families:

- **Divorce Act (R.S.C., 1985, c. 3 (2nd Supp.)), as amended in 2021:** Establishes the best interests of the child as the paramount consideration in all parenting decisions. The Act promotes the principle of **maximum contact** with both parents, consistent with the child’s best interests, and replaces “custody” and “access” with **parenting time** and **decision‑making responsibility**.  
- **Provincial/Territorial family legislation:** Each province and territory has its own statute governing parenting for unmarried parents and married parents not divorcing under the federal Act (e.g., *Children’s Law Reform Act* in Ontario, *Family Law Act* in British Columbia, *Family Property Act* in Alberta, *Civil Code of Québec*). All such laws prioritize the best interests of the child and increasingly support shared parenting.  
- **Child welfare legislation:** Provincial and territorial laws such as Ontario’s *Child, Youth and Family Services Act, 2017*, and Quebec’s *Youth Protection Act* set out the duty to protect children from harm, while respecting family connection wherever possible. The Cube aligns with the principle of the least disruptive intervention.  
- **Canadian Charter of Rights and Freedoms:** Section 7 (liberty and security of the person) and the values of family life inform the legal context in which the Cube operates.  
- **United Nations Convention on the Rights of the Child (UNCRC):** Ratified by Canada in 1991\. Article 9 guarantees the right of the child who is separated from one or both parents to maintain personal relations and direct contact with both parents on a regular basis, except if it is contrary to the child’s best interests. The Cube is a direct expression of this right.

---

## 9\. Glossary of Key Legal Terms

| English | French | Description |
| :---- | :---- | :---- |
| **Best interests of the child** | Intérêt supérieur de l’enfant | The paramount principle guiding all decisions affecting a child. |
| **Parenting time** | Temps parental | The time a child spends in the care of a parent, under the federal *Divorce Act* and some provincial laws. |
| **Decision‑making responsibility** | Responsabilité décisionnelle | The authority to make significant decisions about a child’s life (education, health, culture, etc.). |
| **Contact** | Contact | Time spent with a non‑parent, such as a grandparent, or in some provincial statutes, with a parent who does not have parenting time. |
| **Maximum contact principle** | Principe du contact maximum | The idea that a child should have as much contact with each parent as is consistent with their best interests. |
| **Child protection** | Protection de l’enfance | The system of laws and services designed to keep children safe from abuse and neglect. |
| **Children’s Aid Society (CAS)** | Société d’aide à l’enfance (SAE) | Ontario’s mandated child protection agencies; equivalent bodies exist in other provinces under different names. |
| **Unified Family Court** | Tribunal unifié de la famille | A specialized court that handles all family law matters (divorce, child protection, adoption) in a single venue; present in several provinces. |
| **Office of the Children’s Lawyer** | Bureau de l’avocat des enfants | An independent provincial office (Ontario) that provides legal representation for children in family law and child protection cases. |
| **UNCRC Article 9** | Art. 9 de la CDE | The right of the child to maintain contact with both parents unless contrary to their best interests. |

---

## 10\. Five‑Year Roadmap

**From concept to national infrastructure**

| Phase | Period | Key Activities | Milestones |
| :---- | :---- | :---- | :---- |
| **1\. Foundation** | 0–12 months | Incorporate the federal not‑for‑profit. Complete first physical Cube prototype (screen, audio, LTE). Secure seed funding. Formalize research partnership with a Canadian university. | Legal entity registered. Functional prototype ready. 3 strategic partnerships. |
| **2\. Pilot** | 12–24 months | Deploy 100–150 Cubes in 2–3 provinces/territories, integrated with child welfare agencies and family courts. Collect well‑being and protection data. First evaluation published. | 150 families supported. Independent evaluation report released. |
| **3\. Evidence** | 24–36 months | Peer‑reviewed publication of outcomes. Adoption by provincial child‑protection and family‑justice systems. Expansion to 10 sites. | 2 academic papers. Contract with at least one province/territory. |
| **4\. Scale** | 36–48 months | 50+ implementation sites. Formal use in court orders. Staff of 25+. | 10,000 Cubes deployed. 5 court sites using Cube data. |
| **5\. Public Infrastructure** | 48–60 months | Cube recognized as part of national family‑justice and early‑support infrastructure. Co‑funded by federal programs (e.g., Family Justice Fund). International pilots. | 50,000+ Cubes. Policy guidance issued by Justice Canada. International recognition. |

---

## 11\. Join This Movement

**Commission, research, advocate, create, govern**

*“Every child deserves to hear the voice of someone who loves them. Every parent deserves to reach their child. The Story Cube makes that possible — with simplicity, safety, and warmth.”*

We are building more than a device. We are building an evidence‑based, public‑sector‑ready movement for children’s rights.

Whether you are a provincial minister, a child‑welfare director, a family‑court judge, a children’s lawyer, a police officer, an academic researcher, a victim‑support service, or a parent who knows this struggle firsthand — **there is a place for you in this work.**

- **Commission:** Provincial/territorial ministries, child protection agencies, and family courts: test the Cube in your jurisdiction as part of your early‑intervention or public‑protection strategy.  
- **Research:** Universities: partner to evaluate impact on child well‑being, attachment, and language development.  
- **Advocate:** Family lawyers, judges, children’s lawyers, and legislators: help shape the Cube into a recognized tool for contact and evidence.  
- **Create:** Illustrators, narrators, and animators: contribute to an open library of themes and stories in English, French, and Indigenous languages.  
- **Govern:** Join our board of directors. Help guide the organization with transparency and rigour.

---

**Story Cube / Le Cube d’histoires**  
*Connection that transforms — a bridge of love between parents and children*  
Aligned with the United Nations Convention on the Rights of the Child · Article 9  
Canadian not‑for‑profit organization in formation  
Made with care for families everywhere  
