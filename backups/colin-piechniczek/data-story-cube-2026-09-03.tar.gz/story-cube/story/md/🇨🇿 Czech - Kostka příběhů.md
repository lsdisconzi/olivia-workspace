---

## Cubo de Histórias (Story Cube)

### Vize a Cesta k Dopadu – Český dokument v3.1 · 2026 · Česky

*„Tvůj život by měl být zasvěcen něčemu, co má smysl, ne věcem.“* Tento duch pohání Story Cube — iniciativu, která nehledá finanční návratnost, ale obnovu základního práva: pouta mezi dítětem a rodičem, který ho miluje, i když žijí odděleně.

---

### 1\. Proč Toto Existuje

Když je dítě drženo v odstupu od jednoho z rodičů — ať už kvůli vzdálenosti, rozchodu nebo úmyslnému bránění kontaktu — ztrácí něco nenahraditelného: každodenní hlas člověka, který ho miluje.

Story Cube není produkt, který vytváří společenský prospěch jako vedlejší efekt. Je to sociální poslání, které využívá technologie jako nástroj. Jeho přirozenou institucionální formou je proto nezisková organizace — kde účel řídí strukturu, a ne naopak.

Tento dokument stanovuje vizi a cestu k proměně Story Cube v hnutí veřejného zájmu: škálovatelný, na důkazech založený nástroj, který chrání právo dítěte na rodinný život, podporuje systém rodinné justice a pomáhá veřejným službám včasně zasahovat. Vše je ukotveno v Článku 9 Úmluvy OSN o právech dítěte, který zaručuje právo dítěte udržovat pravidelný kontakt s oběma rodiči, pokud to není v rozporu s jeho nejlepším zájmem.

---

### 2\. Příběh za Krychlí

Od vzdálenosti jednoho rodiče k právu každého dítěte být slyšeno

Story Cube se zrodil ze žité zkušenosti: rodič, kterému bylo znemožněno mluvit se svým dítětem téměř měsíc. Hovory přesměrovány, zprávy bez odpovědi. Drobné každodenní okamžiky — co jsi dnes viděl? líbilo se ti? co jsi nakreslil? — mizely v tichu.

Následovalo bolestivé zjištění: problémem není chybějící aplikace nebo pomalý telefon. Problémem je, že kontakt dítěte s jedním z rodičů je často považován za privilegium udělené druhým rodičem, ačkoli ve skutečnosti je to právo, které náleží samotnému dítěti.

*„Děti potřebují hlas. Mají práva. Komunikace s rodičem, který není hlavním pečovatelem, by měla být volbou dítěte — ne něčím, co je filtrováno prostředníkem.“*

Krychle přeměňuje tuto myšlenku na fyzický předmět: krásně zpracovanou dřevěnou krabičku s obrazovkou, mikrofonem, reproduktorem a vestavěným LTE připojením v jedné jednotce. Žije v dětském pokoji. Nemůže být zablokována, přesměrována ani zneužita. Přenáší pouze hlas a příběhy rodiče, který dítě miluje — a nic jiného z internetu.

|  |  |
| :---- | :---- |
| **Není to aplikace** | Vyhrazené zařízení. Nelze odinstalovat, unést TikTokem ani použít k ničemu jinému. |
| **Nezablokovatelné** | Vestavěné LTE zajišťuje, že žádný prostředník nemůže přerušit spojení. |
| **Vedeno dítětem** | Jedno tlačítko pro poslech, jedno pro nahrávání. Bez potřeby povolení dospělého v místnosti. |
| **Přívětivé a bezpečné** | Dřevěný společník u postele — ne další obrazovka soupeřící o pozornost. |

---

### 3\. Problém

Rodinné odloučení, bránění kontaktu a újma na dětech

V České republice žije přibližně 1,9 milionu dětí ve věku 0–17 let, což představuje asi 18 % populace. Přestože neexistují přesné souhrnné údaje o počtu dětí v rozvedených rodinách, dostupné statistiky ukazují závažnost situace:

- **Rozvody:** V roce 2024 bylo v České republice rozvedeno **23 180 manželství**. Z celkového počtu rozvedených manželství mělo **59,8 %** nezletilé děti (13 863 rozvodů). Celkem se rozvod dotkl **23 136 nezletilých dětí**. Nejvíce rozvodů s nezletilými dětmi bylo v manželstvích trvajících 5–9 let (4 324 rozvodů, 31,2 %).  
- **Rozvodovost:** Hrubá míra rozvodovosti v roce 2024 činila **2,2 ‰** (počet rozvodů na 1 000 obyvatel).  
- **Péče o děti:** Ve **45 %** rozvodů byla péče svěřena matce, v **54 %** případů byla péče svěřena matce s otcovským přispěním nebo jinou formou péče. Pouze v **0,9 %** případů byla péče svěřena otci. **Střídavá péče** je stále častější, ale stále představuje menšinu případů.  
- **Přetížení systému:** Soudy pro rodinné záležitosti a orgány sociálně-právní ochrany dětí (OSPOD) čelí vysoké pracovní zátěži. V roce 2023 bylo zahájeno přes 54 000 nových řízení ve věcech péče o nezletilé.  
- **Systém ochrany:** **Orgány sociálně-právní ochrany dětí (OSPOD)** jsou klíčovými institucemi zajišťujícími ochranu práv dětí. Zákon č. 359/1999 Sb., o sociálně-právní ochraně dětí, stanoví povinnosti obcí a krajů při ochraně práv dětí.

**Kde selhávají současné nástroje**

- **Mobilní telefony a aplikace jsou ovladatelné.** Rodič, u kterého dítě žije, může komunikaci smazat, omezit nebo monitorovat. Hlas druhého rodiče se k dítěti nikdy nedostane.  
- **Běžné obrazovky jsou pro malé děti toxické.** Obsah řízený algoritmy a reklama jsou navrženy tak, aby upoutaly pozornost, nikoli aby posilovaly citové vazby.  
- **Děti nemají přímý hlas.** Jsou závislé na cizím zařízení, cizím rozvrhu a často mluví pod dohledem.  
- **Nerezidentní rodiče postrádají dostupnou podporu.** Rodinná justice je drahá a obtížně se v ní orientuje bez právního zastoupení.

Kromě individuálních rodin existuje ve státním systému strukturální mezera: neexistuje široce dostupný, škálovatelný nástroj, který by pomáhal prosazovat právo dítěte na rodinný život. Story Cube je navržen tak, aby tuto mezeru vyplnil — nikoli jako charita, ale jako účinný nástroj veřejné ochrany a včasné intervence.

---

### 4\. Řešení: Story Cube

Dřevěná krychle. Integrovaná obrazovka, mikrofon a reproduktor. Jeden účel.

Krychle je záměrně radikální ve své jednoduchosti. Je to jediné samostatné zařízení. Dělá jen to, co má dělat, a dělá to s teplem a péčí.

| Funkce | Popis |
| :---- | :---- |
| **Nahrávat** | Červené tlačítko. Dítě mluví, druhý rodič přijímá. |
| **Poslouchat** | Zelené tlačítko. Hlas člověka, který ho miluje, okamžitě. |
| **Sdílet na TV** | Nahrazení pasivních pohádek příběhy, které rodina vytvořila společně. |
| **Dvojitý cloud** | Vestavěné LTE znamená, že spojení nemůže být přerušeno. Oba rodiče mají vždy bezpečný přístup. |
| **Materiál** | Vyrobeno z dřeva s certifikací FSC. Přizpůsobitelná témata — vesmír, zvířata, pohádky. |
| **Rodičovská platforma** | Webová aplikace pro nahrávání ilustrací, výběr témat a přístup k právnímu navigačnímu nástroji. |

**Kde jsme dnes:** Funkční digitální MVP již běží v jakémkoli prohlížeči — s 2D a 3D vyprávěcími engine, hlasovými příkazy a sledováním těla — což umožňuje prvním rodinám okamžitě vyzkoušet zážitek na tabletu nebo telefonu. Toto je embryo fyzické Krychle, která je nyní ve vývoji a přinese všechny tyto schopnosti do jediného autonomního dřevěného zařízení.

**Co to není:** Není to tablet. Není to telefonní aplikace. Není to obrazovka YouTube. Není to nic, co by mohlo být přesměrováno, zablokováno nebo naplněno obsahem, který si rodiče nevybrali. Disciplína Krychle je její největší silou.

---

### 5\. Kdo Má Prospěch

Děti, rodiče, systém rodinné justice, bezpečnostní složky, obce a celá společnost

**Pro dítě**

- **Emocionální bezpečí:** Každodenní slyšení hlasu nepřítomného rodiče pomáhá udržovat bezpečnou vazbu a chrání duševní zdraví.  
- **Zdravý čas u obrazovky:** Žádné algoritmy, žádné reklamy, žádný škodlivý obsah — pouze příběhy, které si rodina vybere.  
- **Vlastní hlas:** Dítě může kontaktovat rodiče, kdykoli chce. Ne tehdy, když je mu to dovoleno. Ne pod dohledem.  
- **Večerní rituál:** Příběh nahraný druhým rodičem nahrazuje úzkost z odloučení pohodlím.

**Pro nerezidentního rodiče**

- **Nezablokovatelná přítomnost:** LTE zajišťuje, že každá zpráva dorazí k dítěti. Žádná aplikace, kterou by bylo možné smazat.  
- **Právní navigační podpora:** Bezpečný webový portál s průvodci v češtině, šablonami pro vyjádření a úložištěm důkazů — pomáhá účastníkům řízení orientovat se v soudním systému. Doplňuje, ale nenahrazuje nezávislé právní poradenství.  
- **Dokumentovaný záznam:** Každá interakce je opatřena časovým razítkem, což poskytuje objektivní důkaz o trvající rodičovské péči pro soudní řízení.  
- **Kreativní rodičovství:** Nahrávání kreseb, vytváření animovaných příběhů, personalizace Krychle pro dítě.

**Pro soudy pro rodinné záležitosti a OSPOD**

- **Ověřitelný komunikační kanál:** Krychli může soud nařídit jako prostředek usnadnění kontaktu — objektivní, auditovatelný kanál bez vnějšího rušení.  
- **Záznam rodičovského zapojení:** Časově označené záznamy nahrazují protichůdné výpovědi daty. Soudci a úředníci OSPOD vidí přesně, jak často se rodič připojil a co sdílel.  
- **Snížení počtu sporů:** Když je kontakt objektivně zaznamenán, spory o bránění kontaktu a neplnění povinností klesají, čímž se uvolňuje soudní čas a snižuje se nepřátelství.

**Pro policii a obce**

- **Včasná intervence v rodinných konfliktech:** Krychli lze nasadit jako součást strategie prevence, což snižuje opakované výjezdy a oznámení k OSPOD.  
- **Důkazy pro ochranná a trestní vyšetřování:** V případech, kdy jeden rodič používá dítě k ovládání druhého, neměnný záznam z Krychle může sloužit jako důkaz — a může být nakonfigurován tak, aby umožňoval pouze bezpečný, monitorovaný kontakt v případech rizika.  
- **Úspora nákladů:** Každá rodina podpořená v této časné fázi zabrání eskalaci do statutární ochrany, ústavní péče nebo trestního řízení — šetří tisíce korun na případ a předchází mezigenerační újmě.

**Pro univerzity a výzkumná centra** Krychle funguje také jako výzkumná infrastruktura pro studium dopadu bránění kontaktu na vývoj dítěte. Prostřednictvím partnerství s českými univerzitami (např. Univerzita Karlova, Masarykova univerzita, Univerzita Palackého) může generovat longitudinální data o emocionální pohodě, osvojování jazyka a citové vazbě — přeměňuje žitou zkušenost v publikované důkazy, které formují veřejné politiky.

**Pro společnost** Přetržení rodinných vazeb vytváří mezigenerační náklady: vyšší míru duševních problémů, školní neúspěšnost, užívání návykových látek a kriminalitu mládeže. Každá rodina, která zůstane propojena, je posílenou společenskou buňkou. Story Cube působí v bodě prevence — zajišťuje, že milující pouto přežije odloučení, snižuje dětské utrpení a zabraňuje prohlubování újmy. Společenský návratnost této investice se neměří ve čtvrtletích, ale v generacích.

---

### 6\. Institucionální Cesta

Nezisková struktura ve službách poslání

Story Cube bude založen jako **nezisková organizace** (obecně prospěšná společnost nebo zapsaný ústav) podle českého práva. Všechny získané prostředky — ať už z dotací, smluv nebo darů — jsou plně reinvestovány do poslání: výroba více Krychlí, vylepšování platformy, financování nezávislého výzkumu a expanze do nových oblastí.

Řízení bude vykonáváno **správní radou** s odbornými znalostmi v oblasti ochrany dětí, rodinného práva, digitální etiky a poskytování veřejných služeb. Organizace může v průběhu času požádat o **registraci u Ministerstva spravedlnosti** nebo o **statut veřejné prospěšnosti**, což nejlépe umožní partnerství s veřejným sektorem, včetně možnosti uzavírání **spolupracujících dohod** s orgány veřejné moci.

Story Cube nepatří akcionářům. Patří věci.

---

### 7\. Ekosystém Podpory

Zdroje financování v České republice, partnerství a třífázová strategie

Jako neziskový nástroj navržený pro veřejný sektor může Story Cube čerpat z různorodé kombinace zdrojů:

**A. Státní dotační programy**

| Zdroj | Popis |
| :---- | :---- |
| **Dotační titul Rodina (MPSV)** | Nejpřímočařejší dotace pro poslání Story Cube. Podporuje preventivní a podpůrné služby pro rodiny s dětmi, posilování rodičovských kompetencí a zlepšování rodinných vztahů. V roce 2026 je vyčleněno **180 milionů Kč** na služby pro ohrožené děti a rodiny. Oblasti: I. Preventivní aktivity; II. Sociální práce s dětmi a rodinami (SPOD); III. Podpora zastřešujících organizací. |
| **Státní dotační politika vůči NNO** | V roce 2026 bylo schváleno **89 dotačních programů** pro nestátní neziskové organizace, spravovaných **16 poskytovateli** (13 ministerstev, Úřad vlády, 2 agentury), pokrývajících **22 tematických oblastí**. Story Cube lze zařadit do oblasti sociálních služeb (hlavním poskytovatelem je MPSV). |
| **Ministerstvo školství, mládeže a tělovýchovy (MŠMT)** | Dotace pro nestátní neziskové organizace pracující s dětmi a mládeží. |
| **Ministerstvo pro místní rozvoj (MMR)** | Dotační programy pro nestátní neziskové organizace. |

**B. Fondy Evropské unie**

| Zdroj | Popis |
| :---- | :---- |
| **Operační program Zaměstnanost plus (OPZ+)** | Česká implementace Evropského sociálního fondu+ (ESF+). **Výzvy pro sociální inovace č. 050, 051, 057 a 070** s uzávěrkou **30\. června 2026**. Story Cube jako kombinace technologické inovace a sociálního poslání je ideálním kandidátem. |
| **Program CERV – „Silnější kořeny“ (Stronger Roots)** | Financován z programu EU CERV (2026–2027). Poskytuje **přes 2,9 milionu €** 63 organizacím občanské společnosti a 21 sítím v ČR, SR, Maďarsku a Polsku. V ČR implementují **Nadace OSF** a **Glopolis**. Podporuje prohlubování spolupráce s veřejnými institucemi. |
| **EEA a Norské fondy – Fond pro občanskou společnost (2026–2031)** | Nový fond spuštěný v ČR s celkovou částkou **přes 500 milionů Kč (20,3 milionů €)** . Cíl: posílit občanskou společnost v oblasti demokracie, lidských práv a právního státu. Priority zahrnují lidská práva, rozvoj NNO, inkluzi Romů a prevenci genderově podmíněného násilí. První výzvy budou vyhlášeny brzy. Spravuje konsorcium **Nadace OSF** a **Výbor dobré vůle – Nadace Olgy Havlové**. |

**C. Nadace a nadační fondy**

| Zdroj | Popis |
| :---- | :---- |
| **Nadace OSF** | – **„Silnější kořeny“** – správa programu CERV.   – **Crowdfundingový matchmaking (2026):** Pokud vyberete alespoň 90 % cílové částky od dárců, OSF dorovná váš výběr až do výše **4 000 €**. Celkem 120 000 € pro ČR, SR a Maďarsko; **40 000 € vyhrazeno pro české organizace**.   – Správa **Fondu pro občanskou společnost** (EEA/Norsko). |
| **Nadace rozvoje občanské společnosti – „Pomozte dětem“** | Roční výzva 2026 podporuje **ohrožené a zranitelné děti do 18 let**. Prioritou je činnost přesahující běžné služby s přidanou hodnotou. Celkový rozpočet: **3 miliony Kč**. Jednotlivý grant: **500 000 – 650 000 Kč**. Termín: **20\. března 2026**. |
| **Nadace rodiny Kellnerových** | Jedna z největších nadací v ČR, aktivní v podpoře dětí a rodin. Partnerství s Nadací Oleny Zelenské na podporu ukrajinských dětí. Potenciální partner pro Story Cube. |
| **Nadace Komarek** | Podporuje stále více rodin prostřednictvím programu „Podpora aktivit pro děti“. |

**D. Krajské a obecní zdroje**

- **Spolufinancování z rozpočtů krajů a obcí** – Dotační titul Rodina výslovně umožňuje spolufinancování z krajských a obecních rozpočtů.  
- **Sociální služby** – Stabilní financování pro ohrožené děti a rodiny, včetně podpory inovativních metod práce.  
- **Dětské skupiny a předškolní péče** – Podpora vytváření míst pro děti do 3 let a rozšiřování kapacity dětských skupin.

**E. Mezinárodní fondy**

| Zdroj | Popis |
| :---- | :---- |
| **Mezinárodní visegrádský fond** | Financuje projekty v zemích V4 (ČR, Maďarsko, Polsko, Slovensko). Program „Bravely for Innovation“ – vzdělávání sociálních inovátorů. Story Cube může žádat o prostředky na projekty zaměřené na rodinnou podporu a inovace. |
| **Public Sector Loan Facility (PSLF)** | Dva české projekty již získaly **přes 2 miliony €** na rozvoj sociální infrastruktury v Moravskoslezském kraji. Ukazuje zájem EU o sociální infrastrukturu. |

**F. Sociální inovace a impact investice**

| Zdroj | Popis |
| :---- | :---- |
| **OPZ+ Sociální inovace** | Viz B.1 – uzávěrka 30\. června 2026\. |
| **Sociální klimatický fond** | V letech 2026–2032 může ČR získat **až 50 miliard Kč** na ochranu zranitelných domácností před dopady ETS2. I když primárně zaměřen na energetickou transformaci, uznává potřebu chránit zranitelné rodiny – Story Cube se může napojit na jeho sociální ochranné cíle. |
| **Trh impact investic** | Rozvíjející se trh v ČR zahrnuje sociální impact bonds, ESG investice, komunitní rozvojové fondy a filantropické impact fondy. |

**G. Potenciální spolupracující instituce**

| Typ instituce | Konkrétní subjekt |
| :---- | :---- |
| **Ministerstvo práce a sociálních věcí** | MPSV |
| **Orgán sociálně-právní ochrany dětí** | OSPOD (na obecních a krajských úřadech) |
| **Soudy pro rodinné záležitosti** | Krajské a okresní soudy |
| **Policie ČR** | Služba kriminální policie a vyšetřování |
| **Obce** | Obecní úřady / odbory sociálních věcí |
| **Univerzity** | Univerzita Karlova, Masarykova univerzita, Univerzita Palackého, VŠE, atd. |

**H. Třífázová strategie**

| Fáze | Období | Hlavní aktivity | Milníky |
| :---- | :---- | :---- | :---- |
| **Semínko** | 0–12 měsíců | Nadace OSF, nadační granty. Pilotní projekt s jednou obcí a OSPOD. Akademické partnerství. První fyzické prototypy. | Právní subjekt zaregistrován. Funkční prototyp. 3 strategická partnerství. |
| **Udržitelnost** | 12–36 měsíců | Přímé zadávání obcemi. Přijetí OSPOD. Publikovaná důkazní základna. Expanze do více krajů. | 150 rodin podpořeno. Nezávislé hodnocení. 2 akademické články. |
| **Škála** | 36+ měsíců | Celostátní implementace se spolufinancováním vlády. Integrace do soudních rozhodnutí. Mezinárodní piloty. | 10 000+ Krychlí. 5 soudních okresů. Uznání jako veřejné infrastruktury. |

---

### 8\. Soulad s Českým Právním a Ochranným Rámcem

Story Cube je navržen tak, aby se nacházel na průsečíku české právní a dětské ochranné architektury:

- **Úmluva OSN o právech dítěte:** ČR ratifikovala Úmluvu v roce 1991\. Článek 9 zaručuje právo dítěte udržovat osobní vztahy a přímý kontakt s oběma rodiči, pokud to není v rozporu s jeho nejlepším zájmem.  
- **Zákon č. 89/2012 Sb., Občanský zákoník:** Upravuje **rodičovskou odpovědnost** (dříve „rodičovská zodpovědnost“) – souhrn práv a povinností rodičů k dětem. § 851 odst. 2 stanoví, že při rozhodování o úpravě poměrů dítěte se přihlíží zejména k potřebě zajištění **stability výchovného prostředí**. § 857 stanoví právo dítěte **stýkat se s oběma rodiči**. Soud může v zájmu dítěte omezit nebo zakázat styk s rodičem, vyžaduje-li to jeho blaho.  
- **Zákon č. 292/2013 Sb., o zvláštních řízeních soudních:** Upravuje řízení ve věcech péče o nezletilé. Soud rozhoduje o **úpravě poměrů nezletilého dítěte** pro dobu po rozvodu, o **svěření do péče**, o **styku** a o výživném.  
- **Zákon č. 359/1999 Sb., o sociálně-právní ochraně dětí:** Hlavní zákon na ochranu dětí v ČR. Stanoví povinnosti obcí a krajů při ochraně práv dětí. Orgány sociálně-právní ochrany dětí (OSPOD) jsou klíčovými institucemi.  
- **Vyhláška č. 473/2012 Sb., o provedení některých ustanovení zákona o sociálně-právní ochraně dětí:** Upravuje podrobnosti o výkonu sociálně-právní ochrany.  
- **Zákon č. 218/2003 Sb., o soudnictví ve věcech mládeže:** Upravuje trestní odpovědnost mládeže a ochranná opatření.  
- **Strategie sociálního začleňování 2021–2030:** Zdůrazňuje **inovativní přístupy** pro ohrožené děti a rodiny a **stabilní financování sociálních služeb**.

---

### 9\. Pětiletý Plán – Česká Republika

| Fáze | Období | Hlavní aktivity | Milníky |
| :---- | :---- | :---- | :---- |
| **1\. Základ** | 0–12 měsíců | Založení neziskového subjektu v ČR. Dokončení prvního fyzického prototypu Krychle. Zajištění počátečního financování. Formalizace výzkumného partnerství s českou univerzitou. | Právní subjekt zaregistrován. Funkční prototyp. 3 strategická partnerství. |
| **2\. Pilot** | 12–24 měsíců | Nasazení 100–150 Krychlí ve 2–3 obcích, integrace s OSPOD a sociální prací. Sběr ochranných a dat o pohodě. První vyhodnocení. | 150 rodin podpořeno. První nezávislá hodnotící zpráva. |
| **3\. Důkazy** | 24–36 měsíců | Recenzované publikování výsledků. Přijetí alespoň jedním krajem. Expanze do 10 obcí. | 2 akademické články. Smlouva s alespoň jednou obcí/krajem. |
| **4\. Škálování** | 36–48 měsíců | 50+ obcí. Formální využití v soudních rozhodnutích. Tým 25+ lidí. | 10 000 Krychlí nasazeno. 5 soudních okresů využívá data Krychle. |
| **5\. Veřejná infrastruktura** | 48–60 měsíců | Krychle uznána jako součást národní infrastruktury rodinné justice a včasné pomoci. Spolufinancována vládou (MPSV). Mezinárodní piloty. | 50 000+ Krychlí. Vydána politická doporučení. Mezinárodní uznání. |

---

### 10\. Připojte se k Tomuto Hnutí

Poskytujte, zkoumejte, obhajujte, tvořte, spravujte

*„Každé dítě si zaslouží slyšet hlas někoho, kdo ho miluje. Každý rodič si zaslouží dosáhnout na své dítě. Story Cube to umožňuje — s jednoduchostí, bezpečností a teplem.“*

Stavíme více než zařízení. Stavíme hnutí za práva dětí, založené na důkazech a navržené pro veřejný sektor.

Ať už jste **starosta obce**, **člen OSPOD**, **soudce pro rodinné záležitosti**, **akademický výzkumník**, **poskytovatel sociálních služeb** nebo **rodič**, který tuto zkušenost zná z první ruky — je tu místo i pro vás.

- **Poskytovat:** Obce, OSPOD a soudy: vyzkoušejte Krychli ve vaší oblasti jako součást vaší strategie včasné podpory nebo ochrany veřejnosti.  
- **Zkoumat:** Univerzity: navazujte partnerství pro hodnocení dopadu na dětskou pohodu, citovou vazbu a jazykový vývoj.  
- **Obhajovat:** Odborníci v rodinném právu a justici: pomozte formovat Krychli jako uznávaný nástroj pro kontakt a důkazy.  
- **Tvořit:** Ilustrátoři, vypravěči a animátoři: přispějte do otevřené knihovny témat a příběhů.  
- **Spravovat:** Připojte se k naší správní radě. Pomozte vést organizaci s transparentností a přísností.

---

## Cubo de Histórias (Story Cube)

### Spojení, které proměňuje — most lásky mezi rodiči a dětmi

**V souladu s Úmluvou OSN o právech dítěte · Článek 9** **Česká nezisková organizace ve fázi založení** **Vytvořeno s péčí pro rodiny všude**

