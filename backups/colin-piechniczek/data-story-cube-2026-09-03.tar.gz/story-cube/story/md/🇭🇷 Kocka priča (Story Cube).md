# Kocka priča (Story Cube)

**Vizija i putokaz za ostvarivanje utjecaja – Hrvatska**  
*Dokument v3.1 · 2026\. · Hrvatski*

*„Vaš život treba biti u službi cilja, a ne stvari.“* Taj duh pokreće Story Cube – inicijativu koja ne traži financijski povrat, već obnovu jednog temeljnog prava: veze između djeteta i roditelja koji ga voli, čak i kad žive odvojeno.

---

## 1\. Zašto ovo postoji

Kad je dijete odvojeno od jednog roditelja – zbog udaljenosti, rastave ili namjernog ometanja – gubi nešto nezamjenjivo: svakodnevni zvuk osobe koja ga voli.

Story Cube nije proizvod koji usput donosi društvenu korist. To je društvena misija koja se služi tehnologijom kao alatom. Njegov prirodan institucionalni oblik stoga je **neprofitna organizacija** – u kojoj svrha oblikuje strukturu, a ne obrnuto.

Ovaj dokument postavlja viziju i putokaz kako bi Story Cube postao pokret od javnog interesa: skalabilan alat utemeljen na dokazima, koji štiti pravo djeteta na obiteljski život, podupire pravosudni sustav i pomaže javnim službama da interveniraju rano. Sve je utemeljeno na **članku 9\. Konvencije Ujedinjenih naroda o pravima djeteta**, koji jamči pravo djeteta da održava redovit kontakt s oba roditelja, osim ako je to u suprotnosti s njegovom dobrobiti.

---

## 2\. Priča iza kocke

**Od roditeljske udaljenosti do prava svakog djeteta da bude saslušano**

Story Cube rođen je iz življenog iskustva: roditelj koji gotovo mjesec dana nije mogao razgovarati sa svojim djetetom. Preusmjereni pozivi, poruke bez odgovora. Mali svakodnevni trenutci – *što si danas vidio? sviđa li ti se? što si nacrtao?* – nestajali su u tišini.

Uslijedila je bolna spoznaja: problem nije nedostatak aplikacije ili spor telefon. Problem je u tome što se kontakt djeteta s jednim roditeljem često tretira kao privilegija koju daje drugi roditelj, a zapravo je to pravo koje pripada samom djetetu.

*„Djeci treba dati glas. Ona imaju prava. Komunikacija s roditeljem koji nije svakodnevni skrbnik trebala bi biti djetetov izbor – a ne nešto što prolazi kroz filter posrednika.“*

Kocka tu ideju pretvara u fizički predmet: lijepo izrađenu drvenu kutiju sa zaslonom, mikrofonom, zvučnikom i integriranom LTE vezom, sve u jednoj jedinici. Živi u dječjoj sobi. Ne može se blokirati, preusmjeravati niti koristiti za nešto drugo. Prenosi samo glas i priče roditelja koji voli dijete – i ništa drugo s interneta.

| Nije aplikacija | Ne može se blokirati | Vođeno djetetom | Toplo i sigurno |
| :---- | :---- | :---- | :---- |
| Namjenski uređaj. Ne može se deinstalirati, oteti TikTokom niti iskoristiti za bilo što drugo. | Ugrađeni LTE jamči da nijedan posrednik ne može prekinuti vezu. | Jedna tipka za slušanje, jedna za snimanje. Nije potrebno dopuštenje odrasle osobe u prostoriji. | Drveni prijatelj kraj kreveta – a ne još jedan ekran koji se bori za pažnju. |

---

## 3\. Problem

**Razdvajanje obitelji, ometanje kontakta i šteta za djetinjstvo**

U Hrvatskoj stvarnost roditeljskog razdvajanja pogađa tisuće djece i mladih. U **2023\. godini zabilježeno je približno 4.800 razvoda brakova**, a podaci Državnog zavoda za statistiku pokazuju da je više od polovice tih brakova imalo maloljetnu djecu.

- **Djeca u rastavljenim obiteljima:** Iako ne postoji jedinstveni zbirni podatak, visok broj razvoda ukazuje na to da deseci tisuća djece i mladih odrastaju u obiteljima s odvojenim roditeljima. Prema podacima Eurostata, **gotovo svako peto dijete u Hrvatskoj živi u riziku od siromaštva**, što dodatno otežava položaj rastavljenih obitelji.  
- **Zajednička roditeljska skrb:** Obiteljski zakon polazi od načela zajedničkog ostvarivanja roditeljske skrbi i nakon razvoda, osim ako to nije u suprotnosti s dobrobiti djeteta. Sudovi sve češće donose odluke o zajedničkoj roditeljskoj skrbi, uključujući naizmjenični boravak djeteta kod oba roditelja. **Praksa pokazuje porast takvih rješenja**, premda točni statistički podaci variraju.  
- **Opterećenost sustava:** Obiteljski odjeli općinskih sudova i centri za socijalnu skrb suočavaju se s velikim brojem predmeta, a postupci ponekad traju godinama, na štetu djece.  
- **Sustav zaštite:** Sustav socijalne skrbi, na čelu s centrima za socijalnu skrb, te pravobraniteljica za djecu djeluju u zaštiti i promicanju prava djece.

**Gdje postojeći alati zakazuju**

- **Telefoni i aplikacije mogu se kontrolirati.** Roditelj s kojim dijete živi može izbrisati, ograničiti ili nadzirati komunikaciju. Glas drugog roditelja nikada ne stiže do djeteta.  
- **Obični ekrani štetni su za malu djecu.** Sadržaji vođeni algoritmima i reklame osmišljeni su da zarobe pažnju, a ne da njeguju privrženost.  
- **Djeca nemaju izravan glas.** Ovise o tuđem uređaju, tuđem rasporedu i često govore pod nadzorom.  
- **Roditelji koji ne žive s djetetom nemaju pristupačnu podršku.** Obiteljskopravni sustav skup je i teško je njime upravljati samostalno.

Osim pojedinačnih obitelji, država ima strukturnu prazninu: ne postoji široko dostupan, skalabilan alat koji bi pomogao u zaštiti prava djeteta na obiteljski život. Story Cube osmišljen je upravo za popunjavanje te praznine – ne kao dobrotvorna akcija, već kao učinkovit instrument javne zaštite i rane intervencije.

---

## 4\. Rješenje: Story Cube

**Drvena kocka. Integrirani zaslon, mikrofon i zvučnik. Jedna jedina svrha.**

Kocka je namjerno radikalna u svojoj jednostavnosti. To je jedinstven, samostalan uređaj. Čini samo ono što treba i čini to s toplinom i pažnjom.

- **Snimi:** Crvena tipka. Dijete govori, drugi roditelj prima.  
- **Slušaj:** Zelena tipka. Glas osobe koja ga voli, odmah dostupan.  
- **Podijeli na TV-u:** Pasivne crtiće zamijenite pričama koje je obitelj zajedno stvorila.  
- **Dvostruki oblak:** Ugrađeni LTE znači da se veza ne može prekinuti. Oba roditelja uvijek imaju siguran pristup.  
- **Izrađeno od certificiranog FSC drva.** Prilagodljive teme – svemir, životinje, bajke.  
- **Platforma za roditelje:** Web-aplikacija za slanje ilustracija, odabir tema i pristup alatu za pravno snalaženje.

**Gdje smo danas:** Funkcionalni digitalni MVP već radi u svakom pregledniku – s 2D i 3D pripovjedačkim motorom, glasovnim naredbama i praćenjem tijela – tako da prve obitelji iskustvo mogu odmah testirati na tabletu ili telefonu. To je zametak fizičke kocke koja je sada u razvoju i koja će svu tu funkcionalnost prenijeti u jedan samostalni drveni uređaj.

**Što Kocka nije:** Nije tablet. Nije telefonska aplikacija. Nije YouTube ekran. Nije ništa što se može preusmjeriti, blokirati ili napuniti sadržajem koji roditelji nisu odabrali. Disciplina Kocke njezina je najveća snaga.

---

## 5\. Tko ima koristi

**Djeca, roditelji, pravosudni sustav, tijela socijalne skrbi, jedinice lokalne samouprave i društvo u cjelini**

### Za dijete

- **Emocionalna sigurnost:** Svakodnevno slušanje glasa odsutnog roditelja pomaže očuvati sigurnu privrženost i štiti mentalno zdravlje.  
- **Zdravo vrijeme pred ekranom:** Bez algoritama, bez reklama, bez štetnog sadržaja – samo priče koje obitelj odabere.  
- **Vlastiti glas:** Dijete može kontaktirati roditelja kad god želi. Ne kad mu je dopušteno. Ne pod nadzorom.  
- **Ritual za laku noć:** Priča koju je snimio drugi roditelj zamjenjuje tjeskobu zbog razdvojenosti utjehom.

### Za roditelja koji ne živi s djetetom

- **Neblokirajuća prisutnost:** LTE jamči da svaka poruka stiže do djeteta. Nijednu aplikaciju nije moguće izbrisati.  
- **Pravno snalaženje:** Siguran web-portal s vodičima na jasnom hrvatskom jeziku, predlošcima za podneske i arhivom dokaza – pomaže strankama da se snađu u sudskom sustavu. Nadopunjuje, ali ne zamjenjuje, neovisno pravno savjetovanje.  
- **Dokumentirani zapis:** Svaka interakcija bilježi se s datumom i vremenom, pružajući objektivan dokaz kontinuirane roditeljske skrbi za sudske postupke.  
- **Kreativno roditeljstvo:** Slanje crteža, izgradnja animiranih priča, personalizacija Kocke za dijete.

### Za pravosudni sustav (obiteljske sudove, centre za socijalnu skrb i državno odvjetništvo)

- **Provjerljiv komunikacijski kanal:** Kocku može odrediti sud kao način olakšavanja kontakta – objektivan, nadziran i slobodan od uplitanja.  
- **Zapis o roditeljskoj uključenosti:** Datumski i vremenski zapisi zamjenjuju oprečne tvrdnje podacima. Suci i stručni djelatnici centara vide točno koliko često se roditelj povezivao i što je dijelio.  
- **Smanjenje sporova:** Kad je kontakt objektivno zabilježen, sporovi o opstrukciji i nepoštivanju odluka se smanjuju, oslobađajući sudsko vrijeme i smanjujući neprijateljstvo.

### Za centre za socijalnu skrb, jedinice lokalne i područne (regionalne) samouprave i policiju

- **Rana intervencija u obiteljskim sukobima:** Kocka se može primijeniti kao dio preventivne strategije, smanjujući ponovljene pozive službama i upućivanja u sustav zaštite.  
- **Dokaz za zaštitne i kaznene istrage:** U slučajevima kad jedan roditelj koristi dijete kako bi kontrolirao drugoga, nepromjenjivi zapis Kocke može poslužiti kao dokaz – a može se i podesiti da dopušta samo siguran, nadzirani kontakt kad postoji rizik.  
- **Uštede troškova:** Svaka obitelj podržana u ovoj ranoj fazi izbjegava eskalaciju prema institucionalnom smještaju, zaštitnim mjerama ili kaznenom progonu – štedeći znatna sredstva po slučaju i sprječavajući međugeneracijsku štetu.

### Za sveučilišta i istraživačke centre

Kocka istovremeno služi i kao istraživačka infrastruktura za proučavanje utjecaja ometanja kontakta na dječji razvoj. Kroz partnerstva s hrvatskim sveučilištima (Sveučilište u Zagrebu – Pravni fakultet, Edukacijsko-rehabilitacijski fakultet, Filozofski fakultet; Sveučilište u Splitu, Sveučilište u Osijeku i dr.) može generirati longitudinalne podatke o emocionalnoj dobrobiti, usvajanju jezika i privrženosti – pretvarajući življeno iskustvo u objavljene dokaze koji oblikuju javne politike.

### Za društvo

Prekid obiteljskih veza stvara međugeneracijske troškove: više stope problema s mentalnim zdravljem, školskog neuspjeha, konzumacije sredstava ovisnosti i delinkvencije mladih. Svaka obitelj koja ostane povezana jača je društvena stanica. Story Cube djeluje na točki prevencije – osiguravajući da ljubavna veza preživi razdvojenost, smanjujući patnju djece i sprječavajući pogoršanje štete. Društveni povrat tog ulaganja ne mjeri se u tromjesečjima, već u generacijama.

---

## 6\. Institucionalni put

**Neprofitna struktura u službi misije**

Story Cube bit će osnovan kao **udruga** (ili, po potrebi, **zaklada**) u skladu sa Zakonom o udrugama (NN 74/14, 70/17, 98/19) odnosno Zakonom o zakladama (NN 106/18, 98/19). Sva sredstva – bilo iz potpora, ugovora ili donacija – u cijelosti se ulažu u misiju: proizvodnju više kocaka, poboljšanje platforme, financiranje neovisnog istraživanja i širenje na nova područja.

Upravljanje će provoditi **upravni odbor** s iskustvom u zaštiti djece, obiteljskom pravu, digitalnoj etici i pružanju javnih usluga. Organizacija može, prema potrebi, zatražiti **status organizacije od posebnog javnog interesa** i registrirati se u odgovarajuće evidencije kako bi mogla sklapati **ugovore o suradnji** i **ugovore o dodjeli bespovratnih sredstava** s javnim sektorom.

Story Cube ne pripada dioničarima. Pripada cilju.

---

## 7\. Ekosustav podrške

**Izvori financiranja u Hrvatskoj, partnerstva i trofazna strategija**

Kao neprofitni alat osmišljen za javni sektor, Story Cube može se oslanjati na raznolik spoj izvora:

**A. Nacionalno javno financiranje**

- **Ministarstvo rada, mirovinskoga sustava, obitelji i socijalne politike:** Ključno ministarstvo za obiteljsku politiku, socijalnu skrb i prava djece; objavljuje natječaje za projekte udruga.  
- **Ministarstvo pravosuđa i uprave:** Može podržati inovacije u pravosudnom sustavu.  
- **Nacionalna zaklada za razvoj civilnoga društva:** Središnje tijelo za sufinanciranje projekata organizacija civilnog društva.  
- **Jedinice lokalne i područne (regionalne) samouprave:** Gradovi, općine i županije mogu ugovoriti pružanje usluge ili sufinancirati Kocke za obitelji na svom području.

**B. Fondovi Europske unije**

- **Europski socijalni fond plus (ESF+):** Prioriteti uključuju socijalno uključivanje, borbu protiv siromaštva i podršku obiteljima.  
- **Program Građani, jednakost, prava i vrijednosti (CERV):** Financira projekte za promicanje prava djece i obitelji.  
- **Nacionalni plan oporavka i otpornosti (NPOO):** Moguće komponente za digitalizaciju socijalnih usluga.

**C. Zaklade i filantropske organizacije**

- **UNICEF Hrvatska:** Aktivan u promicanju prava djece; može biti strateški partner.  
- **Zaklada „Hrvatska za djecu“:** Podupire projekte za dobrobit djece.  
- **Zaklada Adris, Zaklada IKEA i druge korporativne zaklade:** Putem donacija i sponzorstava.  
- **Pojedinci i pravne osobe:** Donacije s mogućnošću poreznih olakšica u skladu s propisima.

**D. Potencijalne institucije suradnice**

| Vrsta institucije | Konkretno tijelo |
| :---- | :---- |
| Ministarstva | Ministarstvo rada, mirovinskoga sustava, obitelji i socijalne politike; Ministarstvo pravosuđa i uprave |
| Pravosudna tijela | Općinski sudovi – obiteljski odjeli; Županijski sudovi |
| Centri za socijalnu skrb | Mreža centara diljem Hrvatske |
| Pravobraniteljica za djecu | Neovisno tijelo za zaštitu prava djece |
| Državno odvjetništvo | Uključeno u zaštitne i obiteljske predmete |
| Jedinice lokalne samouprave | Gradovi i općine, posebno veći gradovi (Zagreb, Split, Rijeka, Osijek) |
| Sveučilišta | Sveučilište u Zagrebu, Splitu, Osijeku, Rijeci – pravni i društveni fakulteti |

### E. Trofazna strategija

1. **Sjeme (1.–2. godina):** Potpore zaklada, pilot-projekt s jednim većim gradom i pripadajućim centrom za socijalnu skrb te obiteljskim sudom, uspostavljeno akademsko partnerstvo. Prvi fizički prototipovi na terenu.  
2. **Održivost (3.–4. godina):** Izravno ugovaranje s gradovima i županijama, prihvaćanje u sustavu socijalne skrbi, objavljena baza dokaza, širenje na više županija.  
3. **Razmjer (od 5\. godine nadalje):** Nacionalna primjena uz sufinanciranje iz EU fondova i državnog proračuna, integracija u sudske odluke i zaštitne rute. Usporedni međunarodni piloti.

---

## 8\. Usklađenost s hrvatskim pravnim i zaštitnim okvirom

Story Cube osmišljen je tako da se smjesti na sjecište hrvatske pravne arhitekture i sustava zaštite djece:

- **Ustav Republike Hrvatske, članak 62.:** Država štiti materinstvo, djecu i mladež te osigurava posebnu zaštitu djece i obvezu roditelja da skrbe o djeci.  
- **Obiteljski zakon (NN 103/15, 98/19, 47/20, 49/23):** Temeljni propis. Polazi od načela zajedničkog ostvarivanja roditeljske skrbi i prava djeteta na ostvarivanje osobnih odnosa s oba roditelja. Sud odlučuje o roditeljskoj skrbi uvijek vodeći se **dobrobiti djeteta** (čl. 5\. i čl. 98.–123.).  
- **Zakon o socijalnoj skrbi (NN 18/22):** Definira ovlasti centara za socijalnu skrb u zaštiti djece i obitelji.  
- **Zakon o zaštiti od nasilja u obitelji (NN 70/17):** U slučajevima nasilja Kocka se može koristiti samo uz odgovarajuće zaštitne mehanizme i pod stručnim nadzorom.  
- **Konvencija UN-a o pravima djeteta:** Hrvatska je ratificirala Konvenciju i ona je dio unutarnjeg pravnog poretka. Članak 9\. jamči pravo djeteta na održavanje kontakta s oba roditelja.  
- **Povelja EU-a o temeljnim pravima, članak 24.:** Prava djeteta – uključujući pravo na redovito održavanje osobnih odnosa s oba roditelja.

---

## 9\. Pojmovnik pravnih izraza

| Hrvatski pojam | Opis |
| :---- | :---- |
| **Zajednička roditeljska skrb** | Oblik roditeljske skrbi u kojem oba roditelja zajednički donose bitne odluke o djetetu i dijele odgovornost, čak i nakon razvoda. |
| **Samostalna roditeljska skrb** | Skrb koju ostvaruje samo jedan roditelj, dok drugi zadržava pravo na osobne odnose s djetetom. |
| **Osobni odnosi s djetetom** | Pravo djeteta i roditelja na međusobno viđanje, druženje i komunikaciju. |
| **Dobrobit djeteta** | Središnji standard prema kojem se procjenjuju sve odluke koje se tiču djeteta. |
| **Centar za socijalnu skrb** | Javna ustanova koja provodi poslove socijalne skrbi, uključujući zaštitu djece i obiteljsko-pravne poslove. |
| **Pravobraniteljica za djecu** | Neovisno tijelo koje prati, štiti i promiče prava djece. |
| **Obiteljski odjel općinskog suda** | Sudski odjel nadležan za obiteljske sporove, uključujući roditeljsku skrb i osobne odnose. |
| **Državno odvjetništvo** | Tijelo koje u određenim slučajevima sudjeluje u zaštiti prava djece. |
| **Županija** | Područna (regionalna) samouprava, često osnivač centara za socijalnu skrb. |

---

## 10\. Petogodišnji plan

**Od koncepta do nacionalne infrastrukture**

| Faza | Razdoblje | Ključne aktivnosti | Prekretnice |
| :---- | :---- | :---- | :---- |
| **1\. Osnivanje** | 0–12 mjeseci | Osnivanje udruge. Dovršetak prvog fizičkog prototipa Kocke (zaslon, zvuk, LTE). Osiguravanje početnog financiranja. Formaliziranje istraživačkog partnerstva s hrvatskim sveučilištem. | Registrirana pravna osoba. Funkcionalan prototip. Tri strateška partnerstva. |
| **2\. Pilot** | 12–24 mjeseca | Primjena 100–150 Kocaka u 2–3 grada, integrirano s centrima za socijalnu skrb i obiteljskim sudovima. Prikupljanje podataka o zaštiti i dobrobiti. Prva objavljena evaluacija. | 150 podržanih obitelji. Prvo neovisno evaluacijsko izvješće. |
| **3\. Dokazi** | 24–36 mjeseci | Recenzirani znanstveni rad s rezultatima. Prihvaćanje od strane sustava socijalne skrbi. Širenje na 10 gradova. | Dva akademska članka. Ugovor s barem jednim gradom/centrom za socijalnu skrb. |
| **4\. Razmjer** | 36–48 mjeseci | Više od 50 gradova/općina. Formalna uporaba u sudskim odlukama. Tim od 25+ ljudi. | 10.000 primijenjenih Kocaka. Pet sudova koristi podatke iz Kocke. |
| **5\. Javna infrastruktura** | 48–60 mjeseci | Kocka prepoznata kao dio nacionalne infrastrukture obiteljskog pravosuđa i rane podrške. Sufinanciranje iz EU i državnih izvora. Međunarodni piloti. | Više od 50.000 Kocaka. Objavljene smjernice politike. Međunarodno priznanje. |

---

## 11\. Pridružite se ovom pokretu

**Naručite, istražujte, zagovarajte, stvarajte, upravljajte**

*„Svako dijete zaslužuje čuti glas osobe koja ga voli. Svaki roditelj zaslužuje doprijeti do svog djeteta. Story Cube to omogućuje – jednostavno, sigurno i toplo.“*

Gradimo više od uređaja. Gradimo pokret za prava djece, utemeljen na dokazima i osmišljen za javni sektor.

Bez obzira jeste li gradonačelnik, stručni djelatnik centra za socijalnu skrb, sudac obiteljskog suda, državni odvjetnik, akademski istraživač, služba za podršku žrtvama nasilja ili roditelj koji iz prve ruke poznaje tu borbu – **ovdje je mjesto i za vas.**

- **Naručite:** Gradovi, centri za socijalnu skrb i obiteljski sudovi: testirajte Kocku na svom području kao dio svoje strategije rane podrške ili javne zaštite.  
- **Istražujte:** Sveučilišta: uspostavite partnerstva za evaluaciju utjecaja na dobrobit djece, privrženost i razvoj jezika.  
- **Zagovarajte:** Obiteljski odvjetnici, članovi državnog odvjetništva i sudstva: pomozite oblikovati Kocku kao prepoznat alat za kontakt i dokaze.  
- **Stvarajte:** Ilustratori, pripovjedači i animatori: doprinesite otvorenoj biblioteci tema i priča.  
- **Upravljajte:** Pridružite se našem upravnom odboru. Pomozite voditi organizaciju s transparentnošću i odgovornošću.

---

**Kocka priča (Story Cube)**  
*Veza koja mijenja sve – most ljubavi između roditelja i djece*  
Usklađeno s Konvencijom Ujedinjenih naroda o pravima djeteta · čl. 9\.  
Hrvatska udruga u osnivanju  
Stvoreno s pažnjom za obitelji posvuda  
