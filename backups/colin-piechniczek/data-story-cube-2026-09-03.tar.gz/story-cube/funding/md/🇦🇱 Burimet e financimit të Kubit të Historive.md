---

## Cubo de Histórias (Story Cube) in Albania

### Comprehensive Funding Options Review — July 2026

*“Your life should be applied to a cause, not to things.”* This spirit drives the Story Cube — an initiative that seeks not a financial return, but the restoration of a fundamental right: the bond between a child and the parent who loves them, even when they live apart. In Albania, where family separation, migration, and a reforming child protection system intersect, the Cube can serve as a critical tool of early intervention and rights protection.

---

### 1\. The Albanian Legal & Policy Window – Your Entry Point

To unlock funding, position the Cube as a tool that directly implements Albania’s child protection and family law commitments.

- **Family Code (Law No. 9062/2003, amended):** Article 219 establishes that the child has the right to maintain personal relationships and direct contact with both parents after separation. The court decides the contact regime in the best interest of the child. Joint parental authority is recognized. The Cube provides a verifiable, child-led channel for this contact.  
- **Law on the Rights and Protection of the Child (Law No. 18/2017):** Strengthens the legal and institutional framework for child protection. It mandates the State to support parents in fulfilling their responsibilities and to provide family-based alternatives over institutionalisation. The Cube can be presented as a preventative measure that keeps children out of the care system by maintaining bonds.  
- **Law on Measures against Violence in Family Relations (Law No. 9669/2006, amended):** Provides for protection orders. In cases where domestic violence is present, contact may need to be safe and monitored. The Cube’s supervised mode and immutable log directly support judicial and social service oversight.  
- **National Agenda for Children’s Rights 2021–2026:** Aligns with the EU Child Guarantee and sets priorities for deinstitutionalisation, family strengthening, and access to services. The Cube is a ready-made digital solution for “family strengthening” under this agenda.  
- **EU Accession Process:** Albania is a candidate country, benefiting from the Instrument for Pre-accession Assistance (IPA III). This is a massive funding stream that prioritises social inclusion, human rights, and rule of law — all areas where the Cube fits.

---

### 2\. Comprehensive Funding Sources for Albania

The funding landscape is a mix of pre-accession EU funds, bilateral donors, UN agencies, local government budgets, and a small but growing philanthropic sector. A blended finance model is essential.

#### A. EU Pre-Accession and Direct Funds (The Largest Opportunity)

| Funding Source | Programme / Mechanism | How the Story Cube Fits |
| :---- | :---- | :---- |
| **IPA III (2021–2027)** | Albania receives €597 million under IPA III. The key thematic windows are:  • Window 1: Rule of Law, Fundamental Rights and Democracy (includes child rights, justice reform).  • Window 4: Competitiveness and Inclusive Growth (includes social inclusion, employment, education).  Annual Action Programmes are agreed between the EU Delegation and the Albanian government. | The Cube can be funded under a future annual action programme as a “social innovation for family justice” or as part of a deinstitutionalisation programme. You do not apply directly; you partner with a ministry (e.g., Ministry of Health and Social Protection) or an INGO that becomes a beneficiary of an IPA grant. The EU Delegation in Tirana also issues direct call for proposals for civil society. |
| **EU Delegation in Tirana – Civil Society Facility** | Regular calls for proposals under the *Civil Society Facility and Media Programme*. Priorities: human rights, social inclusion, child protection, gender equality. Typical grants range from €150,000 to €500,000. | The AMKE (or an Albanian NGO partner) can lead a consortium to apply for a project that pilots the Cube with 100 families, integrating it with municipal child protection units. The call’s focus on “access to justice for children” is an ideal thematic match. |
| **Erasmus+ (Capacity Building in the Field of Youth / Education)** | Albania is a Partner Country. Calls for “Capacity Building in the Field of Youth” fund international cooperation projects that develop innovative tools for young people. | A consortium with an EU-based NGO and an Albanian youth organisation could use the Cube as a tool for children’s participation and mental health support, developing a training curriculum for parents. |
| **CERV (Citizens, Equality, Rights and Values)** | Albanian organisations are eligible as partners in transnational projects. The Daphne and Rights of the Child strands are highly relevant. | Partner with an Italian or Greek lead applicant to pilot the Cube in cross-border family cases or to address parental alienation as a form of psychological violence. Your role brings the Western Balkan dimension. |
| **Horizon Europe** | Albanian research institutions and SMEs are eligible for funding under the “Culture, Creativity and Inclusive Society” cluster. | Partner with the University of Tirana (Faculty of Social Sciences) to apply for an R\&D project on ethical, low-screen technology for child attachment. The Cube becomes the test case. |

#### B. United Nations and International Organisations (Active in Albania)

| Agency / Programme | Programme Focus in Albania | Funding Pathway for Cube |
| :---- | :---- | :---- |
| **UNICEF Albania** | Country Programme 2022–2026 focuses on child protection system strengthening, deinstitutionalisation, and access to justice for children. UNICEF often co-finances innovative pilots with government partners. | Approach the Child Protection section with a concept note. UNICEF can provide seed funding for a pilot in two municipalities (e.g., Tirana, Shkodër), cover the cost of an independent evaluation, and facilitate the integration of the Cube into the government’s child protection information system. |
| **UNDP Albania** | Programmes on rule of law, access to justice, and social inclusion. They manage the “Combating Violence against Women and Domestic Violence” programme. | The Cube can be implemented as a supervised contact tool within the Coordinated Community Response (CCR) mechanism for domestic violence. UNDP can fund the adaptation of the device’s safety protocols and a pilot in a One-Stop-Shop for victims. |
| **World Bank / Social Protection Project** | The World Bank supports Albania’s social protection reform, including the modernization of social services. The *Social Inclusion Project* and new programmes can fund digital solutions that improve case management and service delivery. | The Cube can be positioned as a technology-enabled social service that strengthens family bonds, reducing the need for costly institutional care. It can be funded under a government-executed project with World Bank loan or grant components. |
| **OSCE Presence in Albania** | Active in rule of law and human rights. They support judicial reform and the implementation of family court decisions. They often fund pilot projects that improve the functionality of courts and the rights of children. | A small grant to develop the Cube’s legal-navigation toolkit in Albanian and train judges/family mediators on its use as an evidence-generating tool. Contact the OSCE’s Rule of Law and Human Rights Department. |
| **Swiss Agency for Development and Cooperation (SDC)** | Albania is a priority country for Swiss cooperation. Focus: democratic governance, economic development, social inclusion. The SDC runs specific projects on child protection and family support. | A project proposing the Cube as a “digital innovation for maintaining family ties for children affected by migration” fits the SDC’s emphasis on diaspora and migration. Grant up to CHF 300,000. |
| **Swedish Embassy (SIDA)** | Sweden supports human rights and gender equality in Albania, with a strong focus on children and women. They fund CSO projects through direct calls. | The Cube’s dual value for children’s rights and protection from psychological violence (in obstruction cases) makes it attractive for a SIDA grant. Look for open calls or approach their development cooperation section. |

#### C. National Public Funding (Albanian Government Budget)

| Source / Institution | Mechanism | How to Access |
| :---- | :---- | :---- |
| **Ministry of Health and Social Protection (MoHSP)** | The Ministry is responsible for child protection, social care services, and the *National Helpline for Children*. It manages the budget for child protection units and the deinstitutionalisation agenda. | The MoHSP can include the Cube in its annual service delivery programme as a “supported contact service”. A direct request to the Director of Social Services, with a cost-benefit analysis showing how the Cube reduces caseloads, can lead to a pilot funded by the state budget. |
| **State Social Service (Shërbimi Social Shtetëror)** | This agency under the Ministry implements social care. It manages the network of Child Protection Units (Njësitë për Mbrojtjen e Fëmijëve) in each municipality. | The Cube can be procured and deployed by the State Social Service for use by child protection workers in cases of supervised visitation. An agreement between your organisation and the agency can be funded from the agency’s “Programme for the Development of Social Services”. |
| **Municipal Budgets (61 Municipalities)** | By law, municipalities are responsible for local social services, including family support and child protection. Large municipalities (Tirana, Durrës, Elbasan, Shkodër) have dedicated budgets for social programmes. | Approach the Directorate of Social Services in the Municipality of Tirana to co-finance a pilot of 50 Cubes for families in the capital. A simple service contract can be signed, with the municipality covering the cost of devices and connectivity from its “Social Protection” budget line. |
| **Social Fund (Fondi Social)** | A state-funded mechanism that finances social services delivered by municipalities and non-profit organisations. The Ministry issues annual calls for proposals for innovative social services. | Prepare a project proposal for “Family Digital Contact Service” and submit it to the Social Fund call. This is the most direct route to state co-financing for the Cube. Calls are typically announced in the first quarter of the year. |
| **Agency for the Protection of Children’s Rights** | An independent institution created by Law No. 18/2017. It monitors and promotes children’s rights. While it does not have a large service budget, it can provide official endorsement and advocate for the Cube’s inclusion in national programmes. | Seek its patronage (patronazh) and request a recommendation letter to the Ministry of Health and Social Protection. Its approval significantly strengthens your case for public funding. |

#### D. Albanian Philanthropic and Private Sector

The philanthropic sector in Albania is small but growing. CSR is evolving, especially in banking and telecommunications.

| Organisation | Programme / Interest | Fit for Story Cube |
| :---- | :---- | :---- |
| **BKT (Banka Kombëtare Tregtare) / Raiffeisen Bank / Intesa Sanpaolo Bank Albania** | Major banks have CSR programmes focused on children, education, and community development. Intesa Sanpaolo has a dedicated “Fondo di Beneficenza” that also operates in Albania. | A bank could sponsor the purchase of 50 Cubes for disadvantaged families, integrating this into their “investing in the community” campaign. Intesa Sanpaolo is particularly promising due to its existing Italian connection with the project. |
| **Vodafone Albania Foundation / One Albania (4iG)** | Telecoms are interested in digital inclusion and child safety online. Vodafone Foundation globally focuses on connecting families and protecting children. | Vodafone Foundation could provide LTE connectivity for the Cubes and fund the cloud platform as a flagship project for “tech for good”. One Albania might see it as part of their CSR on digital wellbeing. |
| **Kurum International / Balfin Group** | Large corporations with growing CSR arms. Balfin Group supports education and social causes through its “Balfin Social Investment” programme. | Funding for the production of the physical wooden Cubes could be framed as a “made in Albania” craft and tech initiative, supporting local artisans and children’s welfare simultaneously. |
| **Partners Albania for Change and Development / Fondacioni Së Bashku** | These are intermediaries and grant-making organisations that manage small grants from international donors (EU, US Embassy). They issue sub-grants to local CSOs. | Your local partner NGO can apply for a small action grant through Partners Albania or Fondacioni Së Bashku, which often channels funds for community-level social innovation. Budget range: €5,000 – €20,000. |
| **Diaspora Philanthropy (Diaspora Invest / individual donors)** | Large Albanian diaspora communities in Italy, Greece, the US, and Germany are deeply interested in supporting family and child-related projects. Crowdfunding or targeted diaspora appeals are viable. | A campaign on a platform like “GoFundMe” targeting the Albanian diaspora, with a clear message: “Give the gift of voice to a separated child in Albania.” This can fund an initial batch of 20-30 Cubes. |

#### E. Research and University Partnerships

| Institution | Programme | Application for Cube |
| :---- | :---- | :---- |
| **University of Tirana – Faculty of Social Sciences (Psychology / Social Work)** | The Faculty has ongoing research on family dynamics and child well-being. It participates in EU-funded projects (Erasmus+, Horizon). | Formalise a research partnership to design and carry out the longitudinal evaluation of the Cube’s impact on attachment and language. The university can be the co-applicant for an Erasmus+ or Horizon Europe grant. |
| **MEDRESA / Albanian University (UFO) / Epoka University** | Private universities with active research agendas and good international connections. | A joint application to the EU or a local innovation fund to study the Cube’s acceptance among Albanian families. |
| **Institute of Public Health** | Interested in child mental health and prevention of adverse childhood experiences. | Partner to add the Cube to a community mental health pilot in Shkodër or Kukës, funded by the Ministry of Health. |

---

### 3\. Refined 3-Phase Funding Strategy for Albania

**Phase 1: Farë (Seed, Years 1–2) — Target: €60,000–€120,000**

- **Primary Funding:** A small grant from **UNICEF Albania** (seed funding for innovation in child protection) or a **Partners Albania** sub-grant from an EU Civil Society Facility scheme. Use these to translate the Cube interface and parent platform into Albanian, produce 20-30 prototypes, and run a proof-of-concept with two Child Protection Units in Tirana and one other municipality.  
- **Corporate In-Kind:** **Vodafone Albania Foundation** for connectivity and cloud support.  
- **Research Anchor:** Sign an MoU with the **Faculty of Social Sciences, University of Tirana** for pro-bono evaluation design.  
- **Legal Status:** Register as a local *Organizatë Jo-Fitimprurëse (OJF)* — equivalent to a non-profit association — or partner with an existing OJF that can serve as the legal host. This is essential for opening a bank account and contracting with donors.

**Phase 2: Pilotim dhe Evidenca (Pilot & Evidence, Years 3–4) — Target: €400,000–€700,000**

- **Primary Funding:** Lead an **EU Delegation Civil Society Facility** proposal (as a consortium of Albanian OJF \+ Italian ETS) for a full pilot with 200 Cubes across 5 municipalities. Combine with an **SDC (Swiss Cooperation)** grant for the migration angle.  
- **Government Contract:** Secure an agreement with the **State Social Service** to integrate the Cube into the standard package for supervised contact, funded by the **Social Fund**. The MoHSP includes the Cube in its next Annual Social Protection Programme.  
- **Evaluation:** Publish a peer-reviewed evaluation in an Albanian and international journal, funded by a small **UNICEF** or **World Bank** research grant.

**Phase 3: Shkallë dhe Infrastrukturë Publike (Scale & Public Infrastructure, Year 5+) — Target: €1 million+ annually**

- **Primary Funding:** The Cube is embedded in the national child protection system and funded through the **IPA III National Action Plan** for the next programming period, as part of the deinstitutionalisation and family strengthening component.  
- **Judicial Integration:** The Ministry of Justice and the High Council of Justice issue a directive recommending the Cube as a standard tool in family court cases involving contact disputes. The device is procured centrally.  
- **International Replication:** Using the Albanian and Italian evidence base, apply for a major **Horizon Europe** or **CERV** transnational project to export the model to Kosovo, North Macedonia, and Montenegro, with your organisation as the Western Balkan hub.

---

### 4\. Concrete Next Steps in Albania

1. **Weeks 1-4 — Local Presence:** Identify and secure a partnership with a well-regarded Albanian non-profit organisation (OJF) active in child protection or family rights. This OJF will be the initial legal and operational home for the Albanian pilot, allowing you to open a local bank account and apply for funds that require an Albanian registration number (NUIS).  
2. **Month 2 — First Funder Contact:** Write a concise concept note and request a meeting with the **Child Protection Specialist at UNICEF Albania** and the **EU Delegation Civil Society Focal Point**. Present the Cube as a practical tool for the deinstitutionalisation agenda.  
3. **Month 3 — Government Ally:** Approach the **Director of Social Services at the Municipality of Tirana** or the **State Social Service**. Do not ask for money initially; ask for a letter of interest expressing willingness to co-design a pilot within their child protection units. This letter is essential for donor applications.  
4. **Month 4-6 — Small Pilot:** Use the initial partnership and letters of support to secure a small grant (€10,000–€20,000) from **Partners Albania** or the **OSCE Presence in Albania** to run a 10-family pre-pilot. Document it with photos and testimonials.  
5. **Ongoing — Monitor IPA III:** Track the EU Delegation’s calls for proposals on the TED portal and the Delegation’s website. The key call to target is the “Support to Civil Society Organisations in promoting child rights and access to justice”. When it opens, you will be ready with a strong consortium, pilot data, and government backing.

Albania’s child protection system is in a state of dynamic reform, with a strong political will to move from institutional care to family-based solutions. The Story Cube offers a tangible, low-cost, rights-based intervention that aligns perfectly with this national priority. By navigating the IPA and local partnership landscape carefully, Albania can become a beacon for the Cube’s impact in the entire Western Balkans region.  
