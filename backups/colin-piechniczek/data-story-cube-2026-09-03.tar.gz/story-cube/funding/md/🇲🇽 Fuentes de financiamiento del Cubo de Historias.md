---

### 1\. The Legal & Policy Window in Mexico – Your Entry Point

Before seeking funding, you must frame the Cube as a tool that directly implements Mexico’s child protection laws and national goals. This alignment unlocks doors:

- **Ley General de los Derechos de Niñas, Niños y Adolescentes (LGDNNA, 2014, last reform 2024):** Establishes the *Sistema Nacional de Protección Integral (SIPINNA)* and mandates that all authorities guarantee the right of children to maintain relationships with both parents, with the *interés superior del menor* as the guiding principle.  
- **Anexo Transversal de la Niñez (Federal Budget Annex for Children):** Every year, the federal budget identifies specific spending on children’s rights. For 2025, this annex earmarks hundreds of billions of pesos. Your Cube can be budgeted under *protección y restitución de derechos de la niñez* or *fortalecimiento familiar*.  
- **Código Civil Federal, Artículos 411-424:** Recognises shared custody and mandates continued parental contact after separation. The Cube provides the *how*—a neutral, verifiable channel.  
- **SIPINNA’s National Action Plan:** Calls for innovative, evidence-based interventions that prevent family separation. The Cube is a direct operational response.  
- **Procuraduría Federal de Protección (PFPNNA) and the 32 State Procuradurías:** These bodies are legally responsible for protecting at-risk children. They can contract the Cube as a supervised contact and early intervention tool.

Present the Cube not as a device but as *“infraestructura para la convivencia familiar protegida.”* This is the language that unlocks public budgets.

---

### 2\. Comprehensive Funding Sources in Mexico

I have expanded significantly on your document’s initial list, structuring it into actionable categories for a blended finance approach across your three phases.

#### A. Federal Public Funding (Direct Budget Allocations & Programmes)

Mexico’s federal budget contains several specific line items and programmes that can fund the Cube.

| Funding Source | Programme / Mechanism | How the Story Cube Fits & How to Apply |
| :---- | :---- | :---- |
| **Sistema Nacional DIF (SNDIF)** | *Programa de Atención a la Primera Infancia* and *Programa de Protección y Restitución de Derechos de Niñas, Niños y Adolescentes*. The SNDIF manages a significant budget for family strengthening and alternative care prevention. | The Cube can be piloted as part of the DIF’s *Estrategia de Prevención de la Separación Familiar*. SNDIF can procure devices and services directly or transfer funds to state DIFs. Approach the Dirección General de Protección a la Infancia with a formal proposal aligned with their annual work plan. |
| **Procuraduría Federal de Protección (PFPNNA)** | Budget for *Medidas de Protección Especial* (Special Protection Measures). When a child’s rights are violated, the Procuraduría must act. It can contract services for supervised visitation or facilitate contact in cases of parental obstruction. | The Cube can be offered as a *medida de protección especial* that is less intrusive than institutionalisation and guarantees the child’s right to be heard. A direct service agreement (convenio de colaboración) can fund a pilot. This is a key path for Scale Phase. |
| **INDESOL / Secretaría de Bienestar** | *Programa de Coinversión Social (PCS)*: An annual competitive grant for civil society organisations (CSOs). It co-finances projects that combat poverty, strengthen family structures, and promote child rights. In recent years, budgets for the PCS have been around 300-400 million pesos. | Your AMKE (or AC – Asociación Civil) can submit a project to pilot the Cube in a high-marginalisation municipality. The PCS typically requires a 20-25% counterpart contribution, which can be in-kind (e.g., volunteer time, device prototypes). This is perfect for the Seed Phase. Monitor the Bienestar website for the annual *convocatoria*. |
| **Secretaría de Gobernación (SEGOB)** | *Comisión Nacional de Derechos Humanos (CNDH)* and *Programa de Apoyo a la Sociedad Civil*: SEGOB often has specific funds for human rights promotion and protection. The Cube as a tool for the child’s right to family life qualifies under the rights of children and access to justice. | Look for SEGOB’s *Programa de Fomento a las Actividades de la Sociedad Civil*. These grants can support the parent legal-navigation portal and rights-awareness workshops that accompany the Cube. |
| **Secretaría de Salud (SSA)** | *Programa Nacional de Salud Mental y Prevención de Adicciones*: The Cube’s role in preserving secure attachment and preventing childhood mental health crises is a strong fit. The SSA funds community-based mental health interventions. | Partner with a local *Centro de Salud* or *Hospital de la Mujer* to integrate the Cube into post-divorce family support as a *prevención de trastornos del apego*. The SSA’s *Comisión Nacional de Salud Mental y Adicciones* can provide operational funding. |
| **Anexo Transversal de la Niñez (Federal Budget Annex)** | This is not a programme but a tracking mechanism. Dozens of federal agencies must earmark child-focused spending. For example, the *Secretaría de Educación Pública (SEP)* has budgets for family participation in education. | You can advocate for the Cube to be included in the *Anexo Transversal* under SNDIF, PFPNNA, or even the *Secretaría de las Mujeres* (for domestic violence-related obstruction cases). Inclusion here guarantees multi-year line-item funding. |

#### B. State & Municipal Funding (The Decentralised Route)

Given Mexico’s federal structure, the 32 states and 2,471 municipalities hold enormous potential for direct commissioning.

| Funding Source | How It Works | The Cube’s Angle |
| :---- | :---- | :---- |
| **Sistemas Estatales DIF (32)** | Each state DIF has its own budget and autonomy. They manage *Procuradurías Estatales de Protección* and run *Centros de Asistencia Social*. They often have more agile procurement processes than the federal level. | Approach a progressive state like Nuevo León, Jalisco, or Yucatán, which are open to tech-based social innovation. Offer a *convenio* where the state DIF funds 100 Cubes and the associated platform for a year, with an in-built evaluation. State DIFs can use federal transfers (from Ramo 33, for instance) for this purpose. |
| **Sistemas Municipales DIF (for large cities)** | Municipal DIFs in cities like CDMX, Guadalajara, Monterrey, Puebla, and León have multi-million peso budgets for social assistance. They can directly purchase goods and services for vulnerable families. | The Cube can be integrated into the *Programa de Fortalecimiento a la Familia* of a major municipality. A pilot with the **DIF CDMX** (which serves millions) or **DIF Guadalajara** would be a powerful national reference. They can fund a “family digital contact” pilot with a simple service contract. |
| **State-Level Coinversión Programmes** | Many states mirror the federal PCS and have their own grant schemes for CSOs, often called *Programa de Coinversión Social Estatal*. These are less competitive than the federal one. | Perfect for funding a localised pilot. For example, the *Instituto de Desarrollo Social de Jalisco* or *Secretaría de Desarrollo Social de Nuevo León* can co-finance an initial 50-Cube deployment. |
| **Presupuesto Participativo (Mexico City)** | In CDMX, citizens vote on local projects. A network of parents and family rights groups could propose the Cube as a community project for a specific *alcaldía* (borough). | This is a unique, grassroots way to secure public money directly from the community. You would need to organise a campaign, but it proves demand and can be replicated. |

#### C. The Judicial & Access to Justice Pathway

While courts do not provide direct grants, they hold budgets for auxiliary services, expert evidence, and can become your biggest ally.

| Mechanism | Detail | Action for Story Cube |
| :---- | :---- | :---- |
| **Poder Judicial de la Federación / Local** | The federal judiciary and state-level *Tribunales Superiores de Justicia* have modernisation funds. The Cube, with its tamper-proof log, reduces litigation and provides objective evidence, directly aiding judges. | Propose a *proyecto de colaboración* to the *Centro de Convivencia Familiar Supervisada* of a state court. The court can order the Cube as a supervised contact method, and you can charge a fee per case or secure an annual service contract from the court’s administration budget. |
| **Fondos de Ayuda a Víctimas (e.g., CEAV)** | The *Comisión Ejecutiva de Atención a Víctimas* has a fund to provide services to victims of crime, including child victims of parental alienation or domestic violence. The Cube can be a measure of reparation and support. | If a child is a victim of obstruction or psychological violence, the CEAV can directly fund a Cube and its connectivity as part of a comprehensive reparation plan. Partner with a victim support organisation to channel these funds. |
| **Centros de Justicia para las Mujeres (CJM)** | Present in every state, these centres handle domestic violence cases holistically. They have budgets for child-friendly spaces and interventions to break the cycle of violence, which often includes using children to control the other parent. | The Cube can be installed in CJMs for supervised, safe communication between a child and a non-resident parent where a protection order exists. The CJM can fund the devices through its federal *PAIMEF* (Programa de Apoyo a las Instancias de Mujeres) allocations or state budgets. |

#### D. International Cooperation & Multilateral Agencies

Mexico is a priority country for many international donors focused on child rights and justice reform.

| Donor / Programme | Specific Focus | Application Fit |
| :---- | :---- | :---- |
| **UNICEF México** | Active in Mexico with a 2020-2025 programme cycle focusing on child protection, early childhood development, and ending violence against children. They frequently co-fund innovative pilots with government partners. | The Cube as a device to uphold Article 9 of the UNCRC is a direct match. UNICEF can provide seed funding for a pilot, co-finance the evidence-base, and—crucially—broker partnerships with SNDIF and PFPNNA. Approach UNICEF’s Child Protection Officer with a concept note. |
| **USAID Mexico** | Programmes under “Crime and Violence Prevention” and “Civil Society and Human Rights.” USAID funds rule of law projects that improve access to justice, including family justice. | The Cube’s legal-navigation toolkit and generation of court-admissible evidence is a justice-sector innovation. A grant could fund the adaptation of the parent portal for the Mexican legal system and training for court staff. |
| **European Union (Global Europe / NDICI)** | The EU’s bilateral programme with Mexico includes a “Social Cohesion” pillar. They fund CSO projects on human rights, child protection, and digital inclusion. | A consortium with a European partner (e.g., from Italy or Spain) and a Mexican university could apply for a grant to pilot and evaluate the Cube as a tool for upholding children’s rights in contexts of family separation, with a cross-border learning component. |
| **Inter-American Development Bank (IDB Lab)** | IDB Lab is the innovation arm, testing early-stage, tech-driven solutions for social inclusion. They have a specific interest in ethical tech for vulnerable populations. | The Cube as a “dedicated, non-addictive device for children’s emotional security” is a perfect IDB Lab prototype. They could fund a proof-of-concept pilot in 2-3 Mexican cities, with a loan/grant blend. |
| **Fondo Canadá para Iniciativas Locales (FCIL)** | The Canadian Embassy in Mexico runs a small grants programme for innovative projects that advance human rights and gender equality. Budgets are small (CAD $15,000–$50,000) but perfect for a first prototype or workshop. | A project to translate the Cube’s parent platform into Mexican Spanish, add culturally relevant stories, and run focus groups with Mexican separated families is ideally suited for an FCIL grant. |

#### E. Private Foundations & Corporate Social Responsibility (CSR)

Mexico has a highly developed philanthropic sector. These foundations are the most likely source of Seed and Pilot phase funding.

| Foundation / Corporation | Programmes & Priorities | Story Cube Alignment |
| :---- | :---- | :---- |
| **Fundación Carlos Slim** | Major grants in health, education, and social development. Their *Programa de Apoyo a la Primera Infancia* and *Fortalecimiento Familiar* strands are ideal. They like scalable, technology-based solutions. | Submit a detailed proposal for the physical Cube production and cloud platform under their “Bienestar Social” area. They can fund a multi-year pilot with a rigorous impact evaluation. |
| **Fundación Televisa** | Focuses on childhood, education, and community wellbeing. They have funded tech-for-good projects and have a massive media platform for dissemination. | The Cube’s creative, story-building features align with their educational mission. A partnership could fund a library of culturally relevant Mexican stories (in Spanish and indigenous languages) and a national awareness campaign about children’s right to contact. |
| **Fundación Merced** | Supports social enterprises and innovative non-profits with capacity building and grants. They are a partner of the *Programa de Coinversión Social* and often co-invest. | The Cube’s sustainable public-commissioning model fits their “social enterprise” lens. They can provide seed capital and organisational strengthening, especially if you choose a hybrid AMKE/social enterprise structure. |
| **Fundación FEMSA** | Focuses on early childhood (0-5 years) and water/sanitation. Their *Primera Infancia* programme is science-based and aims to improve caregiver-child interactions. | The Cube as a tool for secure attachment and language development in the first five years fits their neuroscience-informed approach perfectly. A research partnership on the Cube’s impact on language and emotional regulation could secure funding. |
| **Fundación BBVA México** | Has a robust social development programme, funding projects in education, health, and social inclusion. They often support the digitisation of social services. | The Cube’s digital platform and LTE connectivity could be pitched as a “digital inclusion for the most vulnerable families” project. They might fund the connectivity costs and the parent portal for a large cohort. |
| **Fundación CitiBanamex / Banorte / Santander** | All have CSR lines for children’s welfare, family financial education, and community development. Banks are especially interested in financial literacy and tools that reduce economic burden. | The Cube’s legal navigation toolkit, which helps parents avoid costly litigation, can be framed as a “family financial resilience” tool. A bank could sponsor the toolkit’s development as part of its community investment programme. |
| **Fondo Unido – United Way México** | Funds community-based projects focusing on education, health, and financial stability. They often work with local partners and can mobilise employee volunteering. | A pilot in a specific community can be co-funded by United Way, with employees from partner companies volunteering to help assemble or distribute Cubes. This builds broad community ownership. |
| **Nacional Monte de Piedad** | The historic pawnshop’s philanthropic arm (Fundación Montepío) makes large social investments, particularly in family well-being, health, and education. They have an annual open call. | An annual grant from the I.A.P. could fully fund a state-wide pilot. Their focus on “preservation of the family” and historical commitment to social welfare makes this a high-probability match. |

#### F. Social Innovation & Impact Investment

Mexico has a growing impact investment ecosystem. While the Cube is a non-profit, a parallel Social Purpose Entity can access these funds.

| Source / Vehicle | Description | How to Access |
| :---- | :---- | :---- |
| **SVX México** | A social investment platform and advisor. They can connect you with impact investors willing to provide patient capital for scaling. | While you are a non-profit, you could create a revenue-generating model (e.g., selling the Cube to private clients who can afford it, with profits subsidising the free public programme). SVX can help structure this and find investors for the hardware/software arm. |
| **Fondo de Fondos de Capital Emprendedor (Mexico Ventures)** | A government-backed fund of funds that invests in venture capital. Through the right VC, a tech-for-good startup could receive equity investment. | If you were to spin off the technology platform as a social purpose corporation (Sociedad por Acciones Simplificada de Impacto), you could seek impact VC funding. This is complex but possible for the Scale phase to ramp up production. |
| **Bonos de Impacto Social (Social Impact Bonds)** | Mexico has piloted SIBs in areas like education and employment. A SIB for family justice, where investors fund the Cube’s rollout and the government repays based on savings from reduced litigation and care placements, is a long-term play. | Start conversations with the *Secretaría de Hacienda* and a facilitator like *Social Finance* or the IDB to structure a feasibility study. This is a Year 4-5 activity once you have robust pilot data. |

#### G. Research & University Funding

To build your evidence base, partner with academia and tap dedicated research funds.

| Institution | Programme | Use for Story Cube |
| :---- | :---- | :---- |
| **CONAHCYT (Consejo Nacional de Humanidades, Ciencias y Tecnologías)** | The *Programa Nacional Estratégico de Educación* (PRONACES) and specific calls for “social appropriation of knowledge” and “health and well-being.” CONAHCYT funds research projects led by universities that include civil society partners. | Join a UNAM or ITESM research project to evaluate the Cube’s psychosocial impact. CONAHCYT can fund the entire three-year longitudinal study, covering research staff, devices, and dissemination. The CSO (your organisation) can be the non-academic beneficiary. |
| **UNAM, IPN, ITESM, UAM, IBERO** | All have internal research funds and are eager to partner on social impact projects. Their psychology, law, and engineering departments can contribute. | A partnership with the *Facultad de Psicología* at UNAM to validate the Cube’s effect on attachment, or with ITESM’s *Escuela de Gobierno* to analyse its impact on judicial efficiency, opens access to their seed funds and CONAHCYT networks. |
| **UNICEF / INSP (Instituto Nacional de Salud Pública)** | Joint studies on childhood well-being. They have budgets for field research and pilot evaluations. | A joint evaluation with the INSP could add crucial public health weight to your evidence, supporting adoption by the Secretaría de Salud. |

---

### 3\. Refined 3-Phase Strategy for Mexico

Mapping the above sources to your roadmap.

**Phase 1: Semilla (Seed, Years 1–2) – Target: MXN $2M–$4M (approx. €100k–€200k)**

- **Primary Funding:** A grant from **INDESOL’s Programa de Coinversión Social** (federal) combined with a small grant from the **Fondo Canadá (FCIL)** or a state-level coinversión programme. Use these to fund the first 50–100 Cube prototypes and a pilot in one high-need municipality.  
- **Foundation Anchor:** Secure a first-year operational grant from **Fundación Merced** or **Fundación FEMSA** to co-finance the core team and the adaptation of the parent platform to Mexican Spanish.  
- **Strategic Partner:** Formalise a research collaboration with a university (e.g., UNAM’s Psicología) and a DIF municipal (e.g., DIF Nezahualcóyotl or DIF León) for pro-bono evaluation design and pilot distribution.  
- **Legal Status:** Establish an *Asociación Civil (AC)*—the standard non-profit vehicle in Mexico—and apply for *donataria autorizada* status from the SAT (Hacienda) to make donations tax-deductible for private donors. This is crucial for CSR and foundations.

**Phase 2: Piloto y Evidencia (Pilot & Evidence, Years 3–4) – Target: MXN $10M–$20M (approx. €500k–€1M)**

- **Primary Funding:** A major grant from **Fundación Carlos Slim** or **Nacional Monte de Piedad** to scale to 500 Cubes across 5 municipalities. Combine this with a **USAID Mexico** grant to develop and test the legal-navigation portal.  
- **Public Contract:** Secure the first direct service agreement with a **Sistema Estatal DIF** (e.g., DIF Jalisco or DIF Nuevo León) using their federal Ramo 33 transfers, embedding the Cube in their family support services.  
- **Research Validation:** A **CONAHCYT**\-funded project led by a university, with your AC as the social partner, to publish two peer-reviewed papers on attachment and language outcomes.  
- **Key Milestone:** The Cube is officially recognised in a circular by the **PFPNNA** as a recommended tool for supervised contact, and a state *Tribunal Superior de Justicia* begins ordering it in family cases.

**Phase 3: Escala e Infraestructura Pública (Scale & Public Infrastructure, Year 5+) – Target: MXN $50M+ annually (approx. €2.5M+)**

- **Primary Funding:** National rollout co-financed through the **Anexo Transversal de la Niñez** and direct procurement by SNDIF/PFPNNA. You will now be a strategic supplier to the federal government.  
- **Judicial Integration:** Service contracts with multiple state judiciaries to provide Cubes as an integral part of the family court process, funded by court modernisation budgets.  
- **International Pilots:** Leverage Mexican success to secure a **Global Europe (EU)** or **IDB Lab** grant for replication in Central America, where family separation and migration contexts are similar.  
- **Key Milestone:** 10,000+ Cubes active; Mexican Congress includes the Cubo de Historias as a named intervention in the next National Development Plan for Children.

---

### 4\. Concrete Next Steps in Mexico

1. **Week 1-4 – Legal Structure & Tax Status:** Incorporate the **Asociación Civil (AC)** with a clear, mission-aligned corporate purpose: *"Promover y proteger el derecho de niñas, niños y adolescentes a mantener el contacto y la comunicación con ambos progenitores, mediante herramientas tecnológicas éticas y accesibles."* Immediately file for *donataria autorizada* (it takes 6-12 months, so start early).  
2. **Month 2 – First Grant Target:** Prepare a concept note for **INDESOL’s Programa de Coinversión Social** (federal). If the annual call is closed, apply to a state-level coinversión programme (e.g., **Instituto de Desarrollo Social de Jalisco**). Simultaneously, write to the **Canadian Embassy** for a small FCIL grant to fund a series of focus groups with separated families to refine the product.  
3. **Month 3 – Build the Academic and Institutional Alliance:** Secure a Memorandum of Understanding with the *Clínica de Atención Psicológica* at **UNAM** and with the *Procuraduría de Protección* of the **DIF CDMX** or the **DIF Estado de México**. This gives you the credibility to approach major foundations.  
4. **Month 4-6 – Foundation Outreach:** Approach **Fundación FEMSA** (early childhood) and **Fundación Merced** (social enterprise). Present the Cube as a *programa de prevención de la separación familiar traumática*. Do not ask for money initially; ask for a meeting to co-design the evaluation framework. The funding will follow.  
5. **Ongoing – Monitor SIPINNA:** Follow the *Secretaría Ejecutiva del SIPINNA* and attend its open sessions. The Cube should be presented there as a model of *innovación para la garantía de derechos*; this is the fastest route to federal recognition and inclusion in the Anexo Transversal.

Mexico’s child protection system is actively seeking scalable, rights-based tools that reduce judicial backlogs and genuinely improve children’s lives. The Story Cube is a ready-made answer. By walking through the institutional doors in the right order—municipal pilot, DIF adoption, federal line-item—you will transform a wooden box of stories into a national guarantee that no child has to lose the voice of someone who loves them.  
