---

**Kostka příběhů (Story Cube) in the Czech Republic** Comprehensive Funding Options Review — July 2026

“Your life should be applied to a cause, not to things.” This spirit drives the Story Cube — an initiative that seeks not a financial return, but the restoration of a fundamental right: the bond between a child and the parent who loves them, even when they live apart. In the Czech Republic, where high divorce rates, a strong tradition of institutional care, and a modernising child protection system intersect, the Cube can serve as a critical tool of early intervention, trauma prevention, and the practical fulfilment of the child's right to family life.

### 1\. The Czech Legal & Policy Window – Your Entry Point

To unlock funding, position the Cube as a tool that directly implements Czech child protection and family law commitments.

- **Civil Code (Act No. 89/2012, Občanský zákoník):** Section 888 explicitly establishes the child's right to maintain personal contact with both parents, and Section 891 recognises the right of the child to be in contact with grandparents and siblings. The court can regulate the extent of contact, including in a neutral environment or through specific means. The Cube provides a child-led, verifiable, and safe channel for fulfilling this contact.  
- **Act on Social and Legal Protection of Children (Act No. 359/1999, amended):** The cornerstone of child protection. It mandates preventive and supportive measures to keep families together and to support parents in resolving conflicts. The Cube can be integrated into the individual child protection plan (Individuální plán ochrany dítěte) as an innovative tool for supervised distance contact, directly implemented by the municipal social-legal protection authority (OSPOD).  
- **Law on Protection against Domestic Violence (Act No. 135/2006):** Provides for expulsion orders and interim measures. In cases where physical contact must be suspended but emotional bond preservation is crucial, the Cube's supervised mode and tamper-proof record offer a secure, court-admissible solution for continuing the parental voice in the child's life under the watch of intervention centres.  
- **National Strategy for the Protection of Children’s Rights 2021–2029 (Národní strategie ochrany práv dětí):** Emphasises deinstitutionalisation, strengthening foster and biological family support, and using modern technologies for child participation. The Cube is a ready-made digital tool for “supporting family bonds” and “child participation” under this strategy.  
- **EU Child Guarantee – Czech Action Plan:** The Czech Republic has committed to combating child poverty and social exclusion, with a focus on children in alternative care and those from disadvantaged families. The Cube, especially when targeted at children in foster care, in long-distance family arrangements, or in the OSPOD caseload, directly supports the goal of “access to adequate, family-based services.”

---

### 2\. Comprehensive Funding Sources for the Czech Republic

As an EU Member State, the Czech funding landscape is dominated by EU structural and investment funds, complemented by national public budgets, a robust system of grant-making foundations, and significant corporate CSR. A blended finance model is essential.

#### A. European Union Structural and Direct Funds (The Largest Opportunity)

| Funding Source | Programme / Mechanism | How the Story Cube Fits |
| :---- | :---- | :---- |
| **ESF+ (European Social Fund Plus)** | **Operational Programme Employment Plus (OPZ+)** , managed by the Ministry of Labour and Social Affairs (MPSV). Priority axes: social inclusion, support for families and children, modernisation of social services, and innovative pilot projects. Typical calls fund services that shift care from institutions to the community. | The Cube can be funded as a “technology-enabled social service for maintaining family contacts” under a call for innovative projects in child protection. A consortium led by a registered social service provider (non-profit or municipality) can apply directly for a 3-year project piloting 200 Cubes with OSPOD offices across 5 regions. Grant: CZK 10–50 million (€400,000–€2 million). |
| **ESF+** | **Operational Programme Jan Amos Komenský (OP JAK)** — education and research. | A research-focused consortium (university \+ NGO) can apply for a project to develop an evidence-based methodology for the Cube's use in early childhood education and family support, including an impact evaluation. |
| **ERDF (European Regional Development Fund)** | **Integrated Regional Operational Programme (IROP)** and **Operational Programme Technology and Application for Competitiveness (OP TAK)** . They fund social infrastructure and innovation. | If the Cube producer sets up a Czech social enterprise (sociální podnik), an application for the development and production of the Cube as an assistive technology for families can be submitted under OP TAK's “Innovation Vouchers” or “Social Innovation” calls. |
| **CERV (Citizens, Equality, Rights and Values)** | **Daphne strand** (combatting violence against children) and **Rights of the Child** strand. Czech NGOs and universities are fully eligible as lead or partner applicants. | Lead a transnational project (e.g., with partners from Italy, Spain, and Poland) to pilot the Cube as a supervised, trauma-informed contact tool in domestic violence and high-conflict separation cases. The project can fund the Cube's safety protocol adaptation, judicial training, and a multi-country trial. Grant: €500,000–€2.5 million. |
| **Erasmus+ (KA2 Cooperation Partnerships)** | Focus on school education, adult education, and youth. Czech NGOs and schools are very active. | A consortium of a Czech faculty of education, a family mediation centre, and an Italian partner (using the existing Cube expertise) can apply to create a training curriculum for teachers and OSPOD social workers on supporting children through separation using the Cube. Grant: €120,000–€400,000. |
| **Horizon Europe** | Cluster 2 “Culture, Creativity and Inclusive Society”, Destination “Innovative Research on Social and Economic Transformations”. Calls on child well-being, digital child rights, and social innovation. | A consortium led by Masaryk University (Institute for Research on Children, Youth and Family) or Charles University can apply for an R\&D grant to study the neuro-psychological impact of voice-only vs. screen-based remote contact on attachment and stress in young children. The Cube is the core research apparatus. |
| **EEA and Norway Grants** | The Czech Republic receives substantial funding under these grants. The current programming period (2021–2028) focuses on innovation in social inclusion, child welfare, and justice. The **“Human Rights and Inclusion”** and **“Justice”** programmes are highly relevant. | Apply through the Czech EEA Grants programme operator (Ministry of Finance). The Cube fits perfectly under calls for projects that protect children's rights, support access to justice for vulnerable groups, and modernise the justice system. Partner with a Norwegian or Icelandic entity (e.g., Oslo University, a children's rights NGO) to build a strong transnational project. Grant: €200,000–€1 million. |

#### B. National Public Funding (Czech Government Budget)

| Source / Institution | Mechanism | How to Access |
| :---- | :---- | :---- |
| **Ministry of Labour and Social Affairs (MPSV) – Department of Family and Child Protection** | Manages the **State Budget Chapter for Social and Legal Protection of Children**. Annually issues grant programmes (dotační programy) for NGOs providing child protection services and for innovative projects. | Apply for a “Pilot project for the implementation of innovative methods in social and legal protection” grant. Present the Cube as a tool for “supported remote contact” for children in foster care or families in crisis. Grant: CZK 1–5 million (€40,000–€200,000). MPSV endorsement is also key for unlocking ESF+ funding. |
| **Ministry of Justice** | Funds probation and mediation services and is responsible for the reform of family justice. Issues calls for projects that support restorative justice and alternative dispute resolution. | The Cube can be integrated into a project with the Probation and Mediation Service (Probační a mediační služba) as a tool for maintaining parent-child bonds during the mediation of high-conflict divorces. A pilot in 5 family court districts. |
| **Regional Authorities (Kraje)** | Each of the 14 regions has its own budget for social services and child protection. They can directly commission services from NGOs and social enterprises through multi-year service contracts. | Approach the Department of Social Affairs at a progressive regional authority (e.g., South Moravian Region, Prague City Hall). Propose a 3-year service agreement: “Regional Network of Supported Remote Contact Centres Using Story Cubes.” The region co-finances the staff and devices, while ESF+ covers the evaluation and methodology. Budget per region: CZK 3–8 million annually. |
| **Municipalities with Extended Powers (Obce s rozšířenou působností, ORP) / OSPOD** | The OSPOD offices are the frontline child protection authorities. They do not have large flexible budgets but can participate in jointly funded projects (e.g., as project partners in an ESF+ application). | Secure a Letter of Commitment from a major OSPOD (e.g., Brno, Ostrava, Plzeň) to act as a pilot site. They contribute their social workers' time (in-kind co-financing), which is highly valued in EU projects. This builds the critical bottom-up demand. |
| **Office of the Government – Department of Social Inclusion / Agency for Social Inclusion** | Focuses on Roma integration and reducing social exclusion. Family separation and institutionalisation are major issues. | The Cube can be piloted in socially excluded localities as a culturally sensitive tool (voice-only, low text barrier) to strengthen family ties. The Agency can facilitate access to the pilot communities. |

#### C. Czech Philanthropic and Private Sector (A Strong Pillar)

The Czech Republic has a mature and growing foundation sector, with several large, independent grant-makers.

| Organisation | Programme / Interest | Fit for Story Cube |
| :---- | :---- | :---- |
| **Nadace OSF (Open Society Fund Prague)** | Focuses on justice, human rights, civic participation, and innovation in public services. Runs the “Active Citizens Fund” from the EEA Grants. | The Cube's dual value for children's rights and family justice system innovation makes it an ideal candidate for an OSF project grant. They can fund the initial advocacy, legal analysis, and a 50-family proof-of-concept. Grant: CZK 500,000–2 million (€20,000–€80,000). |
| **Nadace České spořitelny (Czech Savings Bank Foundation)** | A large corporate foundation focusing on social entrepreneurship, education, and mental health. Their “Stronger Roots” programme supports systemic social innovation. | The Cube can be presented as a social innovation that prevents mental health issues in children caused by separation. They can fund the Czech translation of the interface, the production of 100 units, and a business model workshop for the Czech social enterprise. Grant up to CZK 3 million. |
| **Výbor dobré vůle – Nadace Olgy Havlové (Committee of Good Will – Olga Havel Foundation)** | A respected foundation supporting children in institutional care, families in crisis, and the development of social services. | A perfect fit. A grant to equip a children's home (dětský domov) or a foster care support centre with Cubes, enabling children to maintain a voice bond with their biological parents. Seed grant: CZK 200,000–500,000. |
| **Nadační fond Avast (Avast Foundation)** | Focuses on using technology for social good, digital safety, and mental well-being. | Fund the security audit, the cloud infrastructure, and the data privacy compliance (GDPR) of the Cube's system, framing it as “ethical tech for the most vulnerable”. Grant or in-kind technical support. |
| **ČEZ Foundation** | Large corporate foundation with a strong regional presence and a focus on communities and children's education/well-being. | Could sponsor Cubes for OSPODs in regions where ČEZ operates (e.g., Ústí nad Labem, Moravia-Silesia), integrating the project into their “Pohyby pro radost” or community grant lines. |
| **Diaspora & Crowdfunding (Znesnáze / Donio / HitHit)** | Czechs are highly active in online giving. Platforms like Znesnáze (for social causes) or Donio can run targeted campaigns. | A powerful campaign: “Darujte hlas – dejte dítěti slyšet mámu i tátu, i když nejsou spolu” (Donate a voice – let a child hear mom and dad, even when they are apart). Can fund the initial 30 Cubes and generate significant public awareness. Target: CZK 500,000–1 million. |

#### D. Research and University Partnerships

The Czech Republic has world-class research institutions in psychology, social work, and child development.

| Institution | Programme / Fit | Application for Cube |
| :---- | :---- | :---- |
| **Masaryk University (Brno) – Institute for Research on Children, Youth and Family (IVDMR)** | The leading Czech research centre on child development, attachment, and family dynamics. They have extensive experience with EU-funded research projects (Horizon, ESF). | A formal research partnership for the longitudinal RCT on the Cube's impact on attachment and emotional regulation. IVDMR can be the scientific coordinator for a Horizon Europe application, with the Cube as the intervention. |
| **Charles University (Prague) – Faculty of Social Sciences / Department of Psychology** | Strong research on family psychology, trauma, and digital media effects on children. | Partner for a qualitative study on the Cube's acceptance in different family cultures (including Roma families) and its perceived naturalness compared to screens. Joint application to the Czech Science Foundation (GA ČR). |
| **University of Ostrava – Faculty of Social Studies** | Focus on social work and social inclusion in the Moravia-Silesia region, a high-need area. | Pilot the Cube in the Ostrava region, integrating it into the university's social work training clinic. Students can be trained to support families using the Cube, creating a sustainable workforce model. |
| **Palacký University Olomouc – Department of Psychology / Pedagogická fakulta** | Centre for research on child mental health and educational psychology. | Co-develop the methodology for using the Cube in schools as a tool for children in post-divorce school transitions or for children in long-term hospital care, funded by a TA ČR (Technology Agency) grant. |

---

### 3\. Refined 3-Phase Funding Strategy for the Czech Republic

The strategy moves from a local academic-philanthropic proof-of-concept to a national public service embedded in the child protection system.

**Phase 1: Semínko (Seed, Years 1–2) — Target: €80,000–€150,000**

- **Primary Philanthropic Seed:** Secure a grant from **Nadace OSF** (Active Citizens Fund) or **Nadace České spořitelny**. Use this to: complete Czech translation and cultural adaptation; produce 30-40 prototypes; run a proof-of-concept pilot with the OSPOD Brno or Prague 7, working with 30 families.  
- **Corporate In-Kind:** **Nadační fond Avast** provides pro-bono cybersecurity and GDPR compliance consulting. **Vodafone Czech Republic Foundation** (if active) provides IoT SIMs.  
- **Research Anchor:** Sign a memorandum with **Masaryk University IVDMR** to design the evaluation framework and supervise the pilot ethically, in exchange for co-authorship on future publications and joint EU grant applications.  
- **Legal Status:** Register as a **zapsaný spolek (z.s.)** (registered association) or **zapsaný ústav (z.ú.)** (registered institute), or, ideally, partner with an existing well-respected child protection NGO (e.g., **Dobrá rodina, o.p.s., Centrum LOCIKA**). This local entity is crucial for opening a bank account and receiving Czech foundation and public funds.

**Phase 2: Pilot a Důkazy (Pilot & Evidence, Years 3–4) — Target: €500,000–€1.2 million**

- **Primary Public Funding:** Lead a large-scale project as the main applicant under the **OPZ+ (ESF+)** call for “Innovative Services in Child Protection.” A consortium of your NGO, Masaryk University, and 4-5 OSPOD offices (from different regions) will deploy 300 Cubes, train 80 social workers, and conduct a rigorous quasi-experimental evaluation.  
- **Dual EU Grant:** Simultaneously lead a **CERV Daphne** project (€500,000) with international partners to write the European protocol for the Cube's use in supervised contact in domestic violence cases. The Czech pilot serves as one of the test sites.  
- **EEA Grant Complement:** Apply for a **Norway Grants** “Justice” programme grant to train family court judges and mediators on ordering and interpreting the Cube's contact logs as evidence, in partnership with a Norwegian family justice research institute.  
- **Government Integration:** The MPSV, based on the OPZ+ pilot results, issues a “recommended methodology” circular to all OSPODs, officially recognising the Cube as a supported contact tool. A dedicated state grant line for its deployment is announced.

**Phase 3: Škálování a Veřejná Infrastruktura (Scale & Public Infrastructure, Year 5+) — Target: €2 million+ annually**

- **Systemic Embedding:** The Cube service becomes an accredited social service under the Social Services Act (Act No. 108/2006), entitled to per-hour state subsidies. All 14 regions can now procure the Cube package from a central framework agreement funded by the state budget for child protection.  
- **Judicial Integration:** The Ministry of Justice, in a joint decree with the Ministry of Labour and Social Affairs, integrates the Cube into the standard repertoire of measures in family law proceedings, particularly for long-distance and supervised contact. The state procures a national cloud platform.  
- **Foster Care Standard:** The Cube becomes part of the standard toolkit for foster carers (pěstouni) nationwide, funded through the annual state contribution for foster care, enabling continuous audio contact with biological parents and siblings placed separately.  
- **International Hub:** Using the Czech evidence base (EEA, CERV, Horizon Europe), your organisation becomes a Central European centre of excellence, applying for an EU-wide policy experimentation project to replicate the model in Slovakia, Hungary, and Poland.

---

### 4\. Concrete Next Steps in the Czech Republic

- **Weeks 1-4 — Local Anchor:** Identify and secure a partnership with a leading Czech non-profit already active in child protection or family mediation (e.g., **Centrum LOCIKA** – focused on children in high-conflict divorces; **Dobrá rodina** – foster care and family support; or **Aperio** – healthy parenting). This organisation will be your first legal host and credibility anchor. Sign a memorandum.  
- **Month 2 — Academic Alliance:** Finalise a partnership with **Masaryk University IVDMR** in Brno. Obtain a letter of intent to be the scientific supervisor for an ESF+ and a Horizon Europe project. This is your strongest asset for public funders.  
- **Month 3 — First Donor Meeting:** Prepare a concise Czech-language concept note and request a face-to-face meeting with the programme director at **Nadace OSF** (Active Citizens Fund) and the corporate foundation manager at **Nadace České spořitelny**. Present the Cube as a low-threshold, rights-based innovation that tackles the hidden harm of parental conflict.  
- **Month 4 — Government Ally:** Approach the head of the child protection methodology unit at the **Ministry of Labour and Social Affairs (MPSV)** . Do not ask for funding; ask for a consultation and a “letter of interest” (zájem) stating that the Cube concept aligns with the National Strategy and is worth piloting. This letter is essential to win an OPZ+ grant.  
- **Month 5-7 — Proof-of-Concept Grant:** Apply for a seed grant (€20,000–€40,000) from **Nadace OSF** or the **Olga Havel Foundation** to pilot the Cube with 15 families through one progressive OSPOD in Prague or Brno. Film short, anonymised testimonials from parents and social workers.  
- **Ongoing — Monitor OPZ+ and Norway Grants:** The ESF+ calls via the Ministry of Labour are the primary scaling vehicle. Track the “Unofficial Translation of the OPZ+ Call Schedule” and the Norway Grants’ “Human Rights” programme. Be ready to submit a full proposal with your strong consortium of university, NGO, and 5 OSPODs the moment a relevant call opens.

The Czech child protection system is actively seeking alternatives to institutionalisation and high-conflict court battles, supported by strong EU funding and a politically backed deinstitutionalisation agenda. The Story Cube offers a uniquely Czech-friendly solution: a pragmatic, voice-driven, and scientifically grounded tool that bridges the gap between the beautiful words of the Civil Code and the painful daily reality of a separated child. With the right academic-social-governmental alliance, it can become a standard, reimbursed part of the national child welfare infrastructure.  
