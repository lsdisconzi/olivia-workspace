---

**Cubo di Storie (Story Cube) in Italy**  
Comprehensive Funding Options Review — July 2026

“Your life should be applied to a cause, not to things.” This spirit drives the Story Cube — an initiative that seeks not a financial return, but the restoration of a fundamental right: the bond between a child and the parent who loves them, even when they live apart. In Italy, where high-conflict family separations, a legacy of institutionalisation, and a reforming family justice system converge, the Cube can serve as a critical tool for child-centred intervention, trauma prevention, and the concrete implementation of the child’s right to family life.

---

### 1\. The Italian Legal & Policy Window – Your Entry Point

To unlock funding, position the Cube as a tool that directly implements Italy’s constitutional and legal commitments to children and families.

* **Constitution, Article 30 & 31:** The Republic protects children and youth and supports the family in fulfilling its duties. The Cube operationalises this support.  
* **Law No. 54/2006 on Shared Custody (Affidamento Condiviso):** This law establishes the child’s right to maintain a balanced and continuous relationship with both parents after separation, even in high conflict. The Cube provides a verifiable, court-admissible channel to uphold this right when physical co-presence is impossible or temporarily suspended.  
* **Law No. 184/1983 (amended) on Adoption and Fostering:** Affirms the right of a minor to grow up in their own family. Article 1 states that the State, Regions, and Local Authorities must support families to prevent abandonment. The Cube is a preventive tool that strengthens the parent-child bond and can be a key measure in a “family support project” to avoid removal.  
* **Cartabia Reform (Legislative Decree No. 149/2022):** This comprehensive civil justice reform emphasises mediation, a unified family court (Tribunale per le Persone, per i Minorenni e per le Famiglie), and the active listening to the child. The Cube’s child-led audio recording is a perfect technological expression of the child’s right to be heard and can be a standard tool ordered by the new court.  
* **National Plan for Children and Adolescents (Piano Nazionale Infanzia e Adolescenza):** The current plan focuses on deinstitutionalisation, digital innovation for children, and the fight against educational poverty. The Cube can be integrated as a “digital service for family strengthening” within the national and regional action plans.  
* **EU Child Guarantee – Italian Action Plan:** Italy must implement the European Child Guarantee to combat child poverty and social exclusion. The Cube, especially when used for children in care, in migration contexts (unaccompanied minors or families separated by borders), or in situations of educational poverty, directly supports the “access to adequate services” pillar.

---

### 2\. Comprehensive Funding Sources for Italy

Italy’s funding ecosystem is vast and multi-layered: a mix of EU structural funds, national social policy funds, regional budgets, a uniquely large banking foundations sector, corporate social responsibility, and significant European research and innovation programmes. A blended model is essential.

#### A. European Union Structural and Investment Funds (The Largest Opportunity)

As an EU Member State, Italy receives tens of billions through its national and regional operational programmes. The 2021–2027 cycle prioritises social innovation, child protection, and digitalisation.

| Funding Source | Programme / Mechanism | How the Story Cube Fits |
| :---- | :---- | :---- |
| **ESF+ (European Social Fund Plus)** | **National OP “Inclusion and Fight against Poverty” (PN Inclusione)** and 21 Regional Operational Programmes. Priorities: child protection, family support, deinstitutionalisation, innovation in social services. Typical calls are managed by Ministries (Labour, Family) and Regions. | The Cube can be funded as a “technological innovation for integrated family services” under specific regional calls (e.g., Regione Lombardia, Regione Toscana). A direct project proposal to a managing authority, often through a partnership with a municipality or an ATS (Ambito Territoriale Sociale), for piloting 150 Cubes with families known to social services. Budget up to €1 million per regional project. |
| **ERDF (European Regional Development Fund)** | National and Regional OPs on Research and Innovation. Invests in product development and digitalisation of SMEs/start-ups with social impact. | If the Cube’s producer is constituted as an Italian innovative start-up or social enterprise, they can apply for ERDF calls to fund the technological refinement (cloud platform, security protocols, accessibility features) and industrialisation of the Cube as “social tech.” |
| **PNRR (National Recovery and Resilience Plan)** | Mission 5 “Inclusion and Cohesion”, Component 2 “Social Infrastructure, Families, Communities and Third Sector”. Key investments: **Sub-investment 1.1.1** (Support for vulnerable families to prevent institutionalisation of minors), **1.2** (Pathways of autonomy for persons with disabilities), and **1.3** (Social housing and support for fragile families). | The Cube is a perfect tool for projects under the PNRR’s “PIPPI” Programme (Programme of Intervention for the Prevention of Institutionalisation) and for new family centres. A consortium of Ambiti Territoriali Sociali could include the Cube in their PNRR project plan as an innovative service for maintaining family ties. PNRR funds must be committed quickly. |
| **Erasmus+ (KA2 Cooperation Partnerships)** | Focus on innovation in education and youth. Calls for school education, adult education, and vocational training. | A consortium of an Italian school, a university, and an NGO could apply to develop a training curriculum for teachers, social workers, and family mediators on using the Cube as a tool for educational continuity for children in separated families. Grant: €120,000–€400,000. |
| **CERV (Citizens, Equality, Rights and Values)** | **Daphne strand** (combatting violence against children) and **Rights of the Child** strand. Italian NGOs, universities, and local authorities are eligible as lead or partners. | Lead a transnational project (with partners from Greece, Spain, etc.) to pilot the Cube as a supervised contact tool in domestic violence cases, or to address parental alienation as a form of psychological abuse. The project can fund a multi-country pilot, evaluation, and a legal protocol for family courts. Grant: €500,000–€2.5 million. |
| **Horizon Europe** | Cluster 2 “Culture, Creativity and Inclusive Society”, Destination “Innovative Research on Social and Economic Transformations”. Calls on child well-being, digital ethics, and social innovation. | A consortium led by the University of Padua or the CNR (National Research Council) can apply for an R\&D grant to study the neuro-psychological and attachment outcomes of the Cube’s low-screen, voice-based interaction for children 0-6, comparing it with video calls. The Cube is the object of study. |

#### B. National Public Funding (Italian Government and Agencies)

Italy has a dedicated Ministry for Family, Birth Rate and Equal Opportunities, which is the natural institutional home for the Cube.

| Source / Institution | Mechanism | How to Access |
| :---- | :---- | :---- |
| **Department for Family Policies (Dipartimento per le Politiche della Famiglia)** | Manages the **National Fund for Family Policies** and the **Fund for the Protection of Minors**. It publishes annual public notices for innovative family services, parenting support, and the fight against educational poverty. | Respond to the annual “Avviso pubblico per il finanziamento di progetti di innovazione sociale per il benessere delle famiglie”. Present the Cube as a “digital service for maintaining family ties in separation”. Budget requests can be up to €500,000. The Department’s endorsement is also critical for national scaling. |
| **Con i Bambini – Social Enterprise** | The implementation body of the “Fund for the Fight against Child Educational Poverty” (established by banking foundations and government). It finances large, multi-year projects led by third-sector partnerships. | A perfect match. Their calls (“Bando per la prima infanzia”, “Bando Nuove Generazioni”) seek innovative solutions for vulnerable children. A strong partnership of a capofila (lead NGO), 5-10 municipalities, and a research body could secure €500,000–€1 million for a multi-regional pilot. |
| **5 per Mille (5x1000)** | A mechanism where Italian taxpayers can allocate 0.5% of their income tax to a non-profit organisation. | Register the Italian branch of your non-profit (ETS – Ente del Terzo Settore) in the national register for 5x1000. A well-communicated campaign (“Dona il tuo 5x1000 al Cubo di Storie per ricostruire il legame tra un bambino e il suo genitore”) can generate significant, multi-year unrestricted funding (€20,000–€100,000+ annually), perfect for core costs. |
| **National Institute for Social Security (INPS)** | Manages welfare funds and publishes calls for projects supporting public employees’ families and work-life balance. | Apply for a call focused on parenting support and conciliation. A project “Cubo di Storie: Tecnologia per l’ascolto e la genitorialità” targeting families of public employees in high-conflict separation could receive a grant of €50,000–€150,000. |

#### C. Regional and Local Government Funding

Italy’s social services are managed by **Comuni** (municipalities) aggregated into **Ambiti Territoriali Sociali (ATS)** .

| Source / Institution | Mechanism | How to Access |
| :---- | :---- | :---- |
| **Ambiti Territoriali Sociali (ATS) & Municipalities** | The ATS is the primary planning unit for social services. Each ATS has a budget for family support, minor protection, and social inclusion. They can directly commission services or co-finance innovative projects. | Partner with a major municipality (e.g., Roma, Milano, Napoli, Torino) or its ATS. Propose a service contract where the ATS funds the deployment of 30 Cubes as a “supervised distance contact service” for families under a court decree. A cost-benefit analysis showing reduced costs for community-based staff-supervised visits is key. Budget: €30,000–€100,000 per ATS. |
| **Regional Programmes (e.g., Regione Emilia-Romagna, Regione Puglia)** | Many regions have specific laws for family and childhood and issue calls for social innovation. | Monitor the regional Official Bulletins (BUR). A call on “Support for co-parenting and family relations” can fund a regional pilot with your lead partner being a local social cooperative (cooperativa sociale). |
| **ASL (Local Health Authority) – Consultori Familiari** | Public family counselling centres are tasked with supporting families through separation. They can adopt and fund new service models. | The Cube can be integrated into the Consultorio’s service portfolio. An agreement with a large ASL (e.g., ASL Città di Torino, ASL Roma 2\) to pilot the Cube with 20 families followed by their psychologists can be funded from the ASL’s “Health and Social Care Integration” budget. |

#### D. Italian Philanthropic and Third Sector (A Uniquely Strong Pillar)

Italy has the largest system of banking foundations in Europe and a vibrant third sector.

| Organisation | Programme / Interest | Fit for Story Cube |
| :---- | :---- | :---- |
| **Fondazione Compagnia di San Paolo (Turin)** | “Persone” Objective: Focuses on child welfare, fight against educational poverty, and support for fragile families. Invests in “tech for good” that generates systemic impact. | An ideal lead philanthropic partner. They could fund a large-scale, multi-year evaluation project in Piedmont and Liguria, supporting the technological development and the construction of a scalable economic model. Grants can be €200,000–€500,000. |
| **Fondazione Cariplo (Milan)** | “Welfare in Transition” and “Childhood” programmes. Co-funds innovative, scalable social services through its calls for proposals (bandi). | Respond to the “Bando per il Benessere dell’Infanzia” or “Bando Innovazione Sociale”. The Cube’s preventive character and digital nature align perfectly with Cariplo’s interest in strengthening community welfare. Grant up to €400,000. |
| **Fondazione con il Sud (Rome)** | Funds projects in Southern Italy to combat educational poverty and strengthen social cohesion. Manages large public-private funds. | A project “Il Cubo della Gentilezza” (The Kindness Cube) targeting children in fragile families in the peripheries of Naples, Bari, or Palermo, presented with a network of local voluntary organisations. A perfect territorial match. Grants: €100,000–€300,000. |
| **Save the Children Italia / SOS Villaggi dei Bambini** | Major international child rights organisations with extensive Italian operations and donor bases. | Strategic partnership. Your Italian entity becomes a provider of the Cube to their ongoing programmes supporting families at risk of separation. They can fund the initial pilot and integrate the Cube into their national advocacy for policy change. |
| **Intesa Sanpaolo – Fondo di Beneficenza** | The in-house philanthropic fund of Italy’s largest bank. Focuses on serious social hardship, minors, and families. | As an Italian banking foundation and charity, they can sponsor a project to equip the family courts (Tribunali per le Famiglie) with Cubes, integrating with their “law and social services” network. Grant up to €150,000. |

#### E. Corporate Social Responsibility and Private Sector

| Organisation | Programme / Fit | Action |
| :---- | :---- | :---- |
| **Fondazione Vodafone Italia** | Focuses on using technology for inclusion and child safety. The “Connecting for Good” ethos. | In-kind partnership: Vodafone provides the IoT connectivity (SIM cards and data plan for life) and funds the development of a dedicated security audit for the cloud platform. A potential flagship CSR project “Ricostruire il legame” (Rebuilding the bond). |
| **Fondazione TIM** | Dedicated to digital empowerment and social innovation through technology. Their “Nuvola Rosa” or similar tech-for-women/children initiatives are relevant. | Co-fund the development of the Cube’s user interface and the parental mobile app, framing it as ethical, low-bandwidth technology for vulnerable users. A grant of €50,000–€100,000. |
| **Coop Alleanza 3.0 / Coop Lombardia** | Large consumer cooperatives with a strong social mandate. They run the “1 euro per tutti i bambini” (1 euro for all children) campaign. | The Cube could be added to the products/initiatives financed by the customer micro-donations campaign, or become a specific project in their “Sostieni una scuola” (Support a school) programme, given the Cube’s educational value. |
| **Diaspora & Community Foundations** | Fondazione Italia Sociale, community foundations (e.g., Fondazione di Comunità Milano, Fondazione della Comunità Bresciana). | Perfect for small-scale, hyper-local pilots. A project by a local social cooperative can be fully funded by a community foundation for a pilot in a single municipality. Seed grants from €10,000. |

#### F. Research and University Partnerships

| Institution | Programme / Fit | Application |
| :---- | :---- | :---- |
| **University of Padova – Department of Developmental Psychology and Socialisation** | A leading research centre on child attachment, family relations, and the impact of technology on development. | Formalise a research partnership to design and conduct a rigorous longitudinal RCT on the Cube’s efficacy vs. standard video calls. The university can be the scientific lead for a Horizon Europe or a Cariplo social research grant. |
| **Bambino Gesù Children’s Hospital (Rome)** | IRCCS (Scientific Institute for Research, Hospitalisation and Healthcare) with a specific focus on paediatric psychology and child protection. | Co-develop a clinical protocol for the Cube’s use in cases of severe parental alienation or chronic illness, integrating it into the hospital’s child protection unit. Joint applications for Ministry of Health research funds. |
| **CNR – Istituto di Scienze e Tecnologie della Cognizione** | Studies cognitive development and social robotics/AI in educational contexts. | A technology development partnership. The CNR could supervise the design of the Cube’s interaction model, ensuring it is grounded in cognitive science. A co-application for a PRIN (Projects of Relevant National Interest) or an EU grant. |
| **Politecnico di Milano / Torino – Design and Social Innovation departments** | Focus on product-service system design for social challenges. | Partner for a Master’s thesis project or a Polisocial Award (Politecnico di Milano’s social responsibility programme) to ideate the next-generation Cube design for autonomous use by very young children, funded with a €30,000–€60,000 grant. |

---

### 3\. Refined 3-Phase Funding Strategy for Italy

The strategy leverages Italy’s “innovation via pilot and evidence” model, building from a local seed to a national public infrastructure.

**Phase 1: Seme (Seed, Years 1–2) — Target: €150,000–€300,000**

* **Primary Philanthropic Seed:** Secure a single, committed grant from **Fondazione Compagnia di San Paolo** or **Fondazione Cariplo**. Use this to: fund a rigorous evaluation design with the University of Padova; produce 50 Italian-language Cubes; establish the Italian legal entity (Associazione/ETS); and run an in-depth pilot in one ATS (e.g., in Turin or Milan) with 50 families.  
* **Corporate In-Kind & Foundation:** **Fondazione Vodafone Italia** provides connectivity and a security audit. **Fondazione TIM** co-funds the app.  
* **Research Anchor:** Sign a co-research agreement with the **Department of Developmental Psychology, University of Padova**, which will apply for its own PRIN or MIUR grant to fund the research assistant time for the pilot evaluation.  
* **Legal Structure:** Constitute an **Ente del Terzo Settore (ETS)** , preferably a **Cooperativa Sociale** (social cooperative) or an Associazione di Promozione Sociale (APS) in partnership with a young, innovative social enterprise. This is a prerequisite for accessing 5x1000 and most foundation funding.

**Phase 2: Pilota e Prova (Pilot & Evidence, Years 3–4) — Target: €800,000–€1.5 million**

* **Primary National Public Funding:** Lead a major project as capofila under a **Con i Bambini** call on “Prima Infanzia”. A partnership of 3-4 ETS, 6 municipalities (ATS), and the University of Padova will pilot 300 Cubes across North, Centre, and South, generating solid evidence.  
* **Major EU Funding:** A consortium led by an Italian university or ETS secures a **CERV Daphne** grant (€500,000–€1 million) with EU partners to write the legal protocol for the Cube’s use in family courts and domestic violence cases, framing it as a European best practice.  
* **PNRR Integration:** A large municipality or a regional authority (e.g., Regione Emilia-Romagna) includes the Cube in its PNRR project for “preventing the institutionalisation of minors” under Mission 5, directly procuring and deploying 500 Cubes for its ATS network.  
* **Political Endorsement:** The **Department for Family Policies** issues a formal recommendation, recognising the Cube as an innovative service for co-parenting support. This unlocks regional and ATS budgets.

**Phase 3: Scala e Infrastruttura Pubblica (Scale & Public Infrastructure, Year 5+) — Target: €2 million+ annually**

* **Systemic Integration:** The Cube is codified into the National Guidelines for interventions with children and families in separation (Linee Guida Nazionali). The service is included in the Essential Levels of Social Services (LEPS – Livelli Essenziali delle Prestazioni Sociali). Once it is an officially recognised service, all ATS across Italy are mandated to provide it, opening a permanent line of ESF+ and National Social Policy Fund co-financing.  
* **Judicial Integration:** The new **Tribunale per le Persone, per i Minorenni e per le Famiglie** adopts the Cube as a standard option in its toolkit, with a national agreement between the Ministry of Justice and your organisation for its use in judicially supervised contact cases. A nationwide procurement is launched.  
* **International Expansion:** Using the Italian and Albanian evidence base, your Italian ETS becomes the Southern European hub, applying for an **Erasmus+ “Policy Experimentation”** grant to export the model across all Mediterranean EU states, funded at €3 million+ for a vast cross-national rollout.

---

### 4\. Concrete Next Steps in Italy

* **Weeks 1-4 — Partnership and Structure:** Identify and formalise a partnership with a well-established Italian ETS active in family services (e.g., a major social cooperative like “Gruppo Abele”, “Casa della Carità”, or a specialised association like “GeA – Genitori Ancora”). This entity will be the initial co-proponent and fiscal host. Simultaneously, instruct a “commercialista” to register your own branch as an APS or new social cooperative.  
* **Month 2 — Scientific Anchor:** Secure a letter of intent from Prof. Paola Rigo or a leading attachment researcher at the University of Padova, committing to be the scientific director for the pilot. This is a non-negotiable credibility asset for Italian funders.  
* **Month 3 — First Funder Contact:** Write a concise concept note and request meetings with the Welfare programme officer at **Fondazione Compagnia di San Paolo** and the Institutional Relations office at **Fondazione Vodafone Italia**. Present the Cube as a rights-based, scientifically-grounded answer to the hidden pandemic of parental conflict and a tool for the Child Guarantee.  
* **Month 4 — Political Ally:** Request a technical meeting with an official at the **Dipartimento per le Politiche della Famiglia** (Presidency of the Council of Ministers) responsible for innovation in family services. Do not ask for money; present the Cube and ask for their feedback and a potential “patronage” (patrocinio) or letter of interest to attach to your first grant application.  
* **Month 5-7 — First Seed Grant:** With your university LoI, political patronage, and ETS partner, apply to a targeted philanthropic call (e.g., **Fondazione Cariplo’s “Bando per l’infanzia”** ) for a €150,000 seed grant. The project: “CU.BO. – Cubo di Storie, Custodire il Bene della Relazione” (Story Cube, Safeguarding the Good of the Relationship).  
* **Ongoing — Monitor Con i Bambini:** The calls from “Con i Bambini” are the single most important step for scaling in Italy. Prepare a large partnership dossier ahead of their next publication.

Italy’s family justice and child protection system is undergoing a profound, once-in-a-generation transformation through the Cartabia reform and an unprecedented convergence of PNRR, EU, and philanthropic funding. The Story Cube offers a concrete, gentle, and rights-based tool that perfectly embodies the new paradigm of child-centred family support. By building a solid academic-philanthropic alliance in the North and immediately proving its value, the Cube can rapidly become an essential part of the Italian welfare infrastructure.  
