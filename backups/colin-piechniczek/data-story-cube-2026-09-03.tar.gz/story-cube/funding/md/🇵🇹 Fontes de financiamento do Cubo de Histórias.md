---

**Cubo de Histórias (Story Cube) in Portugal**  
Comprehensive Funding Options Review — July 2026  
*“Your life should be applied to a cause, not to things.”* This spirit drives the Story Cube — an initiative that seeks not a financial return, but the restoration of a fundamental right: the bond between a child and the parent who loves them, even when they live apart. In Portugal, where family courts are overburdened, migration and separation are rising, and the child protection system actively pursues family-based alternatives, the Cube can become a recognised tool of preventive social innovation and rights-based practice.

---

### 1\. The Portuguese Legal & Policy Window – Your Entry Point

To unlock funding, position the Cube as a tool that directly implements Portugal’s child protection and family law commitments.

- **Código Civil (Civil Code), Articles 1906.º and 1906.º‑A:** Parental responsibilities are exercised jointly, and the child has the right to maintain a direct and regular relationship with the parent who does not live with them. The Cube is the concrete, child-centred means to ensure this contact is meaningful and verifiable.  
- **Lei de Proteção de Crianças e Jovens em Perigo (LPCJP, Law 147/99, updated):** The law prioritises keeping the child in the family and prescribes intervention through the CPCJ (Commissions for the Protection of Children and Young People). The Cube can be deployed by a CPCJ or court as a supervised, child-led contact mechanism that generates evidence for case decisions.  
- **Regime Geral do Processo Tutelar Cível (Law 141/2015):** Regulates civil guardianship proceedings. The judge can determine the terms of visitation. The Cube’s tamper-proof log and supervised communication mode give family courts a reliable monitoring tool.  
- **Estratégia Nacional para os Direitos da Criança 2021–2025 (National Strategy for the Rights of the Child):** Aligned with the EU Child Guarantee, it emphasises deinstitutionalisation, family strengthening, and digital tools that protect children. The Cube is a ready-made digital solution for “family-centred digital inclusion.”  
- **Portugal 2030 and the European Child Guarantee National Action Plan:** Portugal’s Partnership Agreement mobilises €23 billion in EU funds, with clear objectives on child poverty and social innovation. The Cube fits within the ESF+ priority of developing innovative social responses and integrated family support services.  
- **Recovery and Resilience Plan (PRR):** Investments in the digital transition of social services and in modernising the care infrastructure provide a time-limited but substantial funding window. The Cube can be proposed as a tech-enabled social care innovation under the “Social Responses” component.

---

### 2\. Comprehensive Funding Sources for Portugal

The funding landscape combines EU structural and direct funds, strong bilateral mechanisms, robust national public programmes, an active philanthropic sector, and university research excellence. A blended model is essential.

#### A. EU Structural and Direct Funds (The Largest Pool)

| Funding Source | Programme / Mechanism | How the Story Cube Fits |
| :---- | :---- | :---- |
| **Portugal 2030 – ESF+ (Fundo Social Europeu Mais)** | The thematic programme *PESSOAS 2030* and regional programmes (Norte 2030, Centro 2030, Lisboa 2030, etc.) fund social innovation, family inclusion, and combating child poverty. Calls for “innovative social answers” are issued by managing authorities. | The AMKE (or a Portuguese non-profit partner) can apply to a regional ESF+ call to pilot the Cube as a “digital mediated contact service.” A project with 150 families across several municipalities, incorporating training and evaluation, fits perfectly. Budget range: €200,000–€800,000. The Lisbon regional programme is particularly open to tech-based social initiatives. |
| **Portugal Inovação Social (Portugal Social Innovation)** | A dedicated public initiative using ESF+ and national funds to scale social innovations. Instruments include **Partnerships for Impact** (grant \+ co-investment) and **Social Impact Bonds**. | The Cube can be presented as a high-potential social innovation that improves family justice outcomes and reduces costs for the state. A “Partnership for Impact” with a municipality or the CNPDPCJ would cover a 2–3-year pilot with rigorous evaluation. This is one of the most tailored funding routes for the Cube. |
| **Erasmus+ (KA2 – Cooperation Partnerships)** | Portugal is a full Programme Country. Calls for cooperation in adult education or school education can fund tools that strengthen parenting skills and family engagement. | A consortium with a Portuguese university (e.g., ISCTE-IUL) and an Italian NGO can develop training materials for practitioners and evaluate the Cube’s impact on parental capacity and child well-being. Grant size: up to €400,000. |
| **CERV (Citizens, Equality, Rights and Values)** | The Daphne and Rights of the Child calls are directly applicable. Portuguese organisations can be coordinators or partners. | Lead a transnational project on preventing psychological violence through alienation, with the Cube as the core intervention in Portugal, Italy, and Spain. The call “Rights of the Child and Violence Prevention” is ideal. Grant: €400,000–€1 million for a consortium. |
| **Horizon Europe (Cluster 2 / Health)** | Portuguese research institutions and social enterprises are eligible. Topics on child mental health, digital ethics, or inclusive societies. | Partner with the Faculty of Psychology of the University of Lisbon or Coimbra to study the Cube’s effect on attachment, language development, and loneliness. A Research and Innovation Action can fund 3 years of work. |
| **EU4Health / Digital Europe** | Smaller windows but possible if the Cube is framed as a digital mental health tool for vulnerable children. | A call on “digital tools for children’s mental health” could cover adaptation and deployment. Check annual work programmes. |

#### B. Bilateral and International Funds

| Institution | Programme Focus in Portugal | Funding Pathway for Cube |
| :---- | :---- | :---- |
| **EEA Grants (Norway, Iceland, Liechtenstein) 2021–2028** | Under the current funding period, Portugal will benefit from substantial grants in the areas of social inclusion, justice reform, and child protection. The **Active Citizens Fund** and specific **Bilateral Initiatives** are being launched. | This is a strategic opportunity. The Cube can be proposed as a bilateral project between a Portuguese civil society organisation and an Icelandic or Norwegian partner with experience in family justice tech. A well-designed project for implementing the Cube in family courts and CPCJs could secure €300,000–€700,000. Monitor the calls of the *Mecanismo Financeiro do Espaço Económico Europeu* in Portugal. |
| **UNICEF Portugal (National Committee)** | While not a large grant-maker, UNICEF Portugal advocates for children’s rights, co-funds pilot projects with municipalities, and provides the “Child Friendly Cities” framework. | Approach UNICEF Portugal for a small seed grant (€10,000–€30,000) to run a feasibility study in a “Cidade Amiga das Crianças” (Child Friendly City) such as Loures or Guimarães. They can also convene the first meeting with key public bodies. |
| **US Embassy Lisbon – Small Grants Program** | The Public Affairs Section funds projects on democracy, human rights, and social inclusion, typically up to $25,000. | A small grant can fund the translation and cultural adaptation of the Cube’s interface and legal-navigation materials for Portuguese families, with a launch event at the embassy. |
| **Swiss-Portuguese Cooperation** | Switzerland is a contributor to EU cohesion but also has a direct bilateral cooperation programme with selected EU member states. Portugal, however, is not a main focus. | Not a primary target, but the Swiss Embassy in Lisbon occasionally funds small social innovation actions. Worth checking the annual small grants programme. |

#### C. National Public Funding (Portuguese Government and Municipalities)

| Source / Institution | Mechanism | How to Access |
| :---- | :---- | :---- |
| **Ministério do Trabalho, Solidariedade e Segurança Social (MTSSS) – Instituto da Segurança Social (ISS)** | The ISS manages social services and funds programmes for families and children. The **Plano de Ação da Garantia para a Infância** allocates dedicated funding to prevent child poverty and family separation. | The ISS can contract the Cube as an innovative family support service, funded under the Child Guarantee budget line. A direct approach to the Director of Childhood and Youth Services with a cost-benefit dossier and pilot results can lead to a service purchase agreement. |
| **Comissão Nacional de Promoção dos Direitos e Proteção das Crianças e Jovens (CNPDPCJ)** | The national oversight body for the CPCJ network. It does not have a large direct budget but can prioritise the Cube within its national action plans and recommend it to the Government. | Secure the CNPDPCJ’s institutional patronage and request a formal opinion that the Cube is a beneficial tool for the child protection system. This letter is vital for unlocking ISS and municipal funding. |
| **Câmaras Municipais (Municipal Councils)** | The 308 municipalities have autonomous social action budgets. Large cities (Lisboa, Porto, Sintra, Cascais, Braga, Coimbra) actively fund innovative social projects through direct grants or protocol agreements. | Approach the Pelouro dos Direitos Sociais (Social Rights Department) of the Lisbon City Council with a concrete pilot proposal for families under its jurisdiction. A contract under the municipality’s “Programa de Desenvolvimento Social” can fund 30–50 Cubes and local coordination. |
| **Portugal Inovação Social (already mentioned)** | Falls under national public management of ESF+ funds. The “Títulos de Impacto Social” (Social Impact Bonds) instrument is particularly interesting. | Structure a pilot where a social investor (e.g., a bank foundation) pre-finances the Cube rollout, and the State repays based on measurable outcomes (reduction in family conflict reports, improved child well-being). This route is complex but can unlock large-scale funding. |
| **Fundo para a Inovação, a Tecnologia e Economia Circular (FITEC) / Agência para a Modernização Administrativa** | For the tech and administrative modernisation dimension. | If the Cube’s platform is to be integrated into the social security or justice IT systems, co-financing for the development and interoperability can be requested. |

#### D. Portuguese Philanthropic and Private Sector

The philanthropic sector in Portugal is mature, with large foundations and strong corporate social responsibility traditions.

| Organisation | Programme / Interest | Fit for Story Cube |
| :---- | :---- | :---- |
| **Fundação Calouste Gulbenkian** | Programmes in social cohesion, child development, and digital inclusion. The Gulbenkian Knowledge Academy also supports research. | A grant under the “Coesão e Integração Social” or “Inovação Social” programme to pilot the Cube with 100 vulnerable families in the Lisbon Metropolitan Area. Gulbenkian can also fund a rigorous independent evaluation. Budget: up to €150,000. |
| **Fundação “la Caixa” / BPI Foundation** | The “Promove” programme funds innovative social projects in the interior and border regions. “Childhood and Youth” is a priority line. | Apply to a “Promove” call to implement the Cube in Alentejo or Trás-os-Montes, where family separation due to migration is acute. Grant: €50,000–€100,000 per project. |
| **Fundação EDP** | EDP Solidária supports projects in social inclusion, focusing on energy and technology for the community. | Frame the Cube as a low-energy, offline-capable digital device that connects families without invasive screen time. EDP could fund the production of Cubes and their connectivity kits. |
| **Vodafone Portugal Foundation / MEO / NOS** | Telecom foundations invest in digital well-being and child protection online. Vodafone’s “Apps for Good” and similar programmes exist. | Vodafone Portugal Foundation could provide the LTE connectivity and the cloud platform for a two-year pilot as part of its “Connecting for Good” CSR strategy. MEO may contribute through the Altice Foundation. |
| **Banco Santander Portugal / Caixa Geral de Depósitos** | CSR budgets for social action. Caixa’s “Caixa Social” programme funds projects for children at risk. | A straightforward corporate donation to purchase and distribute 50 Cubes to institutions working with separated families. Santander’s “Fundo Solidário” is also an option. |
| **Santa Casa da Misericórdia de Lisboa (SCML)** | SCML is both a major social provider and a funder via its Social Innovation Fund. It actively backs tech-for-good projects. | A partnership with SCML to test the Cube in one of its childhood and family centres is a direct and prestigious entry point. SCML can co-fund the pilot from its own budget or the “Fundo de Inovação Social” it manages. |

#### E. Research and University Partnerships

| Institution | Programme | Application for Cube |
| :---- | :---- | :---- |
| **ISCTE – Instituto Universitário de Lisboa** | The Centre for Psychological Research and Social Intervention (CIS-IUL) has deep expertise in family dynamics, digital media, and child welfare. | Partner to design and lead the longitudinal impact evaluation. Apply together for an FCT (Fundação para a Ciência e a Tecnologia) project grant or an Erasmus+ research partnership. ISCTE can also host a PhD scholarship tied to the Cube’s study. |
| **Faculdade de Psicologia e de Ciências da Educação, Universidade de Coimbra (FPCEUC)** | Strong focus on attachment, family assessment, and forensic psychology. | Collaborate on adapting the Cube’s protocol for high-conflict divorce cases and validating it as a forensic tool. Coimbra is also ideal for a study in the Central region. |
| **Faculdade de Psicologia e de Ciências da Educação, Universidade do Porto (FPCEUP)** | Expertise in child development and early intervention. | A joint application to the EU’s Horizon Europe programme on “digital childhoods” with the Cube as the empirical case study. |
| **Centro de Estudos Judiciários (CEJ)** | The judicial training body. | Involve CEJ to accredit the training module for judges and prosecutors on using the Cube in family proceedings, funded by a small EU justice grant. |

---

### 3\. Refined 3-Phase Funding Strategy for Portugal

**Phase 1: Semente (Seed, Years 1–2) — Target: €100,000–€180,000**

- **Primary Funding:** A small grant from the **Portugal Inovação Social** “Capacity Building for Social Innovation” line or an **EEA Grants Active Citizens Fund** call. Use these to fully localise the Cube interface and parent platform into European Portuguese, produce 30–40 prototypes, and run a proof-of-concept with two CPCJs in Lisbon and one in the interior (e.g., Guarda or Beja).  
- **Corporate In-Kind:** Vodafone Portugal Foundation for connectivity; a local manufacturer for the wooden casing (linking to the “made in Portugal” craft narrative).  
- **Research Anchor:** Sign an MoU with CIS-IUL for pro-bono evaluation design and a jointly supervised master’s thesis on the pilot.  
- **Legal Status:** Register as a Portuguese **Associação** (non-profit association) or, even better, partner with an existing **IPSS** (Private Social Solidarity Institution) that already works in family support and can act as the legal host. IPSS status gives tax benefits and eligibility for specific state contracts.

**Phase 2: Piloto e Evidência (Pilot & Evidence, Years 3–4) — Target: €500,000–€1,000,000**

- **Primary Funding:** A **CERV** or **ESF+** consortium project led by a Portuguese university and the Italian AMKE, with the CNPDPCJ as an associated partner. This full pilot covers 250 Cubes across 8 municipalities and includes a randomised controlled trial. Complement with an **EEA Grants** bilateral project to add a digital ethics component with a Norwegian partner.  
- **Government Contract:** Secure a direct service agreement with the **Instituto da Segurança Social** to include the Cube in the catalogue of “Supported Contact Services” for the Child Guarantee National Action Plan. The State budgets for X number of families per year.  
- **Evaluation:** Publish the pilot results in an international peer-reviewed journal and present them at the Portuguese Congress on Child Psychology. Funded by a small **FCT** grant or the **Gulbenkian Knowledge Academy**.

**Phase 3: Escala e Infraestrutura Pública (Scale & Public Infrastructure, Year 5+) — Target: €2 million+ annually**

- **Primary Funding:** The Cube is adopted as a nationally recognised tool within the family justice and child protection system. Funding is mainstreamed through the **ISS regular social services budget** and the **PRR’s successor digital programme**, allowing the state to procure Cubes as standard equipment for CPCJs and family courts.  
- **Judicial Integration:** The **Conselho Superior da Magistratura** and the **CNPDPCJ** issue a joint guideline recommending the Cube as an evidence-gathering tool in family custody and visitation cases. It becomes part of the official case management toolkit.  
- **International Replication:** Using the strong evidence from Portugal and Italy, lead a **Horizon Europe** scale-up project to export the model to Brazil and Portuguese-speaking African countries (PALOP), with the Portuguese consortium acting as the global hub for Lusophone adaptation.

---

### 4\. Concrete Next Steps in Portugal

- **Weeks 1-4 — Local Anchor:** Identify and formalise a partnership with a respected IPSS in the Lisbon area (e.g., one specialising in family mediation or child contact centres). This organisation will be the initial operational home, allowing you to open a bank account, sign protocols, and immediately apply for grants that require a Portuguese NIF.  
- **Month 2 — Institutional Ally:** Request a meeting with the **CNPDPCJ** (National President’s office). Do not ask for money; present the Cube and ask for a letter of interest endorsing it as a promising tool for the CPCJ network. This letter is the single most important document for unlocking public and EU funds in Portugal.  
- **Month 3 — First Funder Contact:** Submit a concise concept note to the **Portugal Inovação Social** technical team and to the Programme Officer for Civil Society at the **EEA Grants** National Focal Point. Position the Cube as an innovative solution for family preservation and the digital transition of social services.  
- **Month 4-6 — Pre-Pilot:** Use the partnership and CNPDPCJ endorsement to secure a small, fast grant (€15,000–€30,000) from **UNICEF Portugal**, the **US Embassy**, or a **BPI Promove** call. Run a 10-family pre-pilot with one CPCJ. Document it thoroughly with video testimonials, user feedback, and a simple impact report.  
- **Ongoing — Monitor Calls:** Actively track the **Portugal 2030** calls portal, the **CERV** and **Erasmus+** funding and tender opportunities, and the **EEA Grants Portugal** website. The key call to target is the next “Rights of the Child” strand of CERV or the ESF+ social innovation window. When it opens, you will be ready with a strong consortium, national endorsement, and pilot data.

Portugal’s mature welfare state, combined with a vibrant social innovation ecosystem and a strong policy commitment to children’s rights, makes it a perfect European home for the Story Cube. By navigating the ESF+, EEA Grants, and national foundation pathways strategically, the Cube can move from a pilot to a standardised, publicly funded service that safeguards the bond between every separated parent and child.  
