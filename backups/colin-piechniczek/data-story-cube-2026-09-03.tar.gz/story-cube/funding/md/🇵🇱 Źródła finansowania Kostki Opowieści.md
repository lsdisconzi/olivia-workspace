---

Cubo de Histórias (Story Cube) in Poland  
Comprehensive Funding Options Review — July 2026  
“Your life should be applied to a cause, not to things.” This spirit drives the Story Cube — an initiative that seeks not a financial return, but the restoration of a fundamental right: the bond between a child and the parent who loves them, even when they live apart. In Poland, where family separation, migration, a reforming foster care system, and a strong tradition of judicial oversight of child contact intersect, the Cube can serve as a critical tool of early intervention and rights protection.

---

### 1\. The Polish Legal & Policy Window – Your Entry Point

To unlock funding, position the Cube as a tool that directly implements Poland’s child protection, family law, and social welfare commitments.

- **Kodeks rodzinny i opiekuńczy (Family and Guardianship Code, Act of 25 February 1964, as amended):** Articles 113–113⁶ establish the child’s right to maintain contact with both parents and define the court’s power to regulate contact, including ordering supervised meetings when the child’s welfare so requires. The Cube’s secure, monitored, and child-directed communication channel fits directly into the execution of court-ordered contact.  
- **Ustawa o przeciwdziałaniu przemocy domowej (Act on Counteracting Domestic Violence, of 9 March 2023):** This law provides for protection orders and a multi-agency “Niebieska Karta” (Blue Card) procedure. Where contact must be safe and traceable, the Cube’s supervised mode and immutable log offer courts and social workers a verifiable, low-conflict method of ensuring the child’s right to family life while upholding protective measures.  
- **Ustawa o wspieraniu rodziny i systemie pieczy zastępczej (Act on Family Support and Foster Care System, of 9 June 2011):** This law prioritises keeping children in their biological families and promotes family reintegration. The Cube can be presented as a preventative, digital tool for “family strengthening” that reduces the risk of a child entering the care system by maintaining attachment to a non-custodial parent.  
- **Krajowy Program Przeciwdziałania Przemocy Domowej na lata 2024–2030 (National Programme for Counteracting Domestic Violence 2024–2030):** The programme supports innovative interventions that protect children from the psychological harm of family conflict. Supervised digital contact is an explicit innovation that aligns with its goals.  
- **European Child Guarantee – Poland’s National Action Plan (2022–2030):** Poland’s plan focuses on children at risk of poverty, in alternative care, and in situations of family breakdown. It calls for innovative, family-centred services and the modernisation of support infrastructure. The Cube is a ready-made digital solution for these “innovative family services”.  
- **EU Structural Funds 2021–2027:** As the largest net beneficiary of EU cohesion policy, Poland has allocated over €76 billion to development programmes. Social inclusion, child protection, and digital transformation are key spending areas, creating massive, structural financing opportunities for the Cube if it is embedded in national or regional programmes.

---

### 2\. Comprehensive Funding Sources for Poland

The funding landscape combines massive EU structural funds, substantial EEA and Norway Grants, a well-resourced state budget, professionalised philanthropic institutions, and a large corporate CSR market. A blended, multi-level strategy is essential.

#### A. EU Structural and Investment Funds (The Largest, Most Structural Opportunity)

Poland channels EU funds through national operational programmes and 16 regional programmes. The Cube can be funded as a social innovation project within these frameworks.

**Funding Source / Programme**  
*European Social Fund Plus (ESF+) — Krajowy Program Fundusze Europejskie dla Rozwoju Społecznego (FERS)*  
**How the Story Cube Fits**  
FERS is the main national programme for social inclusion, with priorities on family support, deinstitutionalisation, and child welfare. The Ministry of Family, Labour and Social Policy (MRPiPS) issues calls for “innovative social services” and “development of family support forms”. The Cube can be proposed as a digital, low-screen tool for maintaining child-parent bonds. A consortium of an NGO and a local government (e.g., a city’s Miejski Ośrodek Pomocy Społecznej) can apply for a grant of up to PLN 2 million (€450,000) to pilot the Cube in several powiats. Calls are announced regularly on the FERS portal.

**Funding Source / Programme**  
*16 Regional Operational Programmes (Fundusze Europejskie dla \[Województwa\])*  
**How the Story Cube Fits**  
Each voivodeship manages its own ESF+ allocation for social inclusion. Programmes in Mazowieckie, Małopolskie, Wielkopolskie, and Dolnośląskie have specific measures for “integration of families” and “child protection in the community”. A locally-rooted project — e.g., “Digital Contact Service for Families in Wrocław” — can be submitted to the Regionalny Ośrodek Polityki Społecznej (ROPS) in partnership with the Marshal’s Office. Funding can cover equipment purchase, software adaptation, and social worker training for 1–3 years.

**Funding Source / Programme**  
*Krajowy Plan Odbudowy i Zwiększania Odporności (KPO — National Recovery and Resilience Plan)*  
**How the Story Cube Fits**  
The KPO includes a “Reform of the social welfare system and deinstitutionalisation” component and a “Digital transformation of public services” track. The Cube can be proposed as an e-service that improves the quality of family court proceedings and social assistance. The Polish Development Fund (PFR) or MRPiPS can fund pilot projects that digitise social care. While the KPO’s timeline is tight (to 2026), future extensions or post-2027 cohesion policy will continue this logic.

**Funding Source / Programme**  
*EU Direct Programmes — CERV (Citizens, Equality, Rights and Values)*  
**How the Story Cube Fits**  
Polish organisations are fully eligible as lead applicants or partners. The *Daphne* strand (combating violence against children) and the *Rights of the Child* strand are particularly relevant. A consortium led by a Polish foundation in partnership with the Italian AMKE and a Lithuanian or Czech NGO can apply for a 2-year project (budget €400,000–€800,000) to pilot the Cube in supervised contact centres across three EU countries, building a transnational evidence base. Calls are published on the European Commission’s Funding & Tenders Portal.

**Funding Source / Programme**  
*Erasmus+ — Cooperation Partnerships in Youth / School Education*  
**How the Story Cube Fits**  
A partnership between a Polish university (e.g., SWPS University) and a youth NGO can develop a training curriculum for parents and professionals on attachment-centred digital contact, using the Cube as the core tool. A 24-month project with an EU grant of €250,000–€400,000 is feasible. This route funds capacity building, not hardware, so it is ideal for methodology, training, and dissemination.

**Funding Source / Programme**  
*Horizon Europe — Cluster 2 “Culture, Creativity and Inclusive Society”*  
**How the Story Cube Fits**  
Polish research institutions (e.g., Instytut Psychologii PAN, Uniwersytet Jagielloński) can lead a consortium to research the ethical, child-centred design of haptic communication technology. The Cube becomes the use case for studying “low-screen digital tools for attachment”. A Research and Innovation Action grant of €2–3 million can fund a 3-year multi-country study, positioning the Cube at the cutting edge of responsible tech.

#### B. EEA and Norway Grants (A Dedicated Social Inclusion Window)

Poland is one of the largest beneficiaries of the EEA and Norway Grants 2014–2021 (extended into 2024–2027 for many programmes), with dedicated funds for justice, children, and civil society.

**Funding Source / Programme**  
*EEA Grants — “Active Citizens Fund — Regional” (Fundusz Aktywni Obywatele)*  
**How the Story Cube Fits**  
This fund, operated by a consortium of Polish foundations, supports civil society in human rights, civic engagement, and social innovation. Grants of €15,000–€60,000 are available for projects that pilot new solutions in family rights and child participation. An application through a local partner NGO for a 12-month “Child Voice in Separation” pilot, with 20 Cubes, can be submitted during open calls.

**Funding Source / Programme**  
*Norway Grants — “Justice Programme” (Program Sprawiedliwość)*  
**How the Story Cube Fits**  
This programme, managed by the Polish Ministry of Justice, focuses on improving access to justice and services for victims of crime, including domestic violence. A project to integrate the Cube as a supervised contact tool in courts and victim support centres, ensuring safe child-parent contact under a Blue Card procedure, can receive a grant of €100,000–€300,000. The Norwegian partner requirement (e.g., a Norwegian children’s rights organisation) strengthens the proposal.

**Funding Source / Programme**  
*EEA Grants — “Children and Youth at Risk” Programme (Program Dzieci i Młodzież)*  
**How the Story Cube Fits**  
This dedicated programme funds early intervention, mental health, and family support projects for vulnerable children. The Cube can be framed as a preventive digital tool that reduces the psychological harm of family separation and maintains family ties. A consortium of an NGO and a local PCPR (Powiatowe Centrum Pomocy Rodzinie) can apply for a grant of up to €400,000 for a multi-site implementation.

#### C. National Public Funding (Polish Government Budget)

Poland’s state budget allocates significant resources to family support, victim assistance, and justice innovation.

**Funding Source / Institution**  
*Ministerstwo Rodziny, Pracy i Polityki Społecznej (MRPiPS) — Program “Razem Możemy Więcej” and the “Od zależności do samodzielności” programme*  
**How the Story Cube Fits**  
MRPiPS runs annual open competitions for innovative social services and deinstitutionalisation. A project titled “Cyfrowa więź rodzinna” (Digital Family Bond) can be submitted, proposing the Cube as a standardised tool for family assistants (asystenci rodziny) and contact centres. Grants typically cover 80–100% of project costs, with total budgets of PLN 200,000–PLN 800,000. The Ministry can also issue a dedicated task order for testing the Cube if approached with a strong advocacy case.

**Funding Source / Institution**  
*Ministerstwo Sprawiedliwości — Fundusz Sprawiedliwości (Justice Fund)*  
**How the Story Cube Fits**  
The Justice Fund, financed from confiscated assets and fines, supports help for victims of crime, including children affected by domestic violence and family conflict. It has a dedicated track for “counteracting the effects of crime”. The Cube can be positioned as a tool for safe, monitored contact in situations of family violence, purchased and placed in victim support centres or court-supervised visitation rooms. A project can be submitted in an open call by an NGO, with a budget of up to PLN 1 million.

**Funding Source / Institution**  
*Local Government Budgets — Gminy and Powiaty*  
**How the Story Cube Fits**  
Municipalities and counties are legally responsible for social assistance (OPS) and family support (PCPR). Large cities (Warsaw, Kraków, Wrocław, Gdańsk, Poznań) have dedicated “social innovation” small grants. The Municipality of Warsaw’s “Innowacje społeczne” programme or Kraków’s “Otwarty konkurs ofert” for social services can fund a pilot of 30–50 Cubes. A service contract with the city, where the Cube is purchased as equipment for the local family support centre, is straightforward if the city’s social policy department sees its value. The device becomes a municipally-owned resource.

**Funding Source / Institution**  
*Narodowy Instytut Wolności — Centrum Rozwoju Społeczeństwa Obywatelskiego (NIW-CRSO)*  
**How the Story Cube Fits**  
NIW-CRSO channels government funds to civil society through programmes like “NOWEFIO” and “PROO”. The “NOWEFIO” programme (a Polish-American Freedom Foundation and government partnership) awards grants for social innovation and support for families. A thematic block on “early support for families in crisis” could fund a Cube pilot for PLN 100,000–PLN 300,000.

#### D. United Nations and International Organisations (Active in Poland)

**Agency / Programme**  
*UNICEF Poland — Biuro UNICEF w Polsce*  
**How the Story Cube Fits**  
UNICEF has a significant presence in Poland due to the response to the Ukraine refugee crisis. Its country programme now supports child protection system strengthening for all children. The Cube can be proposed as a tool to support the maintenance of family ties for refugee children separated from a parent, or as a general child-friendly contact mechanism. UNICEF can provide seed funding (€30,000–€60,000) for a pilot, fund an independent evaluation, and help advocate for national adoption. Contact the Child Protection section in Warsaw.

**Agency / Programme**  
*OSCE Office for Democratic Institutions and Human Rights (ODIHR) — Warsaw*  
**How the Story Cube Fits**  
ODIHR’s mandate includes human rights and the rule of law. It funds small-scale, innovative projects that enhance access to justice and the protection of vulnerable groups. A project to develop a legal and training toolkit for Polish family judges and probation officers on the use of the Cube in contact enforcement, with a budget of up to €50,000, can be funded through ODIHR’s extra-budgetary contributions.

**Agency / Programme**  
*IOM Poland / UNHCR*  
**How the Story Cube Fits**  
For refugee and migrant families from Ukraine and other countries in Poland, the Cube can help maintain cross-border parent-child communication when families are physically separated by the war and resettlement. A targeted project funded by the UNHCR or IOM, or their implementing partners, can distribute Cubes to separated refugee families staying in Poland, framed as a protection and mental health intervention.

#### E. Polish Philanthropic and Private Sector (Well-Developed and Professionalised)

Poland has a mature philanthropic ecosystem with large grant-making foundations, strong corporate social responsibility, and a vibrant crowdfunding culture.

**Funding Source**  
*Fundacja Dajemy Dzieciom Siłę (Empowering Children Foundation)*  
**How the Story Cube Fits**  
This is Poland’s leading child protection organisation, running child advocacy centres, helplines, and family support programmes. They are both a potential implementing partner and a funder (through their own grants or re-granting of donor funds). A collaboration to pilot the Cube within their existing “Child and Family Support Centres” would provide immediate, credible access to vulnerable families. They can also co-apply for EU grants as the Polish partner.

**Funding Source**  
*Polsko-Amerykańska Fundacja Wolności (PAFW — Polish-American Freedom Foundation)*  
**How the Story Cube Fits**  
PAFW runs the “Równać Szanse” (Equal Opportunities) and “Działaj Lokalnie” (Act Locally) programmes. A project that uses the Cube as a tool to equalise the chances of children from separated families in small towns and villages fits their mission. Grants of PLN 20,000–PLN 60,000 for local initiatives, or larger regional grants, are available through open calls.

**Funding Source**  
*Fundacja Batorego (Stefan Batory Foundation)*  
**How the Story Cube Fits**  
While best known for democracy and civic space, Batorego’s “For Diversity” and “Citizen Participation” programmes can fund projects that strengthen the rights of vulnerable groups, including children. A small grant (PLN 15,000–PLN 50,000) could support the adaptation and initial advocacy for the Cube as a rights-enforcement tool.

**Funding Source**  
*Fundacja Świętego Mikołaja (St. Nicholas Foundation) / Fundacja ORLEN / Totalizator Sportowy (Lottery Fund)*  
**How the Story Cube Fits**  
These large Polish corporate and parastatal foundations fund children’s welfare and equipment for care facilities. The purchase of a batch of 100 Cubes for care centres and supervised contact points can be financed as a straightforward equipment grant, framed as “a gift of connection for separated children”.

**Funding Source**  
*Bank PKO Bank Polski, Santander Bank Polska, ING Bank Śląski, BNP Paribas Poland*  
**How the Story Cube Fits**  
Major Polish banks have CSR programmes focused on children, education, and digital inclusion. PKO Bank Polski’s “PKO Dzieciom” fund or Santander’s “Tu się spełniają marzenia” programme can sponsor the purchase and distribution of Cubes to families in poverty. A corporate partnership of PLN 100,000–PLN 300,000 is realistic for a high-profile, emotionally resonant project like the Story Cube.

**Funding Source**  
*Orange Polska Foundation, T-Mobile Polska Foundation, Play Foundation*  
**How the Story Cube Fits**  
Telecoms are interested in digital wellbeing and connecting families. Orange Foundation’s “Pracownie Orange” or a dedicated “tech for good” grant can provide connectivity, cloud hosting, and 4G-enabled Cubes. They may also fund the IT platform development. A flagship project with Orange, “Łączymy rodzinę” (We Connect the Family), would align with their brand.

**Funding Source**  
*Crowdfunding — Zrzutka.pl, Siepomaga.pl, Pomagam.pl*  
**How the Story Cube Fits**  
Polish society is highly responsive to concrete, emotional social causes. A campaign on Zrzutka.pl titled “Kostka, która łączy — głos dziecka dla oddalonego rodzica” (The Cube that Connects — A Child’s Voice for a Distant Parent) can raise PLN 20,000–PLN 50,000 quickly, especially if supported by a media partner or a trusted child-rights ambassador. This can fund the first 20 Cubes for a visible local pilot.

#### F. Research and University Partnerships (Strong Academic Base)

Poland has a robust academic infrastructure in psychology, social work, and human-computer interaction.

**Institution**  
*Uniwersytet SWPS (University of Social Sciences and Humanities)*  
**How the Story Cube Fits**  
SWPS has leading psychology and law faculties. A partnership with its Institute of Psychology to conduct a rigorous RCT on the Cube’s impact on attachment and parental stress can form the basis of a joint NCN (Narodowe Centrum Nauki) grant application under the OPUS or PRELUDIUM BIS scheme, or an EU Horizon Europe proposal. The university can provide in-kind research capacity, while external funding covers the devices and research personnel.

**Institution**  
*Uniwersytet Warszawski (University of Warsaw) — Wydział Psychologii / Instytut Profilaktyki Społecznej i Resocjalizacji*  
**How the Story Cube Fits**  
The University of Warsaw is a frequent partner in EU-funded projects on social innovation. A joint application to CERV or Erasmus+ with the university’s Centre for Human Rights or social pedagogy department can secure a grant for a cross-national study of digital tools in family justice.

**Institution**  
*Instytut Psychologii Polskiej Akademii Nauk (Institute of Psychology, Polish Academy of Sciences)*  
**How the Story Cube Fits**  
IP PAN can lead a Horizon Europe or Norway Grants research consortium to investigate low-stimulation haptic technology for maintaining attachment, generating the high-level evidence needed for systemic adoption. This partnership elevates the project’s scientific credibility for all other funders.

---

### 3\. Refined 3-Phase Funding Strategy for Poland

**Phase 1: Nasiono (Seed, Years 1–2) — Target: PLN 200,000–400,000 (€45,000–€90,000)**

- **Primary Funding:** A small grant from the EEA Active Citizens Fund – Regional (€25,000–€40,000) or UNICEF Poland (seed funding for child protection innovation). These will cover translation and adaptation of the Cube interface and parent platform into Polish, production of 25 prototypes, and a proof-of-concept pilot with 2 Miejskie Ośrodki Pomocy Społecznej (MOPS) — one in a large city (Warsaw’s Wola district) and one in a smaller town (e.g., Płock).  
- **Corporate In-Kind:** Orange Polska Foundation to provide LTE connectivity and a cloud environment for the pilot.  
- **Research Anchor:** Sign a partnership agreement with SWPS University for pro-bono evaluation design, with the understanding that a larger grant will later fund the full RCT.  
- **Legal Status:** Partner with an existing, well-regarded Polish registered charity (fundacja or stowarzyszenie with OPP status — Organizacja Pożytku Publicznego) active in child rights or family support, e.g., Fundacja Dajemy Dzieciom Siłę. This partner serves as the legal host for the pilot, holding the bank account and providing the KRS registration needed for grants. A separate dedicated Polish foundation can be established later when operations scale.

**Phase 2: Pilotaż i Dowody (Pilot & Evidence, Years 3–4) — Target: PLN 2 million–4 million (€450,000–€900,000)**

- **Primary Funding:** Lead a consortium application to the FERS national programme (ESF+) for a project titled “Innowacyjne wsparcie więzi rodzinnych — Pilotaż Kostki Historii w 10 powiatach”. The consortium includes the NGO partner, two university research teams, and several local government PCPRs. The grant covers hardware for 300 families, development of a Polish-language cloud platform, a training programme for asystenci rodziny and judges, and a rigorous process-outcome evaluation.  
- **Complementary Funding:** A Norway Grants “Justice Programme” grant to specifically pilot the Cube in 3 supervised contact centres run by the courts and probation service, with a Norwegian child protection partner.  
- **Government Integration:** By the end of Phase 2, secure a written agreement with MRPiPS that the Cube is recognised as a recommended tool under the “Standardy usług wspierania rodziny i pieczy zastępczej” (Standards of family support and foster care services) and is eligible for financing from the Fundusz Sprawiedliwości.  
- **Evaluation:** Publish a peer-reviewed study in an open-access journal (e.g., *Dziecko Krzywdzone* or an international attachment journal), funded by a small NCN Miniatura grant or a university internal fund.

**Phase 3: Skala i Infrastruktura Publiczna (Scale & Public Infrastructure, Year 5+) — Target: PLN 10 million+ annually**

- **Primary Funding:** The Cube is embedded in the state-funded social service package. MRPiPS includes “Kostka Historii — cyfrowe narzędzie do podtrzymywania kontaktu” in the catalogue of tasks financed from the state budget under the Act on Family Support and Foster Care System. Local governments can then contract the Cube as a standard service, funded through their own budgets and central subsidies.  
- **Judicial Integration:** The Ministry of Justice, in cooperation with the Krajowa Rada Sądownictwa, issues a directive recommending the Cube as an evidence-based tool in family court proceedings concerning contact arrangements. The Justice Fund procures devices for all district courts with family divisions.  
- **International Replication:** Using the Polish and Italian evidence base, the Polish consortium becomes the Central and Eastern European hub for an EU-wide rollout, leading a large CERV or EU4Health project to transfer the model to Czechia, Slovakia, Hungary, and Lithuania.

---

### 4\. Concrete Next Steps in Poland

- **Weeks 1–4 — Local Alliance:** Identify and secure a formal partnership with a leading Polish child protection foundation (e.g., Fundacja Dajemy Dzieciom Siłę or Fundacja Mamy i Taty). This organisation will be the initial legal and operational home for the pilot, providing the Polish KRS number necessary to apply for virtually all grant programmes. Simultaneously, open a dedicated bank account in PLN for the project.  
- **Month 2 — First Funder Contact:** Prepare a concise bilingual (Polish/English) concept note and request introductory meetings with: (a) the Child Protection specialist at UNICEF Poland, (b) the Programme Officer for the Active Citizens Fund – Regional, and (c) the Director of the Department of Social Innovation at MRPiPS. Present the Cube as a practical, ready-to-test tool for deinstitutionalisation and family strengthening.  
- **Month 3 — Public Ally Letter:** Approach the Dyrektor of MOPS in Warsaw-Wola or Kraków’s Miejski Ośrodek Pomocy Społecznej. Do not ask for money immediately; ask for a list intencyjny (letter of intent) expressing willingness to co-design a pilot within their family support units. This letter is decisive for grant applications.  
- **Month 4–6 — Micro-Pilot:** Use a PLN 30,000 grant from the Active Citizens Fund – Regional or a fast-track donation from a corporate foundation to run a 10-family test in one district, with Polish-language voice recordings. Gather photos, short video testimonials from social workers and parents, and basic usage data.  
- **Ongoing — Monitor EU Calls:** Track the FERS call schedule on the website of the Centrum Projektów Europejskich (CPE) and the regional marshal offices’ portals. The key window for social innovation calls is typically the first half of each year. When the right call opens, you will be ready with a strong consortium, letters of support, and compelling pilot data from the seed phase.

Poland’s child protection system is under both EU-mandated and domestic pressure to modernise, deinstitutionalise, and put the child’s best interest at the centre of all interventions. The Story Cube offers an elegantly simple, rights-aligned, and low-cost tool that fits seamlessly into the emerging architecture of family court-ordered and municipally delivered contact services. By navigating the rich landscape of EU structural funds, EEA grants, and a robust NGO-philanthropy nexus, Poland can become the largest-scale exemplar of the Cube’s transformative potential in the European Union.  
