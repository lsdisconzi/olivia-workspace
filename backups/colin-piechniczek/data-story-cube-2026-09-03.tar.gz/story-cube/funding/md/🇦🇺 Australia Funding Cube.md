**Story Cube**

**Vision and Impact Roadmap – Australia**  
*Document v1.0 · 2026 · English*

*“Your life must be applied to a cause, not to things.”*  
This spirit drives the Story Cube — an initiative that seeks no financial return, but the restoration of a fundamental right: the bond between a child and the parent who loves them, even when they live apart.

---

## 1\. Why This Exists

When a child is kept apart from one parent — by distance, separation or deliberate obstruction — they lose something irreplaceable: the everyday sound of the person who loves them.

The Story Cube is not a product that creates social good as a side effect. It is a social mission that uses technology as a tool. Its natural institutional form is therefore a **not-for-profit organisation** — where purpose governs structure, not the other way around.

This document sets out the vision and the path to transform the Story Cube into a public-interest movement: a scalable, evidence-based tool that protects a child’s right to family contact, supports the justice system and helps public services intervene early. All anchored in **Article 9 of the United Nations Convention on the Rights of the Child**, which guarantees the right of the child to maintain regular contact with both parents, unless this is contrary to their best interests.

---

## 2\. The Story Behind the Cube

**From one parent’s distance to every child’s right to be heard**

The Story Cube was born from lived experience: a parent prevented from speaking with their child for almost a month. Calls diverted, messages unanswered. The small everyday moments — *what did you see today? did you like it? what did you draw?* — disappearing into silence.

What followed was a painful realisation: the problem is not a missing app or a slow phone. The problem is that a child’s contact with one parent is often treated as a privilege granted by the other, when in truth it is a right that belongs to the child.

*“Children need a voice. They have rights. Communication with the non-resident parent should be the child’s choice — not something filtered through a gatekeeper.”*

The Cube turns that idea into a physical object: a beautifully crafted wooden box, with screen, microphone, speaker and LTE connectivity integrated into a single unit. It lives in the child’s room. It cannot be blocked, diverted or repurposed. It carries only the voice and stories of the parent who loves them — and nothing else from the internet.

| Not an app | Unblockable | Child-led | Warm and safe |
| :---- | :---- | :---- | :---- |
| A dedicated device. Cannot be uninstalled, hijacked by TikTok or used for anything else. | Built-in LTE ensures no intermediary can cut the connection. | One button to listen, one button to record. No permission needed from an adult in the room. | A wooden companion beside the bed — not another screen competing for attention. |

---

## 3\. The Problem

**Family separation, contact obstruction and the harm to childhood**

In Australia, parental separation affects hundreds of thousands of children. In **2023, there were 48,700 divorces** granted across the country, with **46,834 children under 18** directly involved in these divorces. Beyond divorce, many more children live in de facto separations.

- **Children in separated families:** The Australian Bureau of Statistics estimates that **over 1 in 4 children** have a parent living elsewhere. Many of these children lose regular contact, not by choice but through practical, emotional or obstructive barriers.  
- **Parental responsibility:** Under the *Family Law Act 1975*, there is a presumption of **equal shared parental responsibility**, and the court must consider whether equal or substantial and significant time with both parents is reasonably practicable and in the child’s best interests. Despite this legal framework, in many cases one parent becomes the gatekeeper of the relationship.  
- **Strain on the family law system:** The **Federal Circuit and Family Court of Australia** and the family law system face high workloads, long delays and escalating costs. Parenting disputes can drag on for years, compounding harm to children.  
- **Child protection system:** State and territory child protection departments intervene when children are at risk, yet early-stage family contact disruption is often not visible until harm has already escalated. The **National Framework for Protecting Australia’s Children 2021–2031** prioritises early intervention — a gap the Cube is designed to fill.

**Where current tools fail**

- **Phones and apps are controllable.** The resident parent can delete, restrict or monitor communication. The other parent’s voice never reaches the child.  
- **Ordinary screens are harmful for young children.** Algorithm-driven content and advertising are designed to capture attention, not to nurture attachment.  
- **Children lack a direct voice.** They depend on someone else’s device, someone else’s schedule, and often speak under observation.  
- **Non-resident parents lack affordable, accessible support.** The family law system is expensive and difficult to navigate alone, especially for those without legal representation.

Beyond individual families, the state has a structural gap: there is no widely available, scalable tool to help defend a child’s right to family contact. The Story Cube is designed to fill that gap — not as charity, but as an effective instrument of public protection and early intervention.

---

## 4\. The Solution: The Story Cube

**A wooden cube. Integrated screen, microphone and speaker. A single purpose.**

The Cube is deliberately radical in its simplicity. It is a single, standalone device. It does only what it needs to do, and it does it with warmth and care.

- **Record:** A red button. The child speaks, the other parent receives.  
- **Listen:** A green button. The voice of the person who loves them, instantly.  
- **Share on the TV:** Replace passive cartoons with stories the family created together.  
- **Dual cloud:** Built-in LTE means the connection cannot be severed. Both parents always have secure access.  
- **Made from FSC-certified wood.** Customisable themes — space, animals, fairy tales.  
- **Parent platform:** A web app to send illustrations, choose themes and access a legal navigation toolkit.

**Where we are today:** A working digital MVP already runs in any browser — with 2D and 3D story engines, voice commands and body tracking — allowing early families to test the experience immediately on a tablet or phone. This is the embryo of the physical Cube, now in development, which will bring all this capability into a single, standalone wooden device.

**What it is not:** Not a tablet. Not a phone app. Not a YouTube screen. Not anything that can be diverted, blocked or filled with content the parents have not chosen. The Cube’s discipline is its greatest strength.

---

## 5\. Who Benefits

**Children, parents, the family law system, child protection, police, communities and society at large**

### For the child

- **Emotional security:** Hearing the absent parent’s voice every day helps preserve secure attachment and protects mental health.  
- **Healthy screen time:** No algorithms, no advertisements, no harmful content — only the stories the family chooses.  
- **A voice of their own:** The child can reach out whenever they want. Not when they are allowed. Not under surveillance.  
- **Bedtime ritual:** A story recorded by the other parent replaces the anxiety of separation with comfort.

### For the non-resident parent

- **Unblockable presence:** LTE ensures every message reaches the child. No app to be deleted.  
- **Legal navigation support:** A secure web portal with guides in clear English, templates for parenting plan proposals, a record of communications and an evidence archive — helping litigants navigate the family law system. It complements, but does not replace, independent legal advice.  
- **Documented record:** Every interaction is timestamped, providing objective proof of ongoing parental care for court proceedings.  
- **Creative parenting:** Send drawings, build animated stories, customise the Cube for the child.

### For the Family Law System (Family Court of Australia, Federal Circuit and Family Court, Legal Aid, Community Legal Centres) and Independent Children’s Lawyers

- **Verifiable communication channel:** The Cube can be ordered by consent or by a court as a way to facilitate contact — an objective, auditable channel free from interference.  
- **Record of parental involvement:** Timestamped logs replace contradictory narratives with data. Judges, registrars and Independent Children’s Lawyers see exactly how often a parent connected and what they shared.  
- **Reduction in litigation:** When contact is objectively recorded, disputes over obstruction and non-compliance diminish, freeing court time and reducing animosity.

### For Child Protection, State and Territory Departments, and Police

- **Early intervention in family conflict:** The Cube can be deployed as part of a prevention strategy, reducing repeat calls to services and referrals into the child protection system.  
- **Evidence for protection and criminal investigations:** In cases where one parent uses the child to control the other, the Cube’s immutable record can serve as evidence — and it can be configured to allow only safe, monitored contact where risk exists.  
- **Cost savings:** Every family supported at this early stage avoids escalation to out-of-home care, protection orders or criminal justice processes — saving tens of thousands of dollars per case and preventing intergenerational harm.

### For universities and research centres

The Cube also functions as research infrastructure on the impact of contact obstruction on child development. Through partnerships with Australian universities (University of Melbourne, UNSW, ANU, QUT, Monash, among others), it can generate longitudinal data on emotional wellbeing, language acquisition and attachment — turning lived experience into published evidence that shapes policy.

### For society

The rupture of family bonds creates intergenerational costs: higher rates of mental ill‑health, educational failure, substance misuse and youth offending. Every family that stays connected is a strengthened social cell. The Story Cube acts at the point of prevention — ensuring a loving bond survives separation, reducing childhood suffering and stopping harm from deepening. The social return on this investment is not measured in quarters, but in generations.

---

## 6\. Institutional Path

**A not-for-profit structure in service of the mission**

The Story Cube will be established as a **charitable not‑for‑profit organisation**, registered with the **Australian Charities and Not‑for‑profits Commission (ACNC)**. All resources generated — whether through grants, contracts or donations — will be reinvested entirely in the mission: manufacturing more Cubes, improving the platform, funding independent research and expanding into new areas.

Governance will be exercised by a **board of directors** with expertise in child protection, family law, digital ethics and public service delivery. The organisation may seek **deductible gift recipient (DGR) status** to receive tax‑deductible donations, and will be structured, likely as a company limited by guarantee, to ensure the mission remains paramount.

The Story Cube does not belong to shareholders. It belongs to the cause.

---

## 7\. Ecosystem of Support

**Australian funding sources, partnerships and a three‑phase strategy**

As a not‑for‑profit tool designed for the public sector, the Story Cube can draw on a diversified mix of resources:

**A. Public funding**

- **Australian Government – Department of Social Services (DSS):** Grants for families and children, early intervention and child protection.  
- **Attorney‑General’s Department:** Family law system innovation and legal assistance funding.  
- **State and Territory Governments:** Funding through community services, child protection and family support programs (e.g., NSW Department of Communities and Justice, Victorian Department of Families, Fairness and Housing).  
- **National Legal Aid and Community Legal Centres:** Collaborative service delivery and pilot programs.

**B. Philanthropic foundations and trusts**

- **The Ian Potter Foundation**  
- **The Myer Foundation / Sidney Myer Fund**  
- **Paul Ramsay Foundation**  
- **Vincent Fairfax Family Foundation**  
- **Gandel Foundation**  
- **John T. Reid Charitable Trusts**  
- **State Trustees Australia Foundation**

**C. Corporate and community partnerships**

- **Relationships Australia, UnitingCare, Barnardos Australia, OzChild, Save the Children Australia:** Implementation partners with existing family support infrastructure.  
- **Corporate social responsibility programs:** Major banks, resource companies and insurers often fund community initiatives addressing family wellbeing.

**D. Individual giving**

- Tax‑deductible donations from members of the public once DGR status is obtained.

**E. Potential collaborating institutions**

| Type of Institution | Specific Entity |
| :---- | :---- |
| National Human Rights Institution | Australian Human Rights Commission / National Children’s Commissioner |
| Family Law Courts | Federal Circuit and Family Court of Australia / Family Court of Western Australia |
| Legal Assistance | National Legal Aid / Community Legal Centres |
| Child Protection | State/Territory child protection departments |
| Family Support | Relationships Australia / Family Relationship Centres |
| Research | University of Melbourne, UNSW, ANU, QUT, Monash, AIFS |
| Philanthropy | Ian Potter Foundation, Paul Ramsay Foundation, etc. |

### F. Three‑phase strategy

1. **Seed (Years 1–2):** Foundation grants, initial pilot with one state child protection service or family relationship centre, academic partnership established. First physical prototypes deployed.  
2. **Sustainability (Years 3–4):** Direct contracting by state governments and community services, adoption by the family law pathway, evidence base published, expansion to multiple states.  
3. **Scale (Year 5 onwards):** National rollout with co‑funding from Commonwealth and state governments, integration into parenting orders and early intervention frameworks. International pilots in parallel.

---

## 8\. Alignment with the Australian Legal and Child Protection Framework

The Story Cube is designed to sit at the intersection of Australia’s legal and child protection architecture:

- **Family Law Act 1975 (Cth), Part VII:** The **best interests of the child** are the paramount consideration (s 60CA). The **objects and principles** (s 60B) include the right of the child to know and be cared for by both parents and to maintain a meaningful relationship with both parents, while protecting children from harm.  
- **Equal shared parental responsibility:** Section 61DA creates a presumption of equal shared parental responsibility, and the court must consider whether equal or substantial and significant time with each parent is reasonably practicable and in the child’s best interests.  
- **Parenting orders and consent orders:** Courts can make orders that include specific communication methods. The Cube can be embedded in such orders as an agreed or directed communication tool.  
- **UN Convention on the Rights of the Child:** Ratified by Australia in 1990\. **Article 9** ensures a child’s right to maintain contact with both parents unless contrary to their best interests.  
- **State and territory child protection legislation:** E.g., *Children and Young Persons (Care and Protection) Act 1998 (NSW)*, *Children, Youth and Families Act 2005 (Vic)*, which prioritise early intervention and preservation of family relationships where safe.  
- **National Framework for Protecting Australia’s Children 2021–2031:** Commits to early intervention and a public health approach to child protection — the Cube aligns with these goals.

---

## 9\. Glossary of Australian Legal Terms

| Term | Description |
| :---- | :---- |
| **Best interests of the child** | The paramount principle under the Family Law Act guiding all parenting decisions. |
| **Parental responsibility** | All the duties, powers and responsibilities parents have in relation to a child. |
| **Equal shared parental responsibility** | A presumption that both parents share responsibility for major long‑term decisions, unless rebutted by safety concerns. |
| **Shared care arrangement** | A parenting arrangement where a child spends substantial and significant time with both parents. |
| **Parenting order** | A court order setting out arrangements for a child’s care, including who the child lives with, spends time with and communicates with. |
| **Parenting plan** | A written agreement between parents about the care of their child, which can be registered with the court. |
| **Family dispute resolution (FDR)** | A mediation process families must generally attempt before going to court for parenting orders. |
| **Independent Children’s Lawyer (ICL)** | A lawyer appointed by the court to represent the best interests of a child in family law proceedings. |
| **Child protection order** | An order made by a state/territory children’s court when a child is found to be in need of protection. |
| **Department of Communities and Justice (DCJ)** | Example: the NSW child protection and family support agency. Similar departments exist in other states. |

---

## 10\. Five‑Year Roadmap

**From concept to national infrastructure**

| Phase | Period | Key Activities | Milestones |
| :---- | :---- | :---- | :---- |
| **1\. Foundation** | 0–12 months | Register the charitable organisation. Complete first physical Cube prototype (screen, audio, LTE). Obtain seed funding. Formalise research partnership with an Australian university. | Legal entity registered. Functional prototype ready. 3 strategic partnerships. |
| **2\. Pilot** | 12–24 months | Deploy 100–150 Cubes in 2–3 communities, integrated with Family Relationship Centres, Legal Aid or child protection. Collect wellbeing and usage data. First independent evaluation published. | 150 families supported. First evaluation report. |
| **3\. Evidence** | 24–36 months | Peer‑reviewed publication of outcomes. Adoption by child protection or family law services. Expand to 10 regions. | 2 academic papers. Contract with at least one state government or large NGO. |
| **4\. Scale** | 36–48 months | 50+ regions. Formal use in consent orders or court‑directed contact. Team of 25+ people. | 10,000 Cubes deployed. 5 court registries using Cube data. |
| **5\. Public Infrastructure** | 48–60 months | Cube recognised as part of national family support and justice infrastructure. Co‑funded by Commonwealth and state governments. International pilots. | 50,000+ Cubes. Policy guidance issued. International recognition. |

---

## 11\. Join This Movement

**Commission, research, advocate, create, govern**

*“Every child deserves to hear the voice of someone who loves them.*  
*Every parent deserves to reach their child.*  
*The Story Cube makes this possible — with simplicity, safety and warmth.”*

We are building more than a device. We are building an evidence‑based, public‑sector‑ready movement for children’s rights.

Whether you are a local councillor, a child protection caseworker, a family lawyer, a judicial officer, an academic researcher, a domestic violence support service, or a parent who knows this struggle first‑hand — **there is a place for you in this work.**

- **Commission:** State child protection agencies, family relationship centres and legal aid commissions: trial the Cube in your area as part of your early intervention or family contact strategy.  
- **Research:** Universities and the Australian Institute of Family Studies: partner with us to evaluate the impact on child wellbeing, attachment and language development.  
- **Advocate:** Family law practitioners, Independent Children’s Lawyers, judicial officers and children’s commissioners: help shape the Cube as a recognised tool for contact and evidence.  
- **Create:** Illustrators, storytellers and animators: contribute to an open library of themes and stories.  
- **Govern:** Join our board of directors. Help guide the organisation with transparency and rigour.

---

**Story Cube**  
*Connection that transforms — a bridge of love between parents and children*  
Aligned with the United Nations Convention on the Rights of the Child · Article 9  
Australian charitable organisation in formation  
Made with care for families everywhere  
